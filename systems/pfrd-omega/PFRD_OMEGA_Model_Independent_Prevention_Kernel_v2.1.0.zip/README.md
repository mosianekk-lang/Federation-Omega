# PFRD-Ω 2.1

PFRD-Ω is an external prevention and release service. The model produces a candidate only. The candidate is compiled into structured claims, checked against signed proofs and a multidimensional state lattice, attacked by an adversarial verifier, evaluated by a deny-by-default policy, and cryptographically sealed before it may be returned.

## Valid paths

```text
USER → GATEWAY → MODEL CANDIDATE → CLAIM COMPILER → PROOF/STATE RESOLVER
     → ADVERSARIAL VERIFIER → POLICY ENGINE → RELEASE SEALER → USER
```

```text
TOOL REQUEST → APPROVAL → CAPABILITY TOKEN → TOOL BROKER → PROVIDER
             → INDEPENDENT READBACK → PROOF LEDGER
```

Direct model-to-user and model-to-provider paths are not part of the application interface.

## Truthful activation states

- `POLICY_ONLY`: source or service exists, but enforcement qualification has not passed.
- `LOCAL_KERNEL_QUALIFIED`: the external gateway, claim gates, proof ledger, broker, readback and sealer pass locally.
- `KERNEL_ENFORCED`: the deployed runtime proves that the gateway is the sole release route and internal services are not publicly bypassable.
- `PRODUCTION_SEALED`: KERNEL_ENFORCED plus production identity, security, recovery, monitoring and two zero-regression cycles.

## Local qualification

```bash
python -m pip install -e .
pytest
python scripts/qualify_local.py
```

## Service

```bash
cp .env.example .env
uvicorn services.gateway:app --host 127.0.0.1 --port 8080
```

The public model route requires `OPENAI_API_KEY`. The administrative canary route tests the complete prevention path without making a paid model call.

## Docker

```bash
docker compose up --build -d
python scripts/qualify_deployment.py
```

Only the gateway is published. Internal services and PostgreSQL remain on the private network.
