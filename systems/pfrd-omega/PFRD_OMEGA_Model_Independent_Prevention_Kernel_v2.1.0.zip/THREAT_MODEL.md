# Threat model

Principal threats are model self-certification, prompt injection, direct provider bypass, stale proofs, duplicate external actions, approval replay, forged receipts, output modification after approval, state changes between check and release, and treating registry or queue state as completion.

Controls include a sole gateway, deny-by-default policy, structured claim parsing, exact-scope completion contracts, capability tokens, provider readback, proof expiry and revocation, immutable-style hash chaining, atomic release receipts and regression tests for known failure signatures.
