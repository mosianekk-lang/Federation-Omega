#!/usr/bin/env bash
set -euo pipefail
export PYTHONPATH="${PYTHONPATH:-.}"
python -m compileall -q pfrd services scripts
pytest -q
python scripts/qualify_local.py
