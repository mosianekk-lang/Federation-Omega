from __future__ import annotations

import hashlib
import json
import os
import secrets
import signal
import subprocess
import sys
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx
import yaml

ROOT = Path(__file__).resolve().parents[1]
PORT = 18080
BASE = f"http://127.0.0.1:{PORT}"
DB = Path('/tmp/pfrd-omega-local-qualification.db')
RECEIPT = ROOT / 'qualification' / 'local_kernel_qualification_receipt.json'


def keys() -> dict[str, str]:
    return {
        'PFRD_PUBLIC_API_KEY': secrets.token_urlsafe(32),
        'PFRD_ADMIN_API_KEY': secrets.token_urlsafe(32),
        'PFRD_SERVICE_TOKEN': secrets.token_urlsafe(32),
        'PFRD_PROOF_SIGNING_KEY': secrets.token_urlsafe(48),
        'PFRD_APPROVAL_SIGNING_KEY': secrets.token_urlsafe(48),
        'PFRD_CAPABILITY_SIGNING_KEY': secrets.token_urlsafe(48),
        'PFRD_RELEASE_SIGNING_KEY': secrets.token_urlsafe(48),
    }


def env(base: dict[str, str], mode: str) -> dict[str, str]:
    result = dict(os.environ)
    result.update(base)
    result.update({
        'DATABASE_URL': f'sqlite+pysqlite:///{DB}',
        'PFRD_ACTIVATION_MODE': mode,
        'PFRD_POLICY_VERSION': '2.1.0',
        'PFRD_PROVIDER_ALLOWLIST': '127.0.0.1,localhost',
        'PFRD_REQUIRE_OPA': 'false',
        'OPENAI_API_KEY': '',
        'PYTHONPATH': str(ROOT),
    })
    return result


def start_server(server_env: dict[str, str]) -> subprocess.Popen:
    process = subprocess.Popen(
        [sys.executable, '-m', 'uvicorn', 'services.gateway:app', '--host', '127.0.0.1', '--port', str(PORT)],
        cwd=ROOT,
        env=server_env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    deadline = time.time() + 45
    while time.time() < deadline:
        if process.poll() is not None:
            output = process.stdout.read() if process.stdout else ''
            raise RuntimeError(f'gateway exited early: {output}')
        try:
            response = httpx.get(f'{BASE}/health', timeout=2)
            if response.status_code == 200:
                return process
        except Exception:
            pass
        time.sleep(0.5)
    stop_server(process)
    raise RuntimeError('gateway did not become ready')


def stop_server(process: subprocess.Popen) -> None:
    if process.poll() is None:
        process.send_signal(signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill(); process.wait(timeout=5)


def admin_headers(k: dict[str, str]) -> dict[str, str]:
    return {'X-PFRD-Admin-Key': k['PFRD_ADMIN_API_KEY']}


def canary(k: dict[str, str], scope: str, text: str) -> dict:
    response = httpx.post(
        f'{BASE}/v1/admin/release-canary',
        headers=admin_headers(k),
        json={
            'candidate_id': f'canary-{uuid.uuid4()}',
            'scope_id': scope,
            'text': text,
            'model': 'LOCAL_QUALIFICATION_CANARY',
            'created_at': datetime.now(timezone.utc).isoformat(),
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def issue_proof(k: dict[str, str], scope: str, proof_type: str, payload: dict) -> dict:
    now = datetime.now(timezone.utc)
    response = httpx.post(
        f'{BASE}/v1/admin/proofs',
        headers=admin_headers(k),
        json={
            'proof_type': proof_type,
            'owner_id': 'KAGISO_KIM_MOSIANE',
            'matter_id': 'PFRD-OMEGA',
            'mission_id': 'LOCAL-KERNEL-QUALIFICATION',
            'scope_id': scope,
            'subject_id': 'PFRD-OMEGA-KERNEL',
            'issuer_domain': 'EXTERNAL_QUALIFICATION_RUNNER',
            'provider_name': 'LOCAL_QUALIFICATION_RUNNER',
            'environment': 'LOCAL',
            'observed_at': now.isoformat(),
            'valid_from': now.isoformat(),
            'expires_at': (now + timedelta(hours=24)).isoformat(),
            'independently_read_back': True,
            'payload': payload,
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def compose_check() -> dict:
    config = yaml.safe_load((ROOT / 'docker-compose.yml').read_text())
    exposed = {name: service.get('ports', []) for name, service in config['services'].items() if service.get('ports')}
    internal = config['networks']['pfrd_internal'].get('internal') is True
    if set(exposed) != {'gateway'} or not internal:
        raise RuntimeError(f'bypass topology failed: exposed={exposed}, internal={internal}')
    return {'passed': True, 'exposed_services': exposed, 'internal_network': internal}


def create_state(k: dict[str, str], scope: str, proof_ids: list[str], version: int) -> dict:
    response = httpx.post(
        f'{BASE}/v1/admin/state',
        headers=admin_headers(k),
        json={
            'scope_id': scope,
            'version': version,
            'lattice': {
                'definition_state': 'HASH_VERIFIED',
                'source_state': 'HASH_MATCHED',
                'function_state': 'CANARY_PASSED',
                'trigger_state': 'FIRED',
                'execution_state': 'TERMINAL_SUCCESS',
                'result_state': 'RECONCILED',
                'verification_state': 'ADVERSARIAL_REVIEW_PASSED',
                'legacy_state': 'READ_BACK',
                'duplicate_state': 'ZERO_DUPLICATES',
                'rollback_state': 'RESTORE_CANARY_PASSED',
                'security_state': 'AUTHORIZATION_VERIFIED',
                'provider_state': 'PROVIDER_CONFIRMED',
                'freshness_state': 'FRESH',
                'environment_state': 'LOCAL',
            },
            'proof_ids': proof_ids,
            'updated_at': datetime.now(timezone.utc).isoformat(),
        },
        timeout=20,
    )
    response.raise_for_status()
    return response.json()


def tool_route(k: dict[str, str], scope: str) -> dict:
    response = httpx.post(
        f'{BASE}/v1/tools/execute',
        headers=admin_headers(k),
        json={
            'owner_id': 'KAGISO_KIM_MOSIANE',
            'matter_id': 'PFRD-OMEGA',
            'mission_id': 'LOCAL-KERNEL-QUALIFICATION',
            'scope_id': scope,
            'action': 'HTTP_GET',
            'side_effect_class': 'READ_ONLY',
            'parameters': {
                'url': f'{BASE}/health',
                'readback_url': f'{BASE}/health',
                'idempotency_key': f'local-broker-{uuid.uuid4()}',
            },
        },
        timeout=30,
    )
    response.raise_for_status()
    result = response.json()
    if result['status'] != 'READBACK_CONFIRMED':
        raise RuntimeError(f'tool broker route failed: {result}')
    return result


def consequential_route(k: dict[str, str], scope: str) -> dict:
    params = {
        'url': f'{BASE}/v1/admin/release-canary',
        'readback_url': f'{BASE}/health',
        'headers': admin_headers(k),
        'json': {
            'candidate_id': f'provider-canary-{uuid.uuid4()}',
            'scope_id': 'PROVIDER-CANARY',
            'text': 'This is a bounded provider-route canary.',
            'model': 'PROVIDER_CANARY',
            'created_at': datetime.now(timezone.utc).isoformat(),
        },
        'idempotency_key': f'consequential-{uuid.uuid4()}',
    }
    expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    approval = httpx.post(
        f'{BASE}/v1/approvals', headers=admin_headers(k),
        json={
            'owner_id': 'KAGISO_KIM_MOSIANE', 'matter_id': 'PFRD-OMEGA',
            'mission_id': 'LOCAL-KERNEL-QUALIFICATION', 'scope_id': scope,
            'action': 'HTTP_POST', 'side_effect_class': 'EXTERNAL_COMMUNICATION',
            'exact_parameters': params, 'expires_at': expiry,
        }, timeout=20,
    ); approval.raise_for_status(); approval_data = approval.json()
    parameter_hash = hashlib.sha256(json.dumps(params, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    capability = httpx.post(
        f'{BASE}/v1/capabilities', headers=admin_headers(k),
        json={
            'approval_id': approval_data['approval_id'], 'matter_id': 'PFRD-OMEGA',
            'mission_id': 'LOCAL-KERNEL-QUALIFICATION', 'scope_id': scope,
            'action': 'HTTP_POST', 'side_effect_class': 'EXTERNAL_COMMUNICATION',
            'exact_parameters_hash': parameter_hash, 'expires_at': expiry,
        }, timeout=20,
    ); capability.raise_for_status(); cap_data = capability.json()
    body = {
        'owner_id': 'KAGISO_KIM_MOSIANE', 'matter_id': 'PFRD-OMEGA',
        'mission_id': 'LOCAL-KERNEL-QUALIFICATION', 'scope_id': scope,
        'action': 'HTTP_POST', 'side_effect_class': 'EXTERNAL_COMMUNICATION',
        'parameters': params, 'approval_id': approval_data['approval_id'],
        'capability_token': cap_data['token'],
    }
    first = httpx.post(f'{BASE}/v1/tools/execute', headers=admin_headers(k), json=body, timeout=30)
    first.raise_for_status(); first_data = first.json()
    second = httpx.post(f'{BASE}/v1/tools/execute', headers=admin_headers(k), json=body, timeout=30)
    second.raise_for_status(); second_data = second.json()
    if first_data['status'] != 'READBACK_CONFIRMED' or second_data['status'] != 'HOLD_FOR_APPROVAL':
        raise RuntimeError(f'consequential/replay canary failed: first={first_data}; second={second_data}')
    return {'first': first_data, 'replay': second_data}


def main() -> None:
    DB.unlink(missing_ok=True)
    k = keys(); scope = 'PFRD-LOCAL-KERNEL-QUALIFICATION'; topology = compose_check()
    policy_process = start_server(env(k, 'POLICY_ONLY'))
    try:
        health_before = httpx.get(f'{BASE}/health').json()
        premature = canary(k, scope, 'PFRD hard-kernel mode is active.')
        false_migration = canary(k, scope, 'All tasks have been migrated.')
        benign = canary(k, scope, 'This is a bounded release-sealer canary.')
        if premature['decision'] == 'RELEASE_SEALED': raise RuntimeError('premature kernel claim released')
        if false_migration['decision'] == 'RELEASE_SEALED': raise RuntimeError('false migration claim released')
        if benign['decision'] != 'RELEASE_SEALED': raise RuntimeError(f'benign canary rejected: {benign}')
        read_only = tool_route(k, scope)
        consequential = consequential_route(k, scope)
        proof_payloads = {
            'ENFORCEMENT_SERVICE_DEPLOYMENT_RECEIPT': {'health': health_before},
            'TOOL_BROKER_ROUTE_TEST': {'read_only': read_only, 'consequential': consequential},
            'DIRECT_BYPASS_TEST': topology,
            'POLICY_ENGINE_HEALTH_RECEIPT': {'premature_blocked': premature['decision'], 'false_migration_blocked': false_migration['decision']},
            'PROOF_LEDGER_HEALTH_RECEIPT': {'proof_ids': [read_only['execution_proof_id'], read_only['readback_proof_id']]},
            'RELEASE_SEALER_CANARY': {'receipt': benign['release_receipt']},
        }
        proofs = [issue_proof(k, scope, ptype, payload) for ptype, payload in proof_payloads.items()]
        create_state(k, scope, [p['proof_id'] for p in proofs], 2)
    finally:
        stop_server(policy_process)

    qualified_process = start_server(env(k, 'LOCAL_KERNEL_QUALIFIED'))
    try:
        final_health = httpx.get(f'{BASE}/health').json()
        final = canary(k, scope, 'PFRD hard-kernel mode is active for the local qualification scope.')
        if final['decision'] != 'RELEASE_SEALED':
            raise RuntimeError(f'qualified kernel claim not sealed: {final}')
        receipt = {
            'receipt_id': f'local-kernel-{uuid.uuid4()}',
            'version': '2.1.0',
            'classification': 'LOCAL_KERNEL_QUALIFIED',
            'qualified_at': datetime.now(timezone.utc).isoformat(),
            'premature_kernel_claim_blocked': premature['decision'],
            'false_migration_claim_blocked': false_migration['decision'],
            'benign_release_receipt': benign['release_receipt'],
            'tool_broker_read_only': read_only['status'],
            'consequential_route': consequential['first']['status'],
            'replay_route': consequential['replay']['status'],
            'direct_bypass_topology': topology,
            'activation_proof_ids': [p['proof_id'] for p in proofs],
            'final_release_receipt': final['release_receipt'],
            'health': final_health,
            'not_claimed': [
                'KERNEL_ENFORCED on a deployed private network',
                'PRODUCTION_SEALED',
                'live OpenAI model execution',
                'cloud deployment',
            ],
        }
        RECEIPT.parent.mkdir(exist_ok=True)
        RECEIPT.write_text(json.dumps(receipt, indent=2, sort_keys=True))
        print(json.dumps(receipt, indent=2))
    finally:
        stop_server(qualified_process)


if __name__ == '__main__':
    main()
