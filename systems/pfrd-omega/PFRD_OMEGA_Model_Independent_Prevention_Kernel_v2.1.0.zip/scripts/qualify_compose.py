from __future__ import annotations

import hashlib
import json
import os
import secrets
import socket
import subprocess
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / '.env'
BASE = 'http://127.0.0.1:8080'
RECEIPT = ROOT / 'qualification' / 'compose_kernel_qualification_receipt.json'


def canonical_hash(value: dict) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()


def values(mode: str) -> dict[str, str]:
    return {
        'PFRD_PUBLIC_API_KEY': secrets.token_urlsafe(32),
        'PFRD_ADMIN_API_KEY': secrets.token_urlsafe(32),
        'PFRD_SERVICE_TOKEN': secrets.token_urlsafe(32),
        'PFRD_PROOF_SIGNING_KEY': secrets.token_urlsafe(48),
        'PFRD_APPROVAL_SIGNING_KEY': secrets.token_urlsafe(48),
        'PFRD_CAPABILITY_SIGNING_KEY': secrets.token_urlsafe(48),
        'PFRD_RELEASE_SIGNING_KEY': secrets.token_urlsafe(48),
        'DATABASE_URL': 'postgresql+psycopg://pfrd:pfrd@postgres:5432/pfrd',
        'OPENAI_API_KEY': '',
        'OPENAI_MODEL': 'gpt-5.6-sol',
        'OPENAI_REASONING_EFFORT': 'high',
        'PFRD_ACTIVATION_MODE': mode,
        'PFRD_POLICY_VERSION': '2.1.0',
        'PFRD_PROVIDER_ALLOWLIST': 'gateway,localhost,127.0.0.1',
        'PFRD_DEV_MODE': 'false',
        'PFRD_REQUIRE_OPA': 'true',
        'OPA_URL': 'http://opa:8181',
        'PFRD_DISTRIBUTED_MODE': 'true',
        'MODEL_ORCHESTRATOR_URL': 'http://model-orchestrator:8010',
        'CLAIM_COMPILER_URL': 'http://claim-compiler:8011',
        'PROOF_LEDGER_URL': 'http://proof-ledger:8012',
        'STATE_SERVICE_URL': 'http://state-service:8013',
        'ADVERSARIAL_VERIFIER_URL': 'http://adversarial-verifier:8014',
        'APPROVAL_SERVICE_URL': 'http://approval-service:8015',
        'CAPABILITY_SERVICE_URL': 'http://capability-service:8016',
        'PROVIDER_ADAPTER_URL': 'http://provider-adapter:8017',
        'TOOL_BROKER_URL': 'http://tool-broker:8018',
        'RELEASE_SEALER_URL': 'http://release-sealer:8019',
    }


def write_env(data: dict[str, str]) -> None:
    ENV_PATH.write_text('\n'.join(f'{k}={v}' for k, v in data.items()) + '\n')


def compose(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(['docker', 'compose', *args], cwd=ROOT, text=True, capture_output=True, check=check)


def wait_gateway(timeout: int = 180) -> dict:
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        try:
            response = httpx.get(f'{BASE}/health', timeout=5)
            if response.status_code == 200:
                body = response.json()
                if body.get('status') == 'ok':
                    return body
                last = body
        except Exception as exc:
            last = repr(exc)
        time.sleep(2)
    logs = compose('logs', '--tail=300', check=False).stdout
    raise RuntimeError(f'gateway not healthy: {last}\n{logs}')


def admin(env: dict[str, str]) -> dict[str, str]:
    return {'X-PFRD-Admin-Key': env['PFRD_ADMIN_API_KEY']}


def canary(env: dict[str, str], scope: str, text: str) -> dict:
    response = httpx.post(
        f'{BASE}/v1/admin/release-canary', headers=admin(env),
        json={
            'candidate_id': f'canary-{uuid.uuid4()}', 'scope_id': scope,
            'text': text, 'model': 'COMPOSE_QUALIFICATION_CANARY',
            'created_at': datetime.now(timezone.utc).isoformat(),
        }, timeout=60,
    )
    response.raise_for_status(); return response.json()


def proof(env: dict[str, str], scope: str, proof_type: str, payload: dict) -> dict:
    now = datetime.now(timezone.utc)
    response = httpx.post(
        f'{BASE}/v1/admin/proofs', headers=admin(env),
        json={
            'proof_type': proof_type, 'owner_id': 'KAGISO_KIM_MOSIANE',
            'matter_id': 'PFRD-OMEGA', 'mission_id': 'COMPOSE-KERNEL-QUALIFICATION',
            'scope_id': scope, 'subject_id': 'PFRD-OMEGA-KERNEL',
            'issuer_domain': 'CI_QUALIFICATION_RUNNER', 'provider_name': 'DOCKER_COMPOSE',
            'environment': 'CI', 'observed_at': now.isoformat(),
            'valid_from': now.isoformat(), 'expires_at': (now + timedelta(hours=24)).isoformat(),
            'independently_read_back': True, 'payload': payload,
        }, timeout=30,
    )
    response.raise_for_status(); return response.json()


def state(env: dict[str, str], scope: str, proof_ids: list[str], version: int) -> dict:
    response = httpx.post(
        f'{BASE}/v1/admin/state', headers=admin(env),
        json={
            'scope_id': scope, 'version': version,
            'lattice': {
                'definition_state': 'HASH_VERIFIED', 'source_state': 'HASH_MATCHED',
                'function_state': 'CANARY_PASSED', 'trigger_state': 'FIRED',
                'execution_state': 'TERMINAL_SUCCESS', 'result_state': 'RECONCILED',
                'verification_state': 'ADVERSARIAL_REVIEW_PASSED', 'legacy_state': 'READ_BACK',
                'duplicate_state': 'ZERO_DUPLICATES', 'rollback_state': 'RESTORE_CANARY_PASSED',
                'security_state': 'AUTHORIZATION_VERIFIED', 'provider_state': 'PROVIDER_CONFIRMED',
                'freshness_state': 'FRESH', 'environment_state': 'CI',
            },
            'proof_ids': proof_ids, 'updated_at': datetime.now(timezone.utc).isoformat(),
        }, timeout=30,
    )
    response.raise_for_status(); return response.json()


def broker_routes(env: dict[str, str], scope: str) -> dict:
    read_only = httpx.post(
        f'{BASE}/v1/tools/execute', headers=admin(env),
        json={
            'owner_id': 'KAGISO_KIM_MOSIANE', 'matter_id': 'PFRD-OMEGA',
            'mission_id': 'COMPOSE-KERNEL-QUALIFICATION', 'scope_id': scope,
            'action': 'HTTP_GET', 'side_effect_class': 'READ_ONLY',
            'parameters': {
                'url': 'http://gateway:8080/health', 'readback_url': 'http://gateway:8080/health',
                'idempotency_key': f'read-{uuid.uuid4()}',
            },
        }, timeout=60,
    ); read_only.raise_for_status(); read_data = read_only.json()
    if read_data['status'] != 'READBACK_CONFIRMED': raise RuntimeError(read_data)

    params = {
        'url': 'http://gateway:8080/v1/admin/release-canary',
        'readback_url': 'http://gateway:8080/health',
        'headers': admin(env),
        'json': {
            'candidate_id': f'provider-{uuid.uuid4()}', 'scope_id': 'PROVIDER-CANARY',
            'text': 'This is a bounded distributed provider canary.', 'model': 'PROVIDER_CANARY',
            'created_at': datetime.now(timezone.utc).isoformat(),
        },
        'idempotency_key': f'conseq-{uuid.uuid4()}',
    }
    expiry = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    approval = httpx.post(
        f'{BASE}/v1/approvals', headers=admin(env),
        json={
            'owner_id': 'KAGISO_KIM_MOSIANE', 'matter_id': 'PFRD-OMEGA',
            'mission_id': 'COMPOSE-KERNEL-QUALIFICATION', 'scope_id': scope,
            'action': 'HTTP_POST', 'side_effect_class': 'EXTERNAL_COMMUNICATION',
            'exact_parameters': params, 'expires_at': expiry,
        }, timeout=30,
    ); approval.raise_for_status(); approval_data = approval.json()
    capability = httpx.post(
        f'{BASE}/v1/capabilities', headers=admin(env),
        json={
            'approval_id': approval_data['approval_id'], 'matter_id': 'PFRD-OMEGA',
            'mission_id': 'COMPOSE-KERNEL-QUALIFICATION', 'scope_id': scope,
            'action': 'HTTP_POST', 'side_effect_class': 'EXTERNAL_COMMUNICATION',
            'exact_parameters_hash': canonical_hash(params), 'expires_at': expiry,
        }, timeout=30,
    ); capability.raise_for_status(); cap = capability.json()
    request = {
        'owner_id': 'KAGISO_KIM_MOSIANE', 'matter_id': 'PFRD-OMEGA',
        'mission_id': 'COMPOSE-KERNEL-QUALIFICATION', 'scope_id': scope,
        'action': 'HTTP_POST', 'side_effect_class': 'EXTERNAL_COMMUNICATION',
        'parameters': params, 'approval_id': approval_data['approval_id'],
        'capability_token': cap['token'],
    }
    first = httpx.post(f'{BASE}/v1/tools/execute', headers=admin(env), json=request, timeout=60)
    first.raise_for_status(); first_data = first.json()
    replay = httpx.post(f'{BASE}/v1/tools/execute', headers=admin(env), json=request, timeout=60)
    replay.raise_for_status(); replay_data = replay.json()
    if first_data['status'] != 'READBACK_CONFIRMED' or replay_data['status'] != 'HOLD_FOR_APPROVAL':
        raise RuntimeError({'first': first_data, 'replay': replay_data})
    return {'read_only': read_data, 'consequential': first_data, 'replay': replay_data}


def bypass_check() -> dict:
    config = json.loads(compose('config', '--format', 'json').stdout)
    exposed = {name: service.get('ports', []) for name, service in config['services'].items() if service.get('ports')}
    if set(exposed) != {'gateway'}:
        raise RuntimeError(f'unexpected exposed services: {exposed}')
    reachable: dict[str, bool] = {}
    for port in range(8010, 8020):
        sock = socket.socket(); sock.settimeout(0.3)
        try:
            reachable[str(port)] = sock.connect_ex(('127.0.0.1', port)) == 0
        finally:
            sock.close()
    if any(reachable.values()):
        raise RuntimeError(f'internal service host port reachable: {reachable}')
    return {'exposed_services': exposed, 'internal_host_ports': reachable, 'passed': True}


def main() -> None:
    scope = 'PFRD-COMPOSE-KERNEL-QUALIFICATION'
    env = values('POLICY_ONLY'); write_env(env)
    compose('down', '-v', '--remove-orphans', check=False)
    try:
        compose('up', '--build', '-d')
        health_before = wait_gateway()
        if health_before.get('model_key_present_in_gateway'):
            raise RuntimeError('OpenAI key is exposed to gateway')
        premature = canary(env, scope, 'PFRD hard-kernel mode is active.')
        migration = canary(env, scope, 'All tasks have been migrated.')
        benign = canary(env, scope, 'This is a bounded distributed release canary.')
        if premature['decision'] == 'RELEASE_SEALED' or migration['decision'] == 'RELEASE_SEALED':
            raise RuntimeError('prevention gate released a false completion claim')
        if benign['decision'] != 'RELEASE_SEALED': raise RuntimeError(benign)
        routes = broker_routes(env, scope)
        bypass = bypass_check()
        payloads = {
            'ENFORCEMENT_SERVICE_DEPLOYMENT_RECEIPT': {'health': health_before},
            'TOOL_BROKER_ROUTE_TEST': routes,
            'DIRECT_BYPASS_TEST': bypass,
            'POLICY_ENGINE_HEALTH_RECEIPT': {'opa': health_before['components'].get('opa')},
            'PROOF_LEDGER_HEALTH_RECEIPT': {'proofs': [routes['read_only']['execution_proof_id'], routes['read_only']['readback_proof_id']]},
            'RELEASE_SEALER_CANARY': {'receipt': benign['release_receipt']},
        }
        proofs = [proof(env, scope, ptype, payload) for ptype, payload in payloads.items()]
        state(env, scope, [item['proof_id'] for item in proofs], 2)
        env['PFRD_ACTIVATION_MODE'] = 'KERNEL_ENFORCED'; write_env(env)
        compose('up', '-d', '--force-recreate', 'gateway')
        health_after = wait_gateway()
        final = canary(env, scope, 'PFRD hard-kernel mode is active for the CI compose qualification scope.')
        if final['decision'] != 'RELEASE_SEALED': raise RuntimeError(final)
        RECEIPT.parent.mkdir(exist_ok=True)
        receipt = {
            'receipt_id': f'compose-kernel-{uuid.uuid4()}',
            'version': '2.1.0', 'classification': 'CI_DISTRIBUTED_KERNEL_QUALIFIED',
            'qualified_at': datetime.now(timezone.utc).isoformat(),
            'premature_claim': premature['decision'], 'false_migration': migration['decision'],
            'broker_routes': {'read_only': routes['read_only']['status'], 'consequential': routes['consequential']['status'], 'replay': routes['replay']['status']},
            'bypass': bypass, 'activation_proof_ids': [item['proof_id'] for item in proofs],
            'final_release_receipt': final['release_receipt'], 'health': health_after,
            'not_claimed': ['PRODUCTION_SEALED', 'live OpenAI model call', 'Cloud Run deployment'],
        }
        RECEIPT.write_text(json.dumps(receipt, indent=2, sort_keys=True))
        print(json.dumps(receipt, indent=2))
    finally:
        compose('logs', '--tail=300', check=False)
        compose('down', '-v', '--remove-orphans', check=False)


if __name__ == '__main__':
    main()
