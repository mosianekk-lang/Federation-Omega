package pfrd.release

default allow := false

allow if {
  count(input.contradictions) == 0
  count(input.contract_failures) == 0
  count(input.proof_failures) == 0
  input.parser_agreement == true
}

decision := "RELEASE_SEALED" if allow else := "REJECT_FALSE_CERTAINTY"

result := {
  "allow": allow,
  "decision": decision,
}
