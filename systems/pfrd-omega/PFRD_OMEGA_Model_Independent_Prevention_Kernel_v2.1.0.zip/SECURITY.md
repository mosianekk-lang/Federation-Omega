# Security boundaries

- Use distinct signing keys for proofs, approvals, capability tokens and releases.
- Keep `OPENAI_API_KEY` only in the model-orchestrator service or secret manager.
- Do not expose internal services publicly.
- Consequential provider operations require exact approval, exact parameter hash, a single-use capability token, provider execution proof and independent readback.
- A timeout after submission becomes `EXECUTION_UNCERTAIN`; automatic retry is forbidden.
- Present-tense operational claims require fresh, unexpired provider evidence.
- Production must replace development HMAC secrets with managed keys and service identities.
