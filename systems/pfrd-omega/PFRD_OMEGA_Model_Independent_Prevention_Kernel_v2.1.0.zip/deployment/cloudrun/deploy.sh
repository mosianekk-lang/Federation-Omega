#!/usr/bin/env bash
set -euo pipefail
: "${GOOGLE_CLOUD_PROJECT:?Set GOOGLE_CLOUD_PROJECT}"
REGION="${GOOGLE_CLOUD_REGION:-africa-south1}"
REPOSITORY="${PFRD_ARTIFACT_REPOSITORY:-pfrd-omega}"
IMAGE="${REGION}-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/${REPOSITORY}/pfrd-omega:2.1.0"

gcloud artifacts repositories describe "$REPOSITORY" --location "$REGION" >/dev/null 2>&1 || \
  gcloud artifacts repositories create "$REPOSITORY" --repository-format docker --location "$REGION"
gcloud builds submit --tag "$IMAGE" .

cat <<MSG
Image built: $IMAGE
Deploy gateway publicly only after Cloud SQL, Secret Manager, service identities,
private internal services and OPA are configured. Run the deployment qualification
workflow before promoting from POLICY_ONLY to KERNEL_ENFORCED.
MSG
