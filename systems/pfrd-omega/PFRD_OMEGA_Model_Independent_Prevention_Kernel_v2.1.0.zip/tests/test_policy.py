from datetime import datetime, timedelta, timezone

from pfrd.models import CandidateOutput, Claim, ProofRecord, StateLattice, StateRecord
from pfrd.policy import evaluate


def claim(predicate: str, polarity: str = 'POSITIVE', speaker: str = 'ASSISTANT_ASSERTION') -> Claim:
    return Claim(claim_id='cl', candidate_id='c', sentence_index=0, text=predicate, speaker=speaker, predicate=predicate, polarity=polarity, modality='ASSERTED', tense='PRESENT', scope_id='scope')


def state(**kwargs) -> StateRecord:
    return StateRecord(scope_id='scope', version=1, lattice=StateLattice(**kwargs), proof_ids=[], updated_at=datetime.now(timezone.utc))


def proof(proof_type: str, expired: bool = False) -> ProofRecord:
    now = datetime.now(timezone.utc)
    return ProofRecord(
        proof_id=f'p-{proof_type}', proof_type=proof_type, owner_id='o', matter_id='m', mission_id='mi', scope_id='scope', subject_id='s', issuer_domain='TEST', provider_name='test', environment='CI', observed_at=now, issued_at=now, valid_from=now, expires_at=(now - timedelta(minutes=1) if expired else now + timedelta(hours=1)), independently_read_back=True, payload={'ok': True}, payload_hash='x'*64, proof_hash='y'*64, signature='sig', verification_state='VALID'
    )


def test_registry_not_migration():
    result = evaluate(claims=[claim('MIGRATED')], state=state(definition_state='HASH_VERIFIED', source_state='STAGED'), proofs=[], activation_mode='POLICY_ONLY')
    assert result.decision.value == 'RELEASE_BLOCKED_CONTRADICTION'


def test_trigger_not_execution():
    result = evaluate(claims=[claim('FULLY_AUTOMATED')], state=state(trigger_state='READ_BACK', result_state='UNKNOWN', freshness_state='FRESH'), proofs=[], activation_mode='POLICY_ONLY')
    assert result.decision.value == 'RELEASE_BLOCKED_CONTRADICTION'


def test_external_effect_without_readback():
    result = evaluate(claims=[claim('EXTERNAL_ACTION_COMPLETED')], state=state(provider_state='UNKNOWN', result_state='UNKNOWN'), proofs=[], activation_mode='POLICY_ONLY')
    assert result.decision.value == 'RELEASE_BLOCKED_CONTRADICTION'


def test_stale_proof_holds():
    result = evaluate(claims=[], state=state(), proofs=[proof('HEALTH', expired=True)], activation_mode='POLICY_ONLY')
    assert result.decision.value == 'HOLD_FOR_FRESH_PROOF'


def test_negated_claim_does_not_block():
    result = evaluate(claims=[claim('MIGRATED', polarity='NEGATIVE')], state=state(), proofs=[], activation_mode='POLICY_ONLY')
    assert result.allow


def test_quoted_claim_does_not_block():
    result = evaluate(claims=[claim('MIGRATED', speaker='SOURCE_QUOTATION')], state=state(), proofs=[], activation_mode='POLICY_ONLY')
    assert result.allow
