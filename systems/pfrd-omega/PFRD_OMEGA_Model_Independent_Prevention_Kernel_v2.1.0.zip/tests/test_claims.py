from datetime import datetime, timezone

from pfrd.claims import compile_claims
from pfrd.models import CandidateOutput


def candidate(text: str, scope: str = 'scope') -> CandidateOutput:
    return CandidateOutput(candidate_id='c', scope_id=scope, text=text, model='test', created_at=datetime.now(timezone.utc))


def test_positive_migration_detected():
    claims = compile_claims(candidate('All tasks have been migrated.'))
    assert any(c.predicate == 'MIGRATED' and c.polarity == 'POSITIVE' for c in claims)


def test_negated_completion_not_positive():
    claims = compile_claims(candidate('The migration is not complete.'))
    assert claims and all(c.polarity != 'POSITIVE' for c in claims)


def test_quoted_completion_not_assistant_assertion():
    claims = compile_claims(candidate('The report stated “migration complete”.'))
    assert claims and all(c.speaker != 'ASSISTANT_ASSERTION' for c in claims)


def test_blockquote_not_assistant_assertion():
    claims = compile_claims(candidate('> The migration is complete.'))
    assert claims and all(c.speaker == 'SOURCE_QUOTATION' for c in claims)


def test_code_literal_not_assistant_assertion():
    claims = compile_claims(candidate('```\nstatus = "active"\n```'))
    assert claims and all(c.speaker == 'CODE_LITERAL' for c in claims)


def test_conditional_not_positive():
    claims = compile_claims(candidate('The migration could be complete after verification.'))
    assert claims and all(c.polarity == 'CONDITIONAL' for c in claims)


def test_inactive_not_active_claim():
    claims = compile_claims(candidate('The service is inactive.'))
    assert not any(c.predicate == 'ACTIVE' for c in claims)


def test_kernel_active_detected():
    claims = compile_claims(candidate('PFRD hard-kernel mode is active.'))
    assert any(c.predicate == 'KERNEL_ACTIVE' for c in claims)


def test_external_send_detected():
    claims = compile_claims(candidate('The email was sent.'))
    assert any(c.predicate == 'EXTERNAL_ACTION_COMPLETED' for c in claims)


def test_absence_detected():
    claims = compile_claims(candidate('Three attachments are missing.'))
    assert any(c.predicate == 'ADVERSE_ABSENCE' for c in claims)
