from datetime import datetime, timedelta, timezone

from pfrd.config import get_settings
from pfrd.contracts import KERNEL_REQUIRED
from pfrd.db import reset_db_for_tests
from pfrd.kernel import PreventionKernel
from pfrd.models import ProofCreate, StateLattice, StateRecord
from pfrd.store import Store


def setup_function():
    reset_db_for_tests()
    get_settings.cache_clear()


def test_benign_candidate_sealed():
    kernel=PreventionKernel(Store())
    candidate=kernel.candidate_from_text(scope_id='s',text='This is a bounded canary with no completion claim.')
    result=kernel.release(candidate)
    assert result.decision.value=='RELEASE_SEALED'
    assert result.release_receipt is not None


def test_false_migration_blocked():
    kernel=PreventionKernel(Store())
    candidate=kernel.candidate_from_text(scope_id='s',text='All tasks have been migrated.')
    result=kernel.release(candidate)
    assert result.output is None
    assert result.decision.value=='RELEASE_BLOCKED_CONTRADICTION'


def test_policy_only_kernel_claim_blocked():
    kernel=PreventionKernel(Store())
    candidate=kernel.candidate_from_text(scope_id='s',text='PFRD hard-kernel mode is active.')
    result=kernel.release(candidate)
    assert result.output is None


def test_kernel_claim_passes_with_proofs_and_state(monkeypatch):
    monkeypatch.setenv('PFRD_ACTIVATION_MODE','LOCAL_KERNEL_QUALIFIED')
    get_settings.cache_clear()
    store=Store(); now=datetime.now(timezone.utc); proof_ids=[]
    for ptype in KERNEL_REQUIRED:
        p=store.issue_proof(ProofCreate(proof_type=ptype,owner_id='o',matter_id='m',mission_id='mi',scope_id='s',subject_id='kernel',issuer_domain='QUALIFIER',provider_name='local',environment='LOCAL',observed_at=now,valid_from=now,expires_at=now+timedelta(hours=1),independently_read_back=True,payload={'ok':True}))
        proof_ids.append(p.proof_id)
    store.set_state(StateRecord(scope_id='s',version=2,lattice=StateLattice(result_state='RECONCILED',provider_state='PROVIDER_CONFIRMED',freshness_state='FRESH'),proof_ids=proof_ids,updated_at=now))
    kernel=PreventionKernel(store)
    result=kernel.release(kernel.candidate_from_text(scope_id='s',text='PFRD hard-kernel mode is active for this scope.'))
    assert result.decision.value=='RELEASE_SEALED'
    get_settings.cache_clear()
