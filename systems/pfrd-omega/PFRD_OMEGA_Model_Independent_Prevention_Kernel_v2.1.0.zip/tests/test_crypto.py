from pfrd.crypto import decode_token, encode_token, merkle_root, sha256_hex, sign, verify


def test_signature_roundtrip():
    payload = {'a': 1}
    signature = sign('secret', payload)
    assert verify('secret', payload, signature)
    assert not verify('other', payload, signature)


def test_token_roundtrip():
    payload = {'scope_id': 's'}
    token = encode_token(payload, 'key')
    assert decode_token(token, 'key') == payload


def test_token_tamper_rejected():
    token = encode_token({'scope_id': 's'}, 'key')
    encoded, signature = token.split('.', 1)
    try:
        decode_token(encoded + 'A.' + signature, 'key')
    except Exception:
        pass
    else:
        raise AssertionError('tampered token accepted')


def test_merkle_changes():
    assert merkle_root([sha256_hex('a'), sha256_hex('b')]) != merkle_root([sha256_hex('a'), sha256_hex('c')])
