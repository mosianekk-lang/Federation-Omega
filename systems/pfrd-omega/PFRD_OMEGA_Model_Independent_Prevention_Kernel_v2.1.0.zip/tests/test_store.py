from datetime import datetime, timedelta, timezone

import pytest

from pfrd.crypto import sha256_hex
from pfrd.db import reset_db_for_tests
from pfrd.models import ApprovalCreate, ProofCreate, SideEffectClass, StateLattice, StateRecord
from pfrd.store import Store


def setup_function():
    reset_db_for_tests()


def test_proof_chain_and_integrity():
    store = Store(); now = datetime.now(timezone.utc)
    first = store.issue_proof(ProofCreate(proof_type='A', owner_id='o', matter_id='m', mission_id='mi', scope_id='s', subject_id='x', issuer_domain='TEST', provider_name='test', environment='CI', observed_at=now, valid_from=now, payload={'a':1}))
    second = store.issue_proof(ProofCreate(proof_type='B', owner_id='o', matter_id='m', mission_id='mi', scope_id='s', subject_id='x', issuer_domain='TEST', provider_name='test', environment='CI', observed_at=now, valid_from=now, payload={'b':2}))
    assert second.previous_proof_hash == first.proof_hash
    assert store.verify_proof_integrity(first)
    count, root = store.proof_root()
    assert count == 2 and len(root) == 64


def test_state_version_guard():
    store=Store(); now=datetime.now(timezone.utc)
    store.set_state(StateRecord(scope_id='s',version=2,lattice=StateLattice(),proof_ids=[],updated_at=now))
    with pytest.raises(ValueError):
        store.set_state(StateRecord(scope_id='s',version=2,lattice=StateLattice(),proof_ids=[],updated_at=now))


def test_exact_approval_match_and_consume():
    store=Store(); now=datetime.now(timezone.utc); params={'to':'a@example.com'}
    approval=store.create_approval(ApprovalCreate(owner_id='o',matter_id='m',mission_id='mi',scope_id='s',action='SEND',side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,exact_parameters=params,expires_at=now+timedelta(hours=1)))
    verified=store.verify_approval(approval.approval_id,sha256_hex(params))
    assert verified.state=='APPROVED'
    consumed=store.verify_approval(approval.approval_id,sha256_hex(params),consume=True)
    assert consumed.state=='CONSUMED'
    with pytest.raises(ValueError): store.verify_approval(approval.approval_id,sha256_hex(params))


def test_approval_mismatch_rejected():
    store=Store(); now=datetime.now(timezone.utc)
    approval=store.create_approval(ApprovalCreate(owner_id='o',matter_id='m',mission_id='mi',scope_id='s',action='SEND',side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,exact_parameters={'x':1},expires_at=now+timedelta(hours=1)))
    with pytest.raises(ValueError): store.verify_approval(approval.approval_id,sha256_hex({'x':2}))


def test_capability_replay_blocked():
    store=Store()
    store.mark_capability_used('token-1','idem-1')
    with pytest.raises(ValueError): store.mark_capability_used('token-1','idem-2')
    with pytest.raises(ValueError): store.mark_capability_used('token-2','idem-1')
