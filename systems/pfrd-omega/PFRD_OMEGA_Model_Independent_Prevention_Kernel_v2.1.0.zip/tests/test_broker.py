from datetime import datetime, timedelta, timezone

import httpx

import pfrd.broker as broker_module
from pfrd.broker import ToolBroker
from pfrd.capabilities import issue
from pfrd.config import get_settings
from pfrd.crypto import sha256_hex
from pfrd.db import reset_db_for_tests
from pfrd.models import ApprovalCreate, CapabilityRequest, SideEffectClass, ToolRequest
from pfrd.store import Store


def setup_function():
    reset_db_for_tests()
    get_settings.cache_clear()


def fake_execute(action, parameters, idempotency_key):
    return {
        'execution_id': 'exec-1',
        'provider_resource_id': 'resource-1',
        'status_code': 200,
        'response_hash': 'a' * 64,
        'response_text': 'ok',
        'idempotency_key': idempotency_key,
    }


def fake_readback(action, parameters, execution_id):
    return {
        'execution_id': execution_id,
        'status_code': 200,
        'readback_hash': 'b' * 64,
        'readback_text': 'ok',
        'provider_confirmed': True,
    }


def request(side_effect, params, approval_id=None, token=None):
    return ToolRequest(
        owner_id='o', matter_id='m', mission_id='mi', scope_id='s', action='HTTP_POST',
        side_effect_class=side_effect, parameters=params, approval_id=approval_id,
        capability_token=token,
    )


def test_read_only_route_needs_no_approval(monkeypatch):
    monkeypatch.setattr(broker_module, 'provider_execute', fake_execute)
    monkeypatch.setattr(broker_module, 'provider_readback', fake_readback)
    result = ToolBroker(Store()).execute(request(SideEffectClass.READ_ONLY, {'url': 'http://localhost'}))
    assert result.status == 'READBACK_CONFIRMED'


def test_consequential_route_requires_approval(monkeypatch):
    monkeypatch.setattr(broker_module, 'provider_execute', fake_execute)
    monkeypatch.setattr(broker_module, 'provider_readback', fake_readback)
    result = ToolBroker(Store()).execute(request(SideEffectClass.EXTERNAL_COMMUNICATION, {'url': 'http://localhost'}))
    assert result.status == 'HOLD_FOR_APPROVAL'


def test_exact_approval_and_token_route(monkeypatch):
    monkeypatch.setattr(broker_module, 'provider_execute', fake_execute)
    monkeypatch.setattr(broker_module, 'provider_readback', fake_readback)
    store = Store(); now = datetime.now(timezone.utc)
    params = {'url': 'http://localhost', 'idempotency_key': 'idem-success'}
    approval = store.create_approval(ApprovalCreate(
        owner_id='o', matter_id='m', mission_id='mi', scope_id='s', action='HTTP_POST',
        side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,
        exact_parameters=params, expires_at=now + timedelta(hours=1),
    ))
    token = issue(CapabilityRequest(
        approval_id=approval.approval_id, matter_id='m', mission_id='mi', scope_id='s',
        action='HTTP_POST', side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,
        exact_parameters_hash=sha256_hex(params), expires_at=now + timedelta(hours=1),
    ))
    result = ToolBroker(store).execute(request(
        SideEffectClass.EXTERNAL_COMMUNICATION, params, approval.approval_id, token.token
    ))
    assert result.status == 'READBACK_CONFIRMED'
    assert result.execution_proof_id and result.readback_proof_id


def test_capability_replay_blocked_before_provider(monkeypatch):
    calls = {'count': 0}
    def count_execute(action, parameters, idempotency_key):
        calls['count'] += 1
        return fake_execute(action, parameters, idempotency_key)
    monkeypatch.setattr(broker_module, 'provider_execute', count_execute)
    monkeypatch.setattr(broker_module, 'provider_readback', fake_readback)
    store = Store(); now = datetime.now(timezone.utc)
    params = {'url': 'http://localhost', 'idempotency_key': 'idem-replay'}
    approval = store.create_approval(ApprovalCreate(
        owner_id='o', matter_id='m', mission_id='mi', scope_id='s', action='HTTP_POST',
        side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,
        exact_parameters=params, expires_at=now + timedelta(hours=1),
    ))
    token = issue(CapabilityRequest(
        approval_id=approval.approval_id, matter_id='m', mission_id='mi', scope_id='s',
        action='HTTP_POST', side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,
        exact_parameters_hash=sha256_hex(params), expires_at=now + timedelta(hours=1),
    ))
    broker = ToolBroker(store)
    first = broker.execute(request(SideEffectClass.EXTERNAL_COMMUNICATION, params, approval.approval_id, token.token))
    second = broker.execute(request(SideEffectClass.EXTERNAL_COMMUNICATION, params, approval.approval_id, token.token))
    assert first.status == 'READBACK_CONFIRMED'
    assert second.status == 'HOLD_FOR_APPROVAL'
    assert calls['count'] == 1


def test_timeout_becomes_uncertain_and_authority_cannot_replay(monkeypatch):
    calls = {'count': 0}
    def timeout_execute(action, parameters, idempotency_key):
        calls['count'] += 1
        raise httpx.TimeoutException('timeout')
    monkeypatch.setattr(broker_module, 'provider_execute', timeout_execute)
    store = Store(); now = datetime.now(timezone.utc)
    params = {'url': 'http://localhost', 'idempotency_key': 'idem-timeout'}
    approval = store.create_approval(ApprovalCreate(
        owner_id='o', matter_id='m', mission_id='mi', scope_id='s', action='HTTP_POST',
        side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,
        exact_parameters=params, expires_at=now + timedelta(hours=1),
    ))
    token = issue(CapabilityRequest(
        approval_id=approval.approval_id, matter_id='m', mission_id='mi', scope_id='s',
        action='HTTP_POST', side_effect_class=SideEffectClass.EXTERNAL_COMMUNICATION,
        exact_parameters_hash=sha256_hex(params), expires_at=now + timedelta(hours=1),
    ))
    broker = ToolBroker(store)
    first = broker.execute(request(SideEffectClass.EXTERNAL_COMMUNICATION, params, approval.approval_id, token.token))
    second = broker.execute(request(SideEffectClass.EXTERNAL_COMMUNICATION, params, approval.approval_id, token.token))
    assert first.status == 'EXECUTION_UNCERTAIN'
    assert second.status == 'HOLD_FOR_APPROVAL'
    assert calls['count'] == 1
