from fastapi.testclient import TestClient

from pfrd.db import reset_db_for_tests
from services.gateway import app


def setup_function(): reset_db_for_tests()


def test_health():
    response=TestClient(app).get('/health')
    assert response.status_code==200
    assert response.json()['sole_public_release_route'] is True


def test_admin_auth_required():
    response=TestClient(app).get('/v1/admin/state/s')
    assert response.status_code==401


def test_canary_false_claim_blocked():
    response=TestClient(app).post('/v1/admin/release-canary',headers={'X-PFRD-Admin-Key':'test-admin-key-123456789012345678901'},json={'candidate_id':'c','scope_id':'s','text':'All tasks have been migrated.','model':'test','created_at':'2026-07-29T08:00:00Z'})
    assert response.status_code==200
    assert response.json()['decision']=='RELEASE_BLOCKED_CONTRADICTION'


def test_answer_without_model_key_is_bounded():
    response=TestClient(app).post('/v1/answer',headers={'X-PFRD-API-Key':'test-public-key-12345678901234567890'},json={'message':'hello','scope_id':'s','context':[]})
    assert response.status_code==503
    assert 'OPENAI_API_KEY' in response.json()['detail']
