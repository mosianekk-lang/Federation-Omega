import os
from pathlib import Path

TEST_DB = Path('/tmp/pfrd-omega-test.db')
try:
    TEST_DB.unlink()
except FileNotFoundError:
    pass

os.environ.setdefault('DATABASE_URL', f'sqlite+pysqlite:///{TEST_DB}')
os.environ.setdefault('PFRD_PUBLIC_API_KEY', 'test-public-key-12345678901234567890')
os.environ.setdefault('PFRD_ADMIN_API_KEY', 'test-admin-key-123456789012345678901')
os.environ.setdefault('PFRD_SERVICE_TOKEN', 'test-service-token-1234567890123456')
os.environ.setdefault('PFRD_PROOF_SIGNING_KEY', 'test-proof-signing-key-1234567890123')
os.environ.setdefault('PFRD_APPROVAL_SIGNING_KEY', 'test-approval-signing-key-123456789')
os.environ.setdefault('PFRD_CAPABILITY_SIGNING_KEY', 'test-capability-signing-key-123456')
os.environ.setdefault('PFRD_RELEASE_SIGNING_KEY', 'test-release-signing-key-123456789')
os.environ.setdefault('PFRD_ACTIVATION_MODE', 'POLICY_ONLY')
os.environ.setdefault('PFRD_PROVIDER_ALLOWLIST', 'localhost,127.0.0.1')
