from __future__ import annotations

import uuid

from pfrd.models import Claim, Contradiction, StateRecord


def _critical(claim: Claim, reason: str) -> Contradiction:
    return Contradiction(
        contradiction_id=f"contra-{uuid.uuid4()}",
        claim_id=claim.claim_id,
        severity="CRITICAL",
        reason=reason,
    )


def verify_claims(claims: list[Claim], state: StateRecord) -> list[Contradiction]:
    contradictions: list[Contradiction] = []
    lattice = state.lattice
    for claim in claims:
        if claim.speaker != "ASSISTANT_ASSERTION" or claim.polarity != "POSITIVE":
            continue
        if claim.parser_agreement != "AGREED":
            contradictions.append(_critical(claim, "claim parser disagreement"))
            continue
        if claim.predicate == "MIGRATED":
            expectations = {
                "definition_state": "HASH_VERIFIED",
                "source_state": "HASH_MATCHED",
                "function_state": "CANARY_PASSED",
                "trigger_state": "FIRED",
                "execution_state": "TERMINAL_SUCCESS",
                "result_state": "RECONCILED",
                "verification_state": "ADVERSARIAL_REVIEW_PASSED",
                "legacy_state": "READ_BACK",
                "duplicate_state": "ZERO_DUPLICATES",
                "rollback_state": "RESTORE_CANARY_PASSED",
                "freshness_state": "FRESH",
            }
            for field, expected in expectations.items():
                actual = getattr(lattice, field)
                if actual != expected:
                    contradictions.append(_critical(claim, f"{field}: expected {expected}; observed {actual}"))
        elif claim.predicate == "DEPLOYED":
            if lattice.environment_state != "PRODUCTION":
                contradictions.append(_critical(claim, "environment is not PRODUCTION"))
            if lattice.security_state != "PRODUCTION_CONTROLS_VERIFIED":
                contradictions.append(_critical(claim, "production security controls are unverified"))
            if lattice.freshness_state != "FRESH":
                contradictions.append(_critical(claim, "deployment proof is not fresh"))
        elif claim.predicate in {"ACTIVE", "FULLY_AUTOMATED"}:
            if lattice.result_state != "RECONCILED":
                contradictions.append(_critical(claim, "operational result is not reconciled"))
            if lattice.freshness_state != "FRESH":
                contradictions.append(_critical(claim, "current-state proof is not fresh"))
        elif claim.predicate == "EXTERNAL_ACTION_COMPLETED":
            if lattice.provider_state != "PROVIDER_CONFIRMED":
                contradictions.append(_critical(claim, "provider confirmation is absent"))
            if lattice.result_state != "RECONCILED":
                contradictions.append(_critical(claim, "provider readback is unreconciled"))
        elif claim.predicate == "COMPLETE" and not claim.scope_id:
            contradictions.append(_critical(claim, "completion scope is missing"))
    return contradictions
