from __future__ import annotations

from dataclasses import dataclass, field

import httpx

from pfrd.config import get_settings
from pfrd.contracts import contract_failures, proof_failures
from pfrd.models import Claim, Contradiction, Decision, ProofRecord, StateRecord
from pfrd.verifier import verify_claims


@dataclass
class PolicyResult:
    decision: Decision
    reasons: list[str] = field(default_factory=list)
    contradictions: list[Contradiction] = field(default_factory=list)

    @property
    def allow(self) -> bool:
        return self.decision == Decision.RELEASE_SEALED


def _opa_check(*, contradictions: list[Contradiction], contracts: list[str], proof_errors: list[str], claims: list[Claim]) -> list[str]:
    settings = get_settings()
    if not settings.pfrd_require_opa:
        return []
    if not settings.opa_url:
        return ["external OPA policy service is required but OPA_URL is unset"]
    payload = {
        "input": {
            "contradictions": [item.model_dump(mode="json") for item in contradictions],
            "contract_failures": contracts,
            "proof_failures": proof_errors,
            "parser_agreement": all(c.parser_agreement == "AGREED" for c in claims),
        }
    }
    try:
        response = httpx.post(
            f"{settings.opa_url.rstrip('/')}/v1/data/pfrd/release/result",
            json=payload,
            timeout=10,
        )
        response.raise_for_status()
        result = response.json().get("result", {})
    except Exception as exc:
        return [f"external OPA policy service unavailable: {type(exc).__name__}"]
    if not result.get("allow", False):
        return ["external OPA policy denied release"]
    return []


def evaluate(
    *, claims: list[Claim], state: StateRecord, proofs: list[ProofRecord], activation_mode: str
) -> PolicyResult:
    contradictions = verify_claims(claims, state)
    semantic = [f"parser disagreement for {c.claim_id}" for c in claims if c.parser_agreement != "AGREED"]
    contracts = contract_failures(claims, state, proofs, activation_mode)
    proof_errors = proof_failures(proofs)
    if semantic:
        return PolicyResult(Decision.HOLD_FOR_SEMANTIC_REVIEW, semantic, contradictions)
    if contradictions:
        return PolicyResult(
            Decision.RELEASE_BLOCKED_CONTRADICTION,
            [item.reason for item in contradictions],
            contradictions,
        )
    if proof_errors:
        expired = any("expired" in item for item in proof_errors)
        return PolicyResult(
            Decision.HOLD_FOR_FRESH_PROOF if expired else Decision.HOLD_FOR_EVIDENCE,
            proof_errors,
            contradictions,
        )
    if contracts:
        return PolicyResult(Decision.REJECT_FALSE_CERTAINTY, contracts, contradictions)
    opa_failures = _opa_check(
        contradictions=contradictions,
        contracts=contracts,
        proof_errors=proof_errors,
        claims=claims,
    )
    if opa_failures:
        return PolicyResult(Decision.CAPABILITY_SUSPENDED, opa_failures, contradictions)
    return PolicyResult(Decision.RELEASE_SEALED, [], contradictions)
