from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import select

from pfrd.config import get_settings
from pfrd.crypto import merkle_root, sha256_hex, sign, verify
from pfrd.db import ApprovalRow, CapabilityUseRow, IncidentRow, ProofRow, ReleaseRow, SessionLocal, StateRow, init_db
from pfrd.models import ApprovalCreate, ApprovalRecord, ProofCreate, ProofRecord, ReleaseReceipt, StateLattice, StateRecord


class Store:
    def __init__(self) -> None:
        init_db()

    @staticmethod
    def _proof_model(row: ProofRow) -> ProofRecord:
        return ProofRecord(
            proof_id=row.proof_id,
            proof_type=row.proof_type,
            owner_id=row.owner_id,
            matter_id=row.matter_id,
            mission_id=row.mission_id,
            scope_id=row.scope_id,
            subject_id=row.subject_id,
            issuer_domain=row.issuer_domain,
            provider_name=row.provider_name,
            provider_resource_id=row.provider_resource_id,
            provider_execution_id=row.provider_execution_id,
            environment=row.environment,
            observed_at=row.observed_at,
            issued_at=row.issued_at,
            valid_from=row.valid_from,
            expires_at=row.expires_at,
            independently_read_back=row.independently_read_back,
            payload=row.payload_json,
            payload_hash=row.payload_hash,
            previous_proof_hash=row.previous_proof_hash,
            proof_hash=row.proof_hash,
            signature=row.signature,
            verification_state=row.verification_state,
        )

    def issue_proof(self, request: ProofCreate) -> ProofRecord:
        now = datetime.now(timezone.utc)
        proof_id = f"proof-{uuid.uuid4()}"
        with SessionLocal() as session:
            previous = session.scalars(select(ProofRow).order_by(ProofRow.issued_at.desc()).limit(1)).first()
            previous_hash = previous.proof_hash if previous else None
            payload_hash = sha256_hex(request.payload)
            unsigned = {
                **request.model_dump(mode="json"),
                "proof_id": proof_id,
                "issued_at": now.isoformat(),
                "payload_hash": payload_hash,
                "previous_proof_hash": previous_hash,
            }
            proof_hash = sha256_hex(unsigned)
            signature = sign(get_settings().pfrd_proof_signing_key, {"proof_id": proof_id, "proof_hash": proof_hash})
            row = ProofRow(
                proof_id=proof_id,
                proof_type=request.proof_type,
                owner_id=request.owner_id,
                matter_id=request.matter_id,
                mission_id=request.mission_id,
                scope_id=request.scope_id,
                subject_id=request.subject_id,
                issuer_domain=request.issuer_domain,
                provider_name=request.provider_name,
                provider_resource_id=request.provider_resource_id,
                provider_execution_id=request.provider_execution_id,
                environment=request.environment,
                observed_at=request.observed_at,
                issued_at=now,
                valid_from=request.valid_from,
                expires_at=request.expires_at,
                independently_read_back=request.independently_read_back,
                payload_json=request.payload,
                payload_hash=payload_hash,
                previous_proof_hash=previous_hash,
                proof_hash=proof_hash,
                signature=signature,
                verification_state="VALID",
            )
            session.add(row)
            session.commit()
            session.refresh(row)
            return self._proof_model(row)

    def verify_proof_integrity(self, proof: ProofRecord) -> bool:
        if sha256_hex(proof.payload) != proof.payload_hash:
            return False
        return verify(
            get_settings().pfrd_proof_signing_key,
            {"proof_id": proof.proof_id, "proof_hash": proof.proof_hash},
            proof.signature,
        )

    def get_proofs(self, *, scope_id: str | None = None, ids: list[str] | None = None) -> list[ProofRecord]:
        with SessionLocal() as session:
            query = select(ProofRow)
            if scope_id:
                query = query.where(ProofRow.scope_id == scope_id)
            if ids:
                query = query.where(ProofRow.proof_id.in_(ids))
            rows = session.scalars(query.order_by(ProofRow.issued_at.asc())).all()
            return [self._proof_model(row) for row in rows]

    def proof_root(self) -> tuple[int, str]:
        with SessionLocal() as session:
            hashes = list(session.scalars(select(ProofRow.proof_hash).order_by(ProofRow.issued_at.asc())).all())
        return len(hashes), merkle_root(hashes)

    def get_state(self, scope_id: str) -> StateRecord:
        with SessionLocal() as session:
            row = session.get(StateRow, scope_id)
            if row is None:
                now = datetime.now(timezone.utc)
                record = StateRecord(scope_id=scope_id, version=1, lattice=StateLattice(), proof_ids=[], updated_at=now)
                session.add(StateRow(scope_id=scope_id, version=1, lattice_json=record.lattice.model_dump(), proof_ids_json=[], updated_at=now))
                session.commit()
                return record
            return StateRecord(
                scope_id=row.scope_id,
                version=row.version,
                lattice=StateLattice.model_validate(row.lattice_json),
                proof_ids=list(row.proof_ids_json or []),
                updated_at=row.updated_at,
            )

    def set_state(self, record: StateRecord) -> StateRecord:
        with SessionLocal() as session:
            row = session.get(StateRow, record.scope_id)
            if row and record.version <= row.version:
                raise ValueError(f"state version must be greater than {row.version}")
            if row:
                row.version = record.version
                row.lattice_json = record.lattice.model_dump()
                row.proof_ids_json = record.proof_ids
                row.updated_at = record.updated_at
            else:
                session.add(StateRow(
                    scope_id=record.scope_id,
                    version=record.version,
                    lattice_json=record.lattice.model_dump(),
                    proof_ids_json=record.proof_ids,
                    updated_at=record.updated_at,
                ))
            session.commit()
        return record

    def create_approval(self, request: ApprovalCreate) -> ApprovalRecord:
        now = datetime.now(timezone.utc)
        if request.expires_at <= now:
            raise ValueError("approval expiry must be in the future")
        approval_id = f"approval-{uuid.uuid4()}"
        parameter_hash = sha256_hex(request.exact_parameters)
        nonce = str(uuid.uuid4())
        unsigned = {
            "approval_id": approval_id,
            "owner_id": request.owner_id,
            "matter_id": request.matter_id,
            "mission_id": request.mission_id,
            "scope_id": request.scope_id,
            "action": request.action,
            "side_effect_class": request.side_effect_class,
            "parameter_hash": parameter_hash,
            "nonce": nonce,
            "expires_at": request.expires_at.isoformat(),
        }
        signature = sign(get_settings().pfrd_approval_signing_key, unsigned)
        with SessionLocal() as session:
            session.add(ApprovalRow(
                approval_id=approval_id,
                owner_id=request.owner_id,
                matter_id=request.matter_id,
                mission_id=request.mission_id,
                scope_id=request.scope_id,
                action=request.action,
                side_effect_class=request.side_effect_class,
                exact_parameters_json=request.exact_parameters,
                parameter_hash=parameter_hash,
                nonce=nonce,
                signature=signature,
                state="APPROVED",
                created_at=now,
                expires_at=request.expires_at,
            ))
            session.commit()
        return ApprovalRecord(
            **request.model_dump(),
            approval_id=approval_id,
            parameter_hash=parameter_hash,
            nonce=nonce,
            signature=signature,
            state="APPROVED",
            created_at=now,
        )

    def verify_approval(self, approval_id: str, parameter_hash: str, *, consume: bool = False) -> ApprovalRecord:
        now = datetime.now(timezone.utc)
        with SessionLocal() as session:
            row = session.get(ApprovalRow, approval_id)
            if row is None:
                raise ValueError("approval not found")
            expires = row.expires_at if row.expires_at.tzinfo else row.expires_at.replace(tzinfo=timezone.utc)
            if row.state != "APPROVED":
                raise ValueError(f"approval state is {row.state}")
            if expires <= now:
                row.state = "EXPIRED"
                session.commit()
                raise ValueError("approval expired")
            if row.parameter_hash != parameter_hash:
                raise ValueError("approved parameters do not match")
            if consume:
                row.state = "CONSUMED"
                session.commit()
            return ApprovalRecord(
                owner_id=row.owner_id,
                matter_id=row.matter_id,
                mission_id=row.mission_id,
                scope_id=row.scope_id,
                action=row.action,
                side_effect_class=row.side_effect_class,
                exact_parameters=row.exact_parameters_json,
                expires_at=row.expires_at,
                approval_id=row.approval_id,
                parameter_hash=row.parameter_hash,
                nonce=row.nonce,
                signature=row.signature,
                state=row.state,
                created_at=row.created_at,
            )

    def mark_capability_used(self, token_id: str, idempotency_key: str) -> None:
        with SessionLocal() as session:
            if session.get(CapabilityUseRow, token_id):
                raise ValueError("capability token already used")
            if session.scalars(select(CapabilityUseRow).where(CapabilityUseRow.idempotency_key == idempotency_key)).first():
                raise ValueError("idempotency key already used")
            session.add(CapabilityUseRow(token_id=token_id, used_at=datetime.now(timezone.utc), idempotency_key=idempotency_key))
            session.commit()

    def save_release(self, *, scope_id: str, state_version: int, output_text: str, claim_ast: list[dict], proof_ids: list[str], state_lattice: dict, policy_version: str) -> ReleaseReceipt:
        now = datetime.now(timezone.utc)
        release_id = f"release-{uuid.uuid4()}"
        count, root = self.proof_root()
        transaction = {
            "release_id": release_id,
            "scope_id": scope_id,
            "state_version": state_version,
            "output_hash": sha256_hex(output_text),
            "claim_ast_hash": sha256_hex(claim_ast),
            "proof_set_hash": sha256_hex(sorted(proof_ids)),
            "state_lattice_hash": sha256_hex(state_lattice),
            "proof_merkle_root": root,
            "proof_count": count,
            "policy_version": policy_version,
            "released_at": now.isoformat(),
        }
        signature = sign(get_settings().pfrd_release_signing_key, transaction)
        with SessionLocal() as session:
            session.add(ReleaseRow(
                release_id=release_id,
                scope_id=scope_id,
                state_version=state_version,
                output_text=output_text,
                output_hash=transaction["output_hash"],
                claim_ast_hash=transaction["claim_ast_hash"],
                proof_set_hash=transaction["proof_set_hash"],
                state_lattice_hash=transaction["state_lattice_hash"],
                proof_merkle_root=root,
                policy_version=policy_version,
                release_signature=signature,
                released_at=now,
            ))
            session.commit()
        return ReleaseReceipt(
            release_id=release_id,
            scope_id=scope_id,
            state_version=state_version,
            output_hash=transaction["output_hash"],
            claim_ast_hash=transaction["claim_ast_hash"],
            proof_set_hash=transaction["proof_set_hash"],
            state_lattice_hash=transaction["state_lattice_hash"],
            proof_merkle_root=root,
            policy_version=policy_version,
            release_signature=signature,
            released_at=now,
        )

    def incident(self, *, scope_id: str, failure_class: str, candidate_text: str, details: dict) -> str:
        incident_id = f"incident-{uuid.uuid4()}"
        with SessionLocal() as session:
            session.add(IncidentRow(
                incident_id=incident_id,
                scope_id=scope_id,
                failure_class=failure_class,
                candidate_text=candidate_text,
                details_json=details,
                created_at=datetime.now(timezone.utc),
                state="CONTAINED",
            ))
            session.commit()
        return incident_id
