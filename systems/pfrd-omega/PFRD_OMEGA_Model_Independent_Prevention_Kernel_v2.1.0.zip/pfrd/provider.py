from __future__ import annotations

import uuid
from urllib.parse import urlparse

import httpx

from pfrd.config import get_settings
from pfrd.crypto import sha256_hex


def _check_url(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only HTTP(S) provider routes are permitted")
    host = (parsed.hostname or "").lower()
    if host not in get_settings().provider_allowlist:
        raise ValueError(f"provider host is not allowlisted: {host}")


def execute(action: str, parameters: dict, idempotency_key: str) -> dict:
    execution_id = f"execution-{uuid.uuid4()}"
    if action == "HTTP_GET":
        url = parameters["url"]
        _check_url(url)
        response = httpx.get(url, headers=parameters.get("headers", {}), timeout=20)
    elif action == "HTTP_POST":
        url = parameters["url"]
        _check_url(url)
        response = httpx.post(
            url,
            headers=parameters.get("headers", {}),
            json=parameters.get("json", {}),
            timeout=20,
        )
    else:
        raise ValueError(f"unsupported provider action: {action}")
    return {
        "execution_id": execution_id,
        "provider_resource_id": response.headers.get("x-request-id") or execution_id,
        "status_code": response.status_code,
        "response_hash": sha256_hex(response.content),
        "response_text": response.text[:2000],
        "idempotency_key": idempotency_key,
    }


def readback(action: str, parameters: dict, execution_id: str) -> dict:
    url = parameters.get("readback_url") or parameters.get("url")
    _check_url(url)
    response = httpx.get(url, headers=parameters.get("readback_headers", {}), timeout=20)
    return {
        "execution_id": execution_id,
        "status_code": response.status_code,
        "readback_hash": sha256_hex(response.content),
        "readback_text": response.text[:2000],
        "provider_confirmed": 200 <= response.status_code < 300,
    }
