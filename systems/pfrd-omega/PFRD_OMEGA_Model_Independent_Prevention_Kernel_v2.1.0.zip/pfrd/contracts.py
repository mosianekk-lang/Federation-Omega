from __future__ import annotations

from datetime import datetime, timezone

from pfrd.models import Claim, ProofRecord, StateRecord


KERNEL_REQUIRED = {
    "ENFORCEMENT_SERVICE_DEPLOYMENT_RECEIPT",
    "TOOL_BROKER_ROUTE_TEST",
    "DIRECT_BYPASS_TEST",
    "POLICY_ENGINE_HEALTH_RECEIPT",
    "PROOF_LEDGER_HEALTH_RECEIPT",
    "RELEASE_SEALER_CANARY",
}

MIGRATION_REQUIRED = {
    "LEGACY_TASK_INVENTORY_RECEIPT",
    "REPLACEMENT_TASK_MAPPING_RECEIPT",
    "TASK_DEFINITION_HASH_RECEIPT",
    "SOURCE_INSTALL_RECEIPT",
    "SOURCE_READBACK_RECEIPT",
    "SOURCE_HASH_MATCH_RECEIPT",
    "FUNCTION_CANARY_RECEIPT",
    "TRIGGER_CREATION_RECEIPT",
    "TRIGGER_READBACK_RECEIPT",
    "UNATTENDED_TRIGGER_FIRE_RECEIPT",
    "PER_TASK_EXECUTION_RECEIPT",
    "PER_TASK_RESULT_READBACK_RECEIPT",
    "LEGACY_DECOMMISSION_RECEIPT",
    "LEGACY_DECOMMISSION_READBACK_RECEIPT",
    "DUPLICATE_EXECUTION_CHECK_RECEIPT",
    "ROLLBACK_SNAPSHOT_RECEIPT",
    "RESTORE_CANARY_RECEIPT",
    "INDEPENDENT_VERIFICATION_RECEIPT",
    "ADVERSARIAL_REVIEW_RECEIPT",
}

ADVERSE_ABSENCE_REQUIRED = {
    "AUTHORITATIVE_SOURCE_IDENTIFICATION_RECEIPT",
    "TOP_LEVEL_INVENTORY_RECEIPT",
    "RECURSIVE_INVENTORY_RECEIPT",
    "APPLICATION_VISIBLE_INVENTORY_RECEIPT",
    "PARENT_CHILD_PROVENANCE_RECEIPT",
    "HASH_DEDUPLICATION_RECEIPT",
    "CONTRARY_INVENTORY_SEARCH_RECEIPT",
    "COMPLETENESS_RECONCILIATION_RECEIPT",
    "INDEPENDENT_REPRODUCTION_RECEIPT",
}


def is_fresh(proof: ProofRecord, now: datetime | None = None) -> bool:
    now = now or datetime.now(timezone.utc)
    if proof.verification_state != "VALID":
        return False
    if proof.expires_at is None:
        return True
    expires = proof.expires_at
    if expires.tzinfo is None:
        expires = expires.replace(tzinfo=timezone.utc)
    return now < expires


def proof_failures(proofs: list[ProofRecord]) -> list[str]:
    failures: list[str] = []
    for proof in proofs:
        if proof.verification_state != "VALID":
            failures.append(f"{proof.proof_id}: state {proof.verification_state}")
        elif not is_fresh(proof):
            failures.append(f"{proof.proof_id}: expired")
    return failures


def contract_failures(
    claims: list[Claim], state: StateRecord, proofs: list[ProofRecord], activation_mode: str
) -> list[str]:
    failures: list[str] = []
    supplied = {proof.proof_type for proof in proofs if is_fresh(proof)}
    for claim in claims:
        if claim.speaker != "ASSISTANT_ASSERTION" or claim.polarity != "POSITIVE":
            continue
        if claim.predicate == "KERNEL_ACTIVE":
            if activation_mode not in {"LOCAL_KERNEL_QUALIFIED", "KERNEL_ENFORCED", "PRODUCTION_SEALED"}:
                failures.append("hard-kernel claim attempted before qualification")
            missing = sorted(KERNEL_REQUIRED - supplied)
            if missing:
                failures.append("kernel activation proofs missing: " + ", ".join(missing))
        elif claim.predicate == "MIGRATED":
            missing = sorted(MIGRATION_REQUIRED - supplied)
            if missing:
                failures.append("migration proofs missing: " + ", ".join(missing))
        elif claim.predicate == "ADVERSE_ABSENCE":
            missing = sorted(ADVERSE_ABSENCE_REQUIRED - supplied)
            if missing:
                failures.append("complete inventory not established: " + ", ".join(missing))
        elif claim.predicate in {"COMPLETE", "DEPLOYED", "FULLY_AUTOMATED"} and not claim.scope_id:
            failures.append(f"{claim.predicate} claim lacks explicit scope")
    return failures
