from __future__ import annotations

import uuid
from datetime import datetime, timezone

from pfrd.claims import compile_claims
from pfrd.config import get_settings
from pfrd.models import AnswerResponse, CandidateOutput, Decision
from pfrd.policy import evaluate
from pfrd.store import Store


class PreventionKernel:
    def __init__(self, store: Store | None = None) -> None:
        self.store = store or Store()

    def candidate_from_text(self, *, scope_id: str, text: str, model: str = "CANARY") -> CandidateOutput:
        return CandidateOutput(
            candidate_id=f"candidate-{uuid.uuid4()}",
            scope_id=scope_id,
            text=text,
            model=model,
            created_at=datetime.now(timezone.utc),
        )

    def model_candidate(self, *, scope_id: str, message: str, context: list[dict]) -> CandidateOutput:
        settings = get_settings()
        if not settings.openai_api_key:
            raise RuntimeError("OPENAI_API_KEY is not configured")
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise RuntimeError("openai package is not installed") from exc
        client = OpenAI(api_key=settings.openai_api_key)
        instructions = (
            "Produce a candidate answer only. Do not claim a migration, deployment, send, filing, "
            "delivery, activation or verification occurred unless supplied context contains "
            "provider-native proof. The external prevention kernel will withhold and review it."
        )
        response = client.responses.create(
            model=settings.openai_model,
            reasoning={"effort": settings.openai_reasoning_effort},
            instructions=instructions,
            input=[*context, {"role": "user", "content": message}],
        )
        text = response.output_text
        if not text:
            raise RuntimeError("model returned no candidate text")
        return self.candidate_from_text(scope_id=scope_id, text=text, model=settings.openai_model)

    def release(self, candidate: CandidateOutput) -> AnswerResponse:
        settings = get_settings()
        claims = compile_claims(candidate)
        state = self.store.get_state(candidate.scope_id)
        proofs = self.store.get_proofs(ids=state.proof_ids) if state.proof_ids else []
        result = evaluate(
            claims=claims,
            state=state,
            proofs=proofs,
            activation_mode=settings.pfrd_activation_mode,
        )
        if not result.allow:
            self.store.incident(
                scope_id=candidate.scope_id,
                failure_class=result.decision.value,
                candidate_text=candidate.text,
                details={
                    "reasons": result.reasons,
                    "claim_ids": [claim.claim_id for claim in claims],
                },
            )
            return AnswerResponse(
                decision=result.decision,
                output=None,
                reasons=result.reasons,
                candidate_id=candidate.candidate_id,
            )
        state_recheck = self.store.get_state(candidate.scope_id)
        if state_recheck.version != state.version:
            return AnswerResponse(
                decision=Decision.HOLD_FOR_FRESH_PROOF,
                output=None,
                reasons=["state changed before sealing; candidate must be re-evaluated"],
                candidate_id=candidate.candidate_id,
            )
        receipt = self.store.save_release(
            scope_id=candidate.scope_id,
            state_version=state.version,
            output_text=candidate.text,
            claim_ast=[claim.model_dump(mode="json") for claim in claims],
            proof_ids=[proof.proof_id for proof in proofs],
            state_lattice=state.lattice.model_dump(mode="json"),
            policy_version=settings.pfrd_policy_version,
        )
        return AnswerResponse(
            decision=Decision.RELEASE_SEALED,
            output=candidate.text,
            reasons=[],
            candidate_id=candidate.candidate_id,
            release_receipt=receipt,
        )
