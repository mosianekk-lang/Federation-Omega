from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    pfrd_public_api_key: str = "dev-public-key"
    pfrd_admin_api_key: str = "dev-admin-key"
    pfrd_service_token: str = "dev-service-token"
    pfrd_proof_signing_key: str = "dev-proof-key"
    pfrd_approval_signing_key: str = "dev-approval-key"
    pfrd_capability_signing_key: str = "dev-capability-key"
    pfrd_release_signing_key: str = "dev-release-key"

    database_url: str = "sqlite+pysqlite:////tmp/pfrd-omega.db"
    openai_api_key: str = ""
    openai_model: str = "gpt-5.6-sol"
    openai_reasoning_effort: str = "high"

    pfrd_activation_mode: str = "POLICY_ONLY"
    pfrd_policy_version: str = "2.1.0"
    pfrd_provider_allowlist: str = "localhost,127.0.0.1,gateway"
    pfrd_dev_mode: bool = False
    pfrd_require_opa: bool = False
    opa_url: str = ""
    pfrd_distributed_mode: bool = False
    model_orchestrator_url: str = "http://model-orchestrator:8010"
    claim_compiler_url: str = "http://claim-compiler:8011"
    proof_ledger_url: str = "http://proof-ledger:8012"
    state_service_url: str = "http://state-service:8013"
    adversarial_verifier_url: str = "http://adversarial-verifier:8014"
    approval_service_url: str = "http://approval-service:8015"
    capability_service_url: str = "http://capability-service:8016"
    provider_adapter_url: str = "http://provider-adapter:8017"
    tool_broker_url: str = "http://tool-broker:8018"
    release_sealer_url: str = "http://release-sealer:8019"

    data_root: Path = Path("/tmp/pfrd-data")

    @property
    def provider_allowlist(self) -> set[str]:
        return {item.strip().lower() for item in self.pfrd_provider_allowlist.split(",") if item.strip()}

    def validate_production_secrets(self) -> list[str]:
        failures: list[str] = []
        values = {
            "public": self.pfrd_public_api_key,
            "admin": self.pfrd_admin_api_key,
            "service": self.pfrd_service_token,
            "proof": self.pfrd_proof_signing_key,
            "approval": self.pfrd_approval_signing_key,
            "capability": self.pfrd_capability_signing_key,
            "release": self.pfrd_release_signing_key,
        }
        for name, value in values.items():
            if value.startswith("dev-") or value.startswith("replace-") or len(value) < 24:
                failures.append(f"{name} secret is not production-grade")
        if len(set(values.values())) != len(values):
            failures.append("signing and authentication secrets are not separated")
        return failures


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.data_root.mkdir(parents=True, exist_ok=True)
    return settings
