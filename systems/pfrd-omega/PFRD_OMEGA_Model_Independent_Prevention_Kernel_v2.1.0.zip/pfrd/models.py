from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class Decision(StrEnum):
    RELEASE_SEALED = "RELEASE_SEALED"
    RELEASE_WITH_BOUNDED_CAVEAT = "RELEASE_WITH_BOUNDED_CAVEAT"
    HOLD_FOR_EVIDENCE = "HOLD_FOR_EVIDENCE"
    HOLD_FOR_FRESH_PROOF = "HOLD_FOR_FRESH_PROOF"
    HOLD_FOR_APPROVAL = "HOLD_FOR_APPROVAL"
    HOLD_FOR_PROVIDER_READBACK = "HOLD_FOR_PROVIDER_READBACK"
    HOLD_FOR_SEMANTIC_REVIEW = "HOLD_FOR_SEMANTIC_REVIEW"
    RELEASE_BLOCKED_CONTRADICTION = "RELEASE_BLOCKED_CONTRADICTION"
    REJECT_FALSE_CERTAINTY = "REJECT_FALSE_CERTAINTY"
    EXECUTION_UNCERTAIN = "EXECUTION_UNCERTAIN"
    CAPABILITY_SUSPENDED = "CAPABILITY_SUSPENDED"


class SideEffectClass(StrEnum):
    READ_ONLY = "READ_ONLY"
    INTERNAL_REVERSIBLE = "INTERNAL_REVERSIBLE"
    EXTERNAL_COMMUNICATION = "EXTERNAL_COMMUNICATION"
    LEGALLY_BINDING = "LEGALLY_BINDING"
    DESTRUCTIVE = "DESTRUCTIVE"
    FINANCIAL = "FINANCIAL"
    CREDENTIAL_CHANGE = "CREDENTIAL_CHANGE"


class CandidateOutput(BaseModel):
    candidate_id: str
    scope_id: str
    text: str
    model: str
    created_at: datetime


class Claim(BaseModel):
    claim_id: str
    candidate_id: str
    sentence_index: int
    text: str
    speaker: str
    predicate: str
    polarity: str
    modality: str
    tense: str
    scope_id: str | None = None
    parser_agreement: str = "AGREED"
    supplied_proof_ids: list[str] = Field(default_factory=list)


class StateLattice(BaseModel):
    definition_state: str = "UNKNOWN"
    source_state: str = "UNKNOWN"
    function_state: str = "UNKNOWN"
    trigger_state: str = "UNKNOWN"
    execution_state: str = "NOT_STARTED"
    result_state: str = "UNKNOWN"
    verification_state: str = "NONE"
    legacy_state: str = "UNKNOWN"
    duplicate_state: str = "UNKNOWN"
    rollback_state: str = "UNKNOWN"
    security_state: str = "UNKNOWN"
    provider_state: str = "UNKNOWN"
    freshness_state: str = "UNKNOWN"
    environment_state: str = "CHAT_POLICY_ONLY"


class StateRecord(BaseModel):
    scope_id: str
    version: int = 1
    lattice: StateLattice = Field(default_factory=StateLattice)
    proof_ids: list[str] = Field(default_factory=list)
    updated_at: datetime


class ProofCreate(BaseModel):
    proof_type: str
    owner_id: str
    matter_id: str
    mission_id: str
    scope_id: str
    subject_id: str
    issuer_domain: str
    provider_name: str
    provider_resource_id: str | None = None
    provider_execution_id: str | None = None
    environment: str
    observed_at: datetime
    valid_from: datetime
    expires_at: datetime | None = None
    independently_read_back: bool = False
    payload: dict[str, Any]


class ProofRecord(ProofCreate):
    proof_id: str
    issued_at: datetime
    payload_hash: str
    previous_proof_hash: str | None = None
    proof_hash: str
    signature: str
    verification_state: str = "VALID"


class Contradiction(BaseModel):
    contradiction_id: str
    claim_id: str
    severity: str
    reason: str


class ApprovalCreate(BaseModel):
    owner_id: str
    matter_id: str
    mission_id: str
    scope_id: str
    action: str
    side_effect_class: SideEffectClass
    exact_parameters: dict[str, Any]
    expires_at: datetime


class ApprovalRecord(ApprovalCreate):
    approval_id: str
    parameter_hash: str
    nonce: str
    signature: str
    state: str
    created_at: datetime


class CapabilityRequest(BaseModel):
    approval_id: str | None = None
    matter_id: str
    mission_id: str
    scope_id: str
    action: str
    side_effect_class: SideEffectClass
    exact_parameters_hash: str
    expires_at: datetime


class CapabilityToken(BaseModel):
    token: str
    token_id: str
    expires_at: datetime


class ToolRequest(BaseModel):
    owner_id: str
    matter_id: str
    mission_id: str
    scope_id: str
    action: str
    side_effect_class: SideEffectClass
    parameters: dict[str, Any]
    approval_id: str | None = None
    capability_token: str | None = None


class ToolResult(BaseModel):
    status: str
    execution_id: str | None = None
    provider_resource_id: str | None = None
    execution_proof_id: str | None = None
    readback_proof_id: str | None = None
    parameter_match_proof_id: str | None = None
    result: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


class ReleaseReceipt(BaseModel):
    release_id: str
    scope_id: str
    state_version: int
    output_hash: str
    claim_ast_hash: str
    proof_set_hash: str
    state_lattice_hash: str
    proof_merkle_root: str
    policy_version: str
    release_signature: str
    released_at: datetime


class AnswerRequest(BaseModel):
    message: str
    scope_id: str
    context: list[dict[str, Any]] = Field(default_factory=list)


class AnswerResponse(BaseModel):
    decision: Decision
    output: str | None = None
    reasons: list[str] = Field(default_factory=list)
    candidate_id: str | None = None
    release_receipt: ReleaseReceipt | None = None
