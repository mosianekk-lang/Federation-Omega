from __future__ import annotations

import hmac

from fastapi import Header, HTTPException

from pfrd.config import get_settings


def _require(actual: str | None, expected: str, label: str) -> None:
    if not actual or not hmac.compare_digest(actual, expected):
        raise HTTPException(status_code=401, detail=f"Invalid {label}.")


def require_public(x_pfrd_api_key: str | None = Header(default=None)) -> None:
    _require(x_pfrd_api_key, get_settings().pfrd_public_api_key, "public API key")


def require_admin(x_pfrd_admin_key: str | None = Header(default=None)) -> None:
    _require(x_pfrd_admin_key, get_settings().pfrd_admin_api_key, "admin API key")


def require_service(x_pfrd_service_token: str | None = Header(default=None)) -> None:
    _require(x_pfrd_service_token, get_settings().pfrd_service_token, "service token")


def service_headers() -> dict[str, str]:
    return {"X-PFRD-Service-Token": get_settings().pfrd_service_token}
