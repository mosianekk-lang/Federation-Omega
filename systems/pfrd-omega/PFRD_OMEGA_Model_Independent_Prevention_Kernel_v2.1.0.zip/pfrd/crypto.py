from __future__ import annotations

import base64
import hashlib
import hmac
import json
from typing import Any


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode()


def sha256_hex(value: Any) -> str:
    raw = value if isinstance(value, bytes) else canonical_json(value)
    return hashlib.sha256(raw).hexdigest()


def sign(key: str, value: Any) -> str:
    raw = hmac.new(key.encode(), canonical_json(value), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(raw).decode().rstrip("=")


def verify(key: str, value: Any, signature: str) -> bool:
    return hmac.compare_digest(sign(key, value), signature)


def encode_token(payload: dict, key: str) -> str:
    encoded = base64.urlsafe_b64encode(canonical_json(payload)).decode().rstrip("=")
    return f"{encoded}.{sign(key, payload)}"


def decode_token(token: str, key: str) -> dict:
    encoded, signature = token.split(".", 1)
    padding = "=" * (-len(encoded) % 4)
    payload = json.loads(base64.urlsafe_b64decode(encoded + padding))
    if not verify(key, payload, signature):
        raise ValueError("invalid token signature")
    return payload


def merkle_root(hashes: list[str]) -> str:
    if not hashes:
        return sha256_hex(b"")
    layer = list(hashes)
    while len(layer) > 1:
        if len(layer) % 2:
            layer.append(layer[-1])
        layer = [
            hashlib.sha256(bytes.fromhex(layer[i]) + bytes.fromhex(layer[i + 1])).hexdigest()
            for i in range(0, len(layer), 2)
        ]
    return layer[0]
