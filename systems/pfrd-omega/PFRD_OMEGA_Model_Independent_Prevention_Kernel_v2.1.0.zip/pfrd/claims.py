from __future__ import annotations

import re
import uuid

from pfrd.models import CandidateOutput, Claim


CONTROLLED: list[tuple[str, re.Pattern[str]]] = [
    (
        "KERNEL_ACTIVE",
        re.compile(
            r"\b(?:hard[- ]kernel|model[- ]independent enforcement|prevention kernel)\b"
            r".{0,50}\b(?:active|enforced|live|operational)\b",
            re.I,
        ),
    ),
    (
        "MIGRATED",
        re.compile(
            r"\b(?:migrated|migration (?:is )?complete|moved to|transferred to|"
            r"now sits on|all tasks (?:are|have been) moved)\b",
            re.I,
        ),
    ),
    ("FULLY_AUTOMATED", re.compile(r"\b(?:fully automated|autonomous|unattended|self[- ]running)\b", re.I)),
    ("DEPLOYED", re.compile(r"\b(?:production live|deployed|deployment complete|live in production)\b", re.I)),
    (
        "EXTERNAL_ACTION_COMPLETED",
        re.compile(r"\b(?:sent|delivered|filed|submitted|shared|published|deleted|paid|accepted)\b", re.I),
    ),
    (
        "ADVERSE_ABSENCE",
        re.compile(r"\b(?:missing|omitted|absent|removed|lost|not attached|incomplete|not provided)\b", re.I),
    ),
    ("VERIFIED", re.compile(r"\b(?:verified|confirmed|proven|validated)\b", re.I)),
    ("ACTIVE", re.compile(r"\b(?:active|activated|operational|enabled)\b", re.I)),
    ("COMPLETE", re.compile(r"\b(?:complete|completed|finished|done)\b", re.I)),
]

NEGATION = re.compile(r"\b(?:not|never|no|isn't|is not|hasn't|has not|wasn't|was not|cannot|can't|without)\b", re.I)
HYPOTHETICAL = re.compile(r"\b(?:if|could|may|might|would|should|possibly|hypothetically|pending|until)\b", re.I)
ATTRIBUTION = re.compile(r"\b(?:said|stated|claimed|reported|wrote|described|labelled|called)\b", re.I)


def _segments(text: str) -> list[tuple[str, str]]:
    segments: list[tuple[str, str]] = []
    in_code = False
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("```"):
            in_code = not in_code
            continue
        if not stripped:
            continue
        speaker = "CODE_LITERAL" if in_code else "ASSISTANT_ASSERTION"
        if stripped.startswith(">"):
            speaker = "SOURCE_QUOTATION"
            stripped = stripped.lstrip("> ")
        for sentence in re.split(r"(?<=[.!?])\s+|\n+", stripped):
            sentence = sentence.strip()
            if sentence:
                segments.append((sentence, speaker))
    return segments


def _inside_quote(sentence: str, position: int) -> bool:
    straight = sentence[:position].count('"') % 2 == 1
    curly = sentence[:position].count("“") > sentence[:position].count("”")
    return straight or curly


def _speaker(sentence: str, position: int, default: str) -> str:
    if default != "ASSISTANT_ASSERTION":
        return default
    if _inside_quote(sentence, position):
        return "SOURCE_QUOTATION"
    prefix = sentence[:position]
    if ATTRIBUTION.search(prefix[-70:]) and ('"' in sentence or "“" in sentence):
        return "THIRD_PARTY_QUOTATION"
    return default


def _polarity(sentence: str, start: int) -> str:
    prefix = sentence[max(0, start - 60):start]
    if NEGATION.search(prefix):
        return "NEGATIVE"
    if HYPOTHETICAL.search(sentence):
        return "CONDITIONAL"
    return "POSITIVE"


def compile_claims(candidate: CandidateOutput) -> list[Claim]:
    claims: list[Claim] = []
    for index, (sentence, default_speaker) in enumerate(_segments(candidate.text)):
        for predicate, pattern in CONTROLLED:
            match = pattern.search(sentence)
            if not match:
                continue
            claims.append(
                Claim(
                    claim_id=f"claim-{uuid.uuid4()}",
                    candidate_id=candidate.candidate_id,
                    sentence_index=index,
                    text=sentence,
                    speaker=_speaker(sentence, match.start(), default_speaker),
                    predicate=predicate,
                    polarity=_polarity(sentence, match.start()),
                    modality="POSSIBLE" if HYPOTHETICAL.search(sentence) else "ASSERTED",
                    tense="PRESENT",
                    scope_id=candidate.scope_id or None,
                    parser_agreement="AGREED",
                )
            )
    return claims
