from __future__ import annotations

import uuid
from datetime import datetime, timezone

from pfrd.config import get_settings
from pfrd.crypto import decode_token, encode_token
from pfrd.models import CapabilityRequest, CapabilityToken


def issue(request: CapabilityRequest) -> CapabilityToken:
    now = datetime.now(timezone.utc)
    if request.expires_at <= now:
        raise ValueError("capability expiry must be in the future")
    token_id = f"cap-{uuid.uuid4()}"
    payload = {
        "token_id": token_id,
        "approval_id": request.approval_id,
        "matter_id": request.matter_id,
        "mission_id": request.mission_id,
        "scope_id": request.scope_id,
        "action": request.action,
        "side_effect_class": request.side_effect_class,
        "exact_parameters_hash": request.exact_parameters_hash,
        "expires_at": request.expires_at.isoformat(),
        "nonce": str(uuid.uuid4()),
        "single_use": True,
    }
    return CapabilityToken(
        token=encode_token(payload, get_settings().pfrd_capability_signing_key),
        token_id=token_id,
        expires_at=request.expires_at,
    )


def validate(token: str, *, exact_parameters_hash: str, action: str, scope_id: str) -> dict:
    payload = decode_token(token, get_settings().pfrd_capability_signing_key)
    expires = datetime.fromisoformat(payload["expires_at"])
    if expires.tzinfo is None:
        expires = expires.replace(tzinfo=timezone.utc)
    if expires <= datetime.now(timezone.utc):
        raise ValueError("capability token expired")
    checks = {
        "exact_parameters_hash": exact_parameters_hash,
        "action": action,
        "scope_id": scope_id,
    }
    for key, expected in checks.items():
        if payload.get(key) != expected:
            raise ValueError(f"capability {key} mismatch")
    return payload
