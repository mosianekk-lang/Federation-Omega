from __future__ import annotations

from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from pfrd.config import get_settings


class Base(DeclarativeBase):
    pass


class ProofRow(Base):
    __tablename__ = "proofs"
    proof_id: Mapped[str] = mapped_column(String(96), primary_key=True)
    proof_type: Mapped[str] = mapped_column(String(128), index=True)
    owner_id: Mapped[str] = mapped_column(String(128))
    matter_id: Mapped[str] = mapped_column(String(128), index=True)
    mission_id: Mapped[str] = mapped_column(String(128), index=True)
    scope_id: Mapped[str] = mapped_column(String(128), index=True)
    subject_id: Mapped[str] = mapped_column(String(256))
    issuer_domain: Mapped[str] = mapped_column(String(128))
    provider_name: Mapped[str] = mapped_column(String(128))
    provider_resource_id: Mapped[str | None] = mapped_column(String(512), nullable=True)
    provider_execution_id: Mapped[str | None] = mapped_column(String(512), nullable=True)
    environment: Mapped[str] = mapped_column(String(80))
    observed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    issued_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    valid_from: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    independently_read_back: Mapped[bool] = mapped_column(Boolean, default=False)
    payload_json: Mapped[dict] = mapped_column(JSON)
    payload_hash: Mapped[str] = mapped_column(String(64))
    previous_proof_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    proof_hash: Mapped[str] = mapped_column(String(64), unique=True)
    signature: Mapped[str] = mapped_column(Text)
    verification_state: Mapped[str] = mapped_column(String(40), default="VALID")


class StateRow(Base):
    __tablename__ = "states"
    scope_id: Mapped[str] = mapped_column(String(128), primary_key=True)
    version: Mapped[int] = mapped_column(Integer)
    lattice_json: Mapped[dict] = mapped_column(JSON)
    proof_ids_json: Mapped[list] = mapped_column(JSON)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class ApprovalRow(Base):
    __tablename__ = "approvals"
    approval_id: Mapped[str] = mapped_column(String(96), primary_key=True)
    owner_id: Mapped[str] = mapped_column(String(128))
    matter_id: Mapped[str] = mapped_column(String(128))
    mission_id: Mapped[str] = mapped_column(String(128))
    scope_id: Mapped[str] = mapped_column(String(128))
    action: Mapped[str] = mapped_column(String(128))
    side_effect_class: Mapped[str] = mapped_column(String(64))
    exact_parameters_json: Mapped[dict] = mapped_column(JSON)
    parameter_hash: Mapped[str] = mapped_column(String(64))
    nonce: Mapped[str] = mapped_column(String(96))
    signature: Mapped[str] = mapped_column(Text)
    state: Mapped[str] = mapped_column(String(48))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class CapabilityUseRow(Base):
    __tablename__ = "capability_uses"
    token_id: Mapped[str] = mapped_column(String(96), primary_key=True)
    used_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    idempotency_key: Mapped[str] = mapped_column(String(128), unique=True)


class ReleaseRow(Base):
    __tablename__ = "releases"
    release_id: Mapped[str] = mapped_column(String(96), primary_key=True)
    scope_id: Mapped[str] = mapped_column(String(128), index=True)
    state_version: Mapped[int] = mapped_column(Integer)
    output_text: Mapped[str] = mapped_column(Text)
    output_hash: Mapped[str] = mapped_column(String(64))
    claim_ast_hash: Mapped[str] = mapped_column(String(64))
    proof_set_hash: Mapped[str] = mapped_column(String(64))
    state_lattice_hash: Mapped[str] = mapped_column(String(64))
    proof_merkle_root: Mapped[str] = mapped_column(String(64))
    policy_version: Mapped[str] = mapped_column(String(40))
    release_signature: Mapped[str] = mapped_column(Text)
    released_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))


class IncidentRow(Base):
    __tablename__ = "incidents"
    incident_id: Mapped[str] = mapped_column(String(96), primary_key=True)
    scope_id: Mapped[str] = mapped_column(String(128), index=True)
    failure_class: Mapped[str] = mapped_column(String(128), index=True)
    candidate_text: Mapped[str] = mapped_column(Text)
    details_json: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    state: Mapped[str] = mapped_column(String(48))


settings = get_settings()
connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, pool_pre_ping=True, future=True, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, expire_on_commit=False)


def init_db() -> None:
    Base.metadata.create_all(bind=engine)


def reset_db_for_tests() -> None:
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)


def proof_rows(scope_id: str | None = None, ids: list[str] | None = None) -> list[ProofRow]:
    with SessionLocal() as session:
        query = select(ProofRow)
        if scope_id:
            query = query.where(ProofRow.scope_id == scope_id)
        if ids:
            query = query.where(ProofRow.proof_id.in_(ids))
        return list(session.scalars(query.order_by(ProofRow.issued_at.asc())).all())
