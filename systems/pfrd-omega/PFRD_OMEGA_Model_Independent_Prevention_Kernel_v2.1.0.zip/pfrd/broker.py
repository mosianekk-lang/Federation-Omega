from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import httpx

from pfrd.capabilities import validate as validate_capability
from pfrd.crypto import sha256_hex
from pfrd.models import ProofCreate, SideEffectClass, ToolRequest, ToolResult
from pfrd.provider import execute as provider_execute, readback as provider_readback
from pfrd.store import Store


CONSEQUENTIAL = {
    SideEffectClass.EXTERNAL_COMMUNICATION,
    SideEffectClass.LEGALLY_BINDING,
    SideEffectClass.DESTRUCTIVE,
    SideEffectClass.FINANCIAL,
    SideEffectClass.CREDENTIAL_CHANGE,
}


class ToolBroker:
    def __init__(self, store: Store | None = None, executor=None, reader=None) -> None:
        self.store = store or Store()
        self.executor = executor or provider_execute
        self.reader = reader or provider_readback

    def execute(self, request: ToolRequest) -> ToolResult:
        parameter_hash = sha256_hex(request.parameters)
        idempotency_key = request.parameters.get("idempotency_key") or f"idempotency-{uuid.uuid4()}"
        capability_payload: dict | None = None
        if request.side_effect_class in CONSEQUENTIAL:
            if not request.approval_id or not request.capability_token:
                return ToolResult(status="HOLD_FOR_APPROVAL", error="exact approval and capability token required")
            try:
                self.store.verify_approval(request.approval_id, parameter_hash, consume=False)
                capability_payload = validate_capability(
                    request.capability_token,
                    exact_parameters_hash=parameter_hash,
                    action=request.action,
                    scope_id=request.scope_id,
                )
            except ValueError as exc:
                return ToolResult(status="HOLD_FOR_APPROVAL", error=str(exc))
        if request.side_effect_class in CONSEQUENTIAL:
            assert request.approval_id and capability_payload
            try:
                # Reserve the single-use token and consume the exact approval before
                # the provider call. This is deliberately fail-closed: a timeout or
                # ambiguous provider response cannot silently reuse the same authority.
                self.store.mark_capability_used(capability_payload["token_id"], idempotency_key)
                self.store.verify_approval(request.approval_id, parameter_hash, consume=True)
            except ValueError as exc:
                return ToolResult(status="HOLD_FOR_APPROVAL", error=str(exc))
        try:
            execution = self.executor(request.action, request.parameters, idempotency_key)
        except httpx.TimeoutException:
            return ToolResult(
                status="EXECUTION_UNCERTAIN",
                error="provider request timed out after submission; automatic retry prohibited",
            )
        except Exception as exc:
            return ToolResult(status="FAILED", error=str(exc))
        try:
            readback = self.reader(request.action, request.parameters, execution["execution_id"])
        except Exception as exc:
            return ToolResult(
                status="EXECUTION_UNCERTAIN",
                execution_id=execution["execution_id"],
                provider_resource_id=execution["provider_resource_id"],
                result={"execution": execution},
                error=f"provider execution returned but readback failed: {exc}",
            )
        now = datetime.now(timezone.utc)
        expiry = now + timedelta(hours=1)
        common = dict(
            owner_id=request.owner_id,
            matter_id=request.matter_id,
            mission_id=request.mission_id,
            scope_id=request.scope_id,
            subject_id=request.action,
            provider_resource_id=execution["provider_resource_id"],
            provider_execution_id=execution["execution_id"],
            observed_at=now,
            valid_from=now,
            expires_at=expiry,
        )
        execution_proof = self.store.issue_proof(
            ProofCreate(
                proof_type="PROVIDER_EXECUTION_RECEIPT",
                issuer_domain="PROVIDER_EXECUTOR",
                provider_name="PRIVATE_PROVIDER_ADAPTER",
                environment="PROVIDER_NATIVE",
                independently_read_back=False,
                payload=execution,
                **common,
            )
        )
        readback_proof = self.store.issue_proof(
            ProofCreate(
                proof_type="PROVIDER_ACTION_READBACK_RECEIPT",
                issuer_domain="PROVIDER_READER",
                provider_name="PRIVATE_PROVIDER_ADAPTER",
                environment="PROVIDER_NATIVE",
                independently_read_back=True,
                payload=readback,
                **common,
            )
        )
        match_proof = self.store.issue_proof(
            ProofCreate(
                proof_type="PARAMETER_MATCH_RECEIPT",
                issuer_domain="TOOL_BROKER",
                provider_name="PFRD_TOOL_BROKER",
                environment="KERNEL",
                independently_read_back=True,
                payload={
                    "parameter_hash": parameter_hash,
                    "idempotency_key": idempotency_key,
                    "provider_confirmed": readback["provider_confirmed"],
                },
                **common,
            )
        )
        return ToolResult(
            status="READBACK_CONFIRMED" if readback["provider_confirmed"] else "HOLD_FOR_PROVIDER_READBACK",
            execution_id=execution["execution_id"],
            provider_resource_id=execution["provider_resource_id"],
            execution_proof_id=execution_proof.proof_id,
            readback_proof_id=readback_proof.proof_id,
            parameter_match_proof_id=match_proof.proof_id,
            result={"execution": execution, "readback": readback},
        )
