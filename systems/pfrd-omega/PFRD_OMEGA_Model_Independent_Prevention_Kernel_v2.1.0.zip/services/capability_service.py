from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel
from pfrd.capabilities import issue, validate
from pfrd.models import CapabilityRequest, CapabilityToken
from pfrd.security import require_service
class Verify(BaseModel): token:str; exact_parameters_hash:str; action:str; scope_id:str
app=FastAPI(title="PFRD Capability Service")
@app.get("/health")
def health(): return {"status":"ok","service":"capability-service"}
@app.post("/tokens",response_model=CapabilityToken,dependencies=[Depends(require_service)])
def tokens(r:CapabilityRequest):
    try:return issue(r)
    except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
@app.post("/verify",dependencies=[Depends(require_service)])
def verify_route(r:Verify):
    try:return {"valid":True,"payload":validate(r.token,exact_parameters_hash=r.exact_parameters_hash,action=r.action,scope_id=r.scope_id)}
    except ValueError as exc:raise HTTPException(status_code=409,detail=str(exc)) from exc
