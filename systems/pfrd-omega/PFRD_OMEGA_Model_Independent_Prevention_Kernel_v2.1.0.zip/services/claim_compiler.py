from fastapi import Depends, FastAPI
from pfrd.claims import compile_claims
from pfrd.models import CandidateOutput, Claim
from pfrd.security import require_service
app=FastAPI(title="PFRD Claim Compiler")
@app.get("/health")
def health(): return {"status":"ok","service":"claim-compiler"}
@app.post("/compile",response_model=list[Claim],dependencies=[Depends(require_service)])
def compile_route(candidate:CandidateOutput): return compile_claims(candidate)
