from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel
from pfrd.provider import execute, readback
from pfrd.security import require_service
class Execute(BaseModel): action:str; parameters:dict; idempotency_key:str
class Readback(BaseModel): action:str; parameters:dict; execution_id:str
app=FastAPI(title="PFRD Provider Adapter")
@app.get("/health")
def health(): return {"status":"ok","service":"provider-adapter"}
@app.post("/execute",dependencies=[Depends(require_service)])
def execute_route(r:Execute):
    try:return execute(r.action,r.parameters,r.idempotency_key)
    except Exception as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
@app.post("/readback",dependencies=[Depends(require_service)])
def readback_route(r:Readback):
    try:return readback(r.action,r.parameters,r.execution_id)
    except Exception as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
