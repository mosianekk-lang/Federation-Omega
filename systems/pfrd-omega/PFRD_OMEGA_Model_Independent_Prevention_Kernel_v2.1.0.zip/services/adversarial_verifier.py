from fastapi import Depends, FastAPI
from pydantic import BaseModel
from pfrd.models import Claim, Contradiction, StateRecord
from pfrd.security import require_service
from pfrd.verifier import verify_claims
class Request(BaseModel): claims:list[Claim]; state:StateRecord
app=FastAPI(title="PFRD Adversarial Verifier")
@app.get("/health")
def health(): return {"status":"ok","service":"adversarial-verifier"}
@app.post("/verify",response_model=list[Contradiction],dependencies=[Depends(require_service)])
def verify(r:Request): return verify_claims(r.claims,r.state)
