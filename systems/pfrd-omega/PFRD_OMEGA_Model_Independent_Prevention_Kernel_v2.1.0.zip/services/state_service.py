from fastapi import Depends, FastAPI, HTTPException
from pfrd.models import StateRecord
from pfrd.security import require_service
from pfrd.store import Store
app=FastAPI(title="PFRD State Service"); store=Store()
@app.get("/health")
def health(): return {"status":"ok","service":"state-service"}
@app.get("/states/{scope_id}",response_model=StateRecord,dependencies=[Depends(require_service)])
def get(scope_id:str): return store.get_state(scope_id)
@app.post("/states",response_model=StateRecord,dependencies=[Depends(require_service)])
def set_route(r:StateRecord):
    try:return store.set_state(r)
    except ValueError as exc: raise HTTPException(status_code=409,detail=str(exc)) from exc
