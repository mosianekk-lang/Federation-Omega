import httpx
from fastapi import Depends, FastAPI

from pfrd.broker import ToolBroker
from pfrd.config import get_settings
from pfrd.models import ToolRequest, ToolResult
from pfrd.security import require_service, service_headers


def remote_execute(action: str, parameters: dict, idempotency_key: str) -> dict:
    response = httpx.post(
        f"{get_settings().provider_adapter_url}/execute",
        headers=service_headers(),
        json={"action": action, "parameters": parameters, "idempotency_key": idempotency_key},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


def remote_readback(action: str, parameters: dict, execution_id: str) -> dict:
    response = httpx.post(
        f"{get_settings().provider_adapter_url}/readback",
        headers=service_headers(),
        json={"action": action, "parameters": parameters, "execution_id": execution_id},
        timeout=30,
    )
    response.raise_for_status()
    return response.json()


app = FastAPI(title="PFRD Tool Broker")
broker = ToolBroker(executor=remote_execute, reader=remote_readback)


@app.get("/health")
def health():
    return {"status": "ok", "service": "tool-broker", "provider_route": "PRIVATE_ADAPTER"}


@app.post("/execute", response_model=ToolResult, dependencies=[Depends(require_service)])
def execute_route(request: ToolRequest):
    return broker.execute(request)
