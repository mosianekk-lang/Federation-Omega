from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel
from pfrd.models import CandidateOutput, Claim, ReleaseReceipt
from pfrd.security import require_service
from pfrd.store import Store
class Seal(BaseModel): candidate:CandidateOutput; claims:list[Claim]; proof_ids:list[str]; state_version:int; policy_version:str
app=FastAPI(title="PFRD Release Sealer"); store=Store()
@app.get("/health")
def health():return {"status":"ok","service":"release-sealer"}
@app.post("/seal",response_model=ReleaseReceipt,dependencies=[Depends(require_service)])
def seal(r:Seal):
    state=store.get_state(r.candidate.scope_id)
    if state.version!=r.state_version:raise HTTPException(status_code=409,detail="state changed before sealing")
    return store.save_release(scope_id=r.candidate.scope_id,state_version=state.version,output_text=r.candidate.text,claim_ast=[c.model_dump(mode="json") for c in r.claims],proof_ids=r.proof_ids,state_lattice=state.lattice.model_dump(mode="json"),policy_version=r.policy_version)
