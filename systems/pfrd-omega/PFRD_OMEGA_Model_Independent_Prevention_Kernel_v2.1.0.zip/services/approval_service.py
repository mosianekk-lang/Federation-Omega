from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel
from pfrd.models import ApprovalCreate, ApprovalRecord
from pfrd.security import require_service
from pfrd.store import Store
class Verify(BaseModel): approval_id:str; parameter_hash:str; consume:bool=False
app=FastAPI(title="PFRD Approval Service"); store=Store()
@app.get("/health")
def health(): return {"status":"ok","service":"approval-service"}
@app.post("/approvals",response_model=ApprovalRecord,dependencies=[Depends(require_service)])
def create(r:ApprovalCreate):
    try:return store.create_approval(r)
    except ValueError as exc:raise HTTPException(status_code=400,detail=str(exc)) from exc
@app.post("/verify",response_model=ApprovalRecord,dependencies=[Depends(require_service)])
def verify(r:Verify):
    try:return store.verify_approval(r.approval_id,r.parameter_hash,consume=r.consume)
    except ValueError as exc:raise HTTPException(status_code=409,detail=str(exc)) from exc
