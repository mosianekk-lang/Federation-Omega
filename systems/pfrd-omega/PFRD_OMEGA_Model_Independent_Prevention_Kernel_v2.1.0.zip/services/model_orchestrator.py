from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field
from pfrd.kernel import PreventionKernel
from pfrd.models import CandidateOutput
from pfrd.security import require_service

app = FastAPI(title="PFRD Model Orchestrator")
kernel = PreventionKernel()

class Request(BaseModel):
    message: str
    scope_id: str
    context: list[dict] = Field(default_factory=list)

@app.get("/health")
def health(): return {"status":"ok","service":"model-orchestrator"}

@app.post("/candidate", response_model=CandidateOutput, dependencies=[Depends(require_service)])
def candidate(request: Request):
    try:
        return kernel.model_candidate(scope_id=request.scope_id, message=request.message, context=request.context)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
