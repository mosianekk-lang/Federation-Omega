from __future__ import annotations

from datetime import datetime, timezone

import httpx
from fastapi import Depends, FastAPI, HTTPException

from pfrd.broker import ToolBroker
from pfrd.capabilities import issue as issue_capability
from pfrd.claims import compile_claims
from pfrd.config import get_settings
from pfrd.kernel import PreventionKernel
from pfrd.models import (
    AnswerRequest,
    AnswerResponse,
    ApprovalCreate,
    ApprovalRecord,
    CandidateOutput,
    CapabilityRequest,
    CapabilityToken,
    Claim,
    ProofCreate,
    ProofRecord,
    ReleaseReceipt,
    StateRecord,
    ToolRequest,
    ToolResult,
)
from pfrd.policy import evaluate
from pfrd.security import require_admin, require_public, service_headers
from pfrd.store import Store


app = FastAPI(title="PFRD-Ω External Enforcement Gateway", version="2.1.0")
store = Store()
kernel = PreventionKernel(store)
broker = ToolBroker(store)


def _distributed() -> bool:
    return get_settings().pfrd_distributed_mode


def _request(method: str, url: str, **kwargs) -> httpx.Response:
    headers = dict(service_headers())
    headers.update(kwargs.pop("headers", {}))
    response = httpx.request(method, url, headers=headers, timeout=120, **kwargs)
    response.raise_for_status()
    return response


def _distributed_release(candidate: CandidateOutput) -> AnswerResponse:
    settings = get_settings()
    claims = [
        Claim.model_validate(item)
        for item in _request(
            "POST",
            f"{settings.claim_compiler_url}/compile",
            json=candidate.model_dump(mode="json"),
        ).json()
    ]
    state = StateRecord.model_validate(
        _request("GET", f"{settings.state_service_url}/states/{candidate.scope_id}").json()
    )
    proofs = [
        ProofRecord.model_validate(item)
        for item in _request(
            "GET",
            f"{settings.proof_ledger_url}/proofs",
            params=[("ids", proof_id) for proof_id in state.proof_ids],
        ).json()
    ] if state.proof_ids else []
    result = evaluate(
        claims=claims,
        state=state,
        proofs=proofs,
        activation_mode=settings.pfrd_activation_mode,
    )
    if not result.allow:
        store.incident(
            scope_id=candidate.scope_id,
            failure_class=result.decision.value,
            candidate_text=candidate.text,
            details={"reasons": result.reasons, "distributed": True},
        )
        return AnswerResponse(
            decision=result.decision,
            output=None,
            reasons=result.reasons,
            candidate_id=candidate.candidate_id,
        )
    current = StateRecord.model_validate(
        _request("GET", f"{settings.state_service_url}/states/{candidate.scope_id}").json()
    )
    if current.version != state.version:
        return AnswerResponse(
            decision="HOLD_FOR_FRESH_PROOF",
            output=None,
            reasons=["state changed before sealing; candidate must be re-evaluated"],
            candidate_id=candidate.candidate_id,
        )
    receipt = ReleaseReceipt.model_validate(
        _request(
            "POST",
            f"{settings.release_sealer_url}/seal",
            json={
                "candidate": candidate.model_dump(mode="json"),
                "claims": [claim.model_dump(mode="json") for claim in claims],
                "proof_ids": [proof.proof_id for proof in proofs],
                "state_version": state.version,
                "policy_version": settings.pfrd_policy_version,
            },
        ).json()
    )
    return AnswerResponse(
        decision="RELEASE_SEALED",
        output=candidate.text,
        reasons=[],
        candidate_id=candidate.candidate_id,
        release_receipt=receipt,
    )


def _release(candidate: CandidateOutput) -> AnswerResponse:
    return _distributed_release(candidate) if _distributed() else kernel.release(candidate)


@app.get("/health")
def health() -> dict:
    settings = get_settings()
    proof_count, proof_root = store.proof_root()
    components: dict[str, dict] = {}
    if _distributed():
        services = {
            "model_orchestrator": settings.model_orchestrator_url,
            "claim_compiler": settings.claim_compiler_url,
            "proof_ledger": settings.proof_ledger_url,
            "state_service": settings.state_service_url,
            "adversarial_verifier": settings.adversarial_verifier_url,
            "approval_service": settings.approval_service_url,
            "capability_service": settings.capability_service_url,
            "provider_adapter": settings.provider_adapter_url,
            "tool_broker": settings.tool_broker_url,
            "release_sealer": settings.release_sealer_url,
        }
        for name, url in services.items():
            try:
                response = _request("GET", f"{url}/health")
                components[name] = {"ok": response.status_code == 200}
            except Exception as exc:
                components[name] = {"ok": False, "error": type(exc).__name__}
        if settings.pfrd_require_opa:
            try:
                response = httpx.get(f"{settings.opa_url.rstrip('/')}/health", timeout=5)
                components["opa"] = {"ok": response.status_code == 200}
            except Exception as exc:
                components["opa"] = {"ok": False, "error": type(exc).__name__}
    overall = all(item.get("ok", False) for item in components.values()) if components else True
    return {
        "status": "ok" if overall else "degraded",
        "service": "pfrd-gateway",
        "activation_mode": settings.pfrd_activation_mode,
        "policy_version": settings.pfrd_policy_version,
        "distributed_mode": settings.pfrd_distributed_mode,
        "sole_public_release_route": True,
        "database_ready": True,
        "proof_ledger_ready": True,
        "proof_count": proof_count,
        "proof_root": proof_root,
        "model_key_present_in_gateway": bool(settings.openai_api_key),
        "production_secret_failures": settings.validate_production_secrets(),
        "components": components,
    }


@app.post("/v1/answer", response_model=AnswerResponse, dependencies=[Depends(require_public)])
def answer(request: AnswerRequest) -> AnswerResponse:
    settings = get_settings()
    try:
        if _distributed():
            candidate = CandidateOutput.model_validate(
                _request(
                    "POST",
                    f"{settings.model_orchestrator_url}/candidate",
                    json=request.model_dump(mode="json"),
                ).json()
            )
        else:
            candidate = kernel.model_candidate(
                scope_id=request.scope_id,
                message=request.message,
                context=request.context,
            )
    except (RuntimeError, httpx.HTTPError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return _release(candidate)


@app.post("/v1/admin/release-canary", response_model=AnswerResponse, dependencies=[Depends(require_admin)])
def canary(candidate: CandidateOutput) -> AnswerResponse:
    return _release(candidate)


@app.post("/v1/admin/proofs", response_model=ProofRecord, dependencies=[Depends(require_admin)])
def create_proof(request: ProofCreate) -> ProofRecord:
    if _distributed():
        return ProofRecord.model_validate(
            _request(
                "POST",
                f"{get_settings().proof_ledger_url}/proofs",
                json=request.model_dump(mode="json"),
            ).json()
        )
    return store.issue_proof(request)


@app.get("/v1/admin/proofs", response_model=list[ProofRecord], dependencies=[Depends(require_admin)])
def list_proofs(scope_id: str | None = None) -> list[ProofRecord]:
    if _distributed():
        return [
            ProofRecord.model_validate(item)
            for item in _request(
                "GET",
                f"{get_settings().proof_ledger_url}/proofs",
                params={"scope_id": scope_id} if scope_id else {},
            ).json()
        ]
    return store.get_proofs(scope_id=scope_id)


@app.post("/v1/admin/state", response_model=StateRecord, dependencies=[Depends(require_admin)])
def set_state(request: StateRecord) -> StateRecord:
    try:
        if _distributed():
            return StateRecord.model_validate(
                _request(
                    "POST",
                    f"{get_settings().state_service_url}/states",
                    json=request.model_dump(mode="json"),
                ).json()
            )
        return store.set_state(request)
    except (ValueError, httpx.HTTPError) as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.get("/v1/admin/state/{scope_id}", response_model=StateRecord, dependencies=[Depends(require_admin)])
def get_state(scope_id: str) -> StateRecord:
    if _distributed():
        return StateRecord.model_validate(
            _request("GET", f"{get_settings().state_service_url}/states/{scope_id}").json()
        )
    return store.get_state(scope_id)


@app.post("/v1/approvals", response_model=ApprovalRecord, dependencies=[Depends(require_admin)])
def approval(request: ApprovalCreate) -> ApprovalRecord:
    try:
        if _distributed():
            return ApprovalRecord.model_validate(
                _request(
                    "POST",
                    f"{get_settings().approval_service_url}/approvals",
                    json=request.model_dump(mode="json"),
                ).json()
            )
        return store.create_approval(request)
    except (ValueError, httpx.HTTPError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/v1/capabilities", response_model=CapabilityToken, dependencies=[Depends(require_admin)])
def capability(request: CapabilityRequest) -> CapabilityToken:
    try:
        if _distributed():
            return CapabilityToken.model_validate(
                _request(
                    "POST",
                    f"{get_settings().capability_service_url}/tokens",
                    json=request.model_dump(mode="json"),
                ).json()
            )
        return issue_capability(request)
    except (ValueError, httpx.HTTPError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/v1/tools/execute", response_model=ToolResult, dependencies=[Depends(require_admin)])
def execute_tool(request: ToolRequest) -> ToolResult:
    if _distributed():
        return ToolResult.model_validate(
            _request(
                "POST",
                f"{get_settings().tool_broker_url}/execute",
                json=request.model_dump(mode="json"),
            ).json()
        )
    return broker.execute(request)


@app.get("/v1/admin/time", dependencies=[Depends(require_admin)])
def current_time() -> dict:
    return {"now": datetime.now(timezone.utc).isoformat()}
