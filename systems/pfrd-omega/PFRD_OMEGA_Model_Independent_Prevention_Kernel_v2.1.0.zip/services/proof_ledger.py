from fastapi import Depends, FastAPI
from pfrd.models import ProofCreate, ProofRecord
from pfrd.security import require_service
from pfrd.store import Store
app=FastAPI(title="PFRD Proof Ledger"); store=Store()
@app.get("/health")
def health():
    count,root=store.proof_root(); return {"status":"ok","proof_count":count,"merkle_root":root}
@app.post("/proofs",response_model=ProofRecord,dependencies=[Depends(require_service)])
def create(p:ProofCreate): return store.issue_proof(p)
@app.get("/proofs",response_model=list[ProofRecord],dependencies=[Depends(require_service)])
def list_route(scope_id:str|None=None, ids:list[str]|None=None): return store.get_proofs(scope_id=scope_id, ids=ids)
