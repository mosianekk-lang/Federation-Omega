package main

import (
	"archive/zip"
	"os"
	"path/filepath"
	"testing"
)

func makeReplicaFixture(t *testing.T) (string, *Fabric, string) {
	t.Helper()
	root := t.TempDir()
	src := filepath.Join(root, "src")
	if err := os.MkdirAll(src, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "a.txt"), []byte("A1"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "b.txt"), []byte("B1"), 0o600); err != nil {
		t.Fatal(err)
	}
	f := newFabric(filepath.Join(root, "fabric"))
	m, err := f.Bootstrap(src)
	if err != nil {
		t.Fatal(err)
	}
	c, err := f.CreateCandidate(m.ManifestID, map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	r, err := f.Admit(c.CandidateID)
	if err != nil || r.Result != "ADMITTED" {
		t.Fatal(err, r)
	}
	snap := filepath.Join(root, "replica.zip")
	if _, err := f.ExportReplicaSnapshot(snap, ""); err != nil {
		t.Fatal(err)
	}
	return root, f, snap
}

func TestReplicaRestoreAndAudit(t *testing.T) {
	root, f, snap := makeReplicaFixture(t)
	_ = f
	dest := filepath.Join(root, "restore")
	r, err := RestoreReplicaSnapshot(dest, snap)
	if err != nil {
		t.Fatal(err)
	}
	if r.Status != "RESTORED_VERIFIED" || r.AuditStatus != "PASS" {
		t.Fatalf("bad restore %#v", r)
	}
	rf := newFabric(dest)
	a, err := rf.Audit()
	if err != nil || a.Status != "ok" {
		t.Fatal(err, a)
	}
	cmp, err := rf.CompareReplicaSnapshot(snap)
	if err != nil {
		t.Fatal(err)
	}
	if cmp.Status != "SAME" {
		t.Fatal(cmp.Status)
	}
}

func TestReplicaCompareAncestorAndDivergence(t *testing.T) {
	root, f, snap := makeReplicaFixture(t)
	dest := filepath.Join(root, "restore")
	if _, err := RestoreReplicaSnapshot(dest, snap); err != nil {
		t.Fatal(err)
	}
	rf := newFabric(dest)
	rep, err := VerifyReplicaSnapshot(snap)
	if err != nil {
		t.Fatal(err)
	}
	c, err := f.CreateCandidate(rep.ManifestID, map[string][]byte{"a.txt": []byte("A3")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	r, err := f.Admit(c.CandidateID)
	if err != nil || r.Result != "ADMITTED" {
		t.Fatal(err)
	}
	old, err := f.CompareReplicaSnapshot(snap)
	if err != nil {
		t.Fatal(err)
	}
	if old.Status != "REMOTE_ANCESTOR" {
		t.Fatalf("got %s", old.Status)
	}
	c2, err := rf.CreateCandidate(rep.ManifestID, map[string][]byte{"b.txt": []byte("B3")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	r2, err := rf.Admit(c2.CandidateID)
	if err != nil || r2.Result != "ADMITTED" {
		t.Fatal(err)
	}
	newer := filepath.Join(root, "newer.zip")
	if _, err := f.ExportReplicaSnapshot(newer, ""); err != nil {
		t.Fatal(err)
	}
	div, err := rf.CompareReplicaSnapshot(newer)
	if err != nil {
		t.Fatal(err)
	}
	if div.Status != "DIVERGED" || div.CommonAncestor != rep.ManifestID {
		t.Fatalf("bad divergence %#v", div)
	}
}

func TestReplicaRestoreRejectsNonEmptyTarget(t *testing.T) {
	root, _, snap := makeReplicaFixture(t)
	dest := filepath.Join(root, "nonempty")
	if err := os.MkdirAll(dest, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dest, "x"), []byte("x"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := RestoreReplicaSnapshot(dest, snap); err == nil {
		t.Fatal("nonempty restore target accepted")
	}
}

func TestReplicaTamperedJournalRejected(t *testing.T) {
	root, _, snap := makeReplicaFixture(t)
	bad := filepath.Join(root, "bad.zip")
	zr, err := zip.OpenReader(snap)
	if err != nil {
		t.Fatal(err)
	}
	out, err := os.Create(bad)
	if err != nil {
		t.Fatal(err)
	}
	zw := zip.NewWriter(out)
	for _, zf := range zr.File {
		rc, err := zf.Open()
		if err != nil {
			t.Fatal(err)
		}
		b, err := ioReadAll(rc)
		_ = rc.Close()
		if err != nil {
			t.Fatal(err)
		}
		if zf.Name == "FUSE-JOURNAL.jsonl" && len(b) > 5 {
			b[5] ^= 1
		}
		h := zf.FileHeader
		w, err := zw.CreateHeader(&h)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := w.Write(b); err != nil {
			t.Fatal(err)
		}
	}
	_ = zr.Close()
	if err := zw.Close(); err != nil {
		t.Fatal(err)
	}
	if err := out.Close(); err != nil {
		t.Fatal(err)
	}
	if _, err := VerifyReplicaSnapshot(bad); err == nil {
		t.Fatal("tampered journal snapshot passed")
	}
}

func ioReadAll(r interface{ Read([]byte) (int, error) }) ([]byte, error) {
	var out []byte
	buf := make([]byte, 32768)
	for {
		n, err := r.Read(buf)
		if n > 0 {
			out = append(out, buf[:n]...)
		}
		if err != nil {
			if err.Error() == "EOF" {
				return out, nil
			}
			return out, err
		}
	}
}
