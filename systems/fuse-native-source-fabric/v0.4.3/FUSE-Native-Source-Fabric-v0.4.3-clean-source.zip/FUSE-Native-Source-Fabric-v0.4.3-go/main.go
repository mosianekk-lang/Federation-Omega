package main

import (
	"archive/zip"
	"bufio"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

const Version = "0.4.3"

type Manifest struct {
	ManifestID       string            `json:"manifest_id"`
	Files            map[string]string `json:"files"`
	CreatedAt        string            `json:"created_at"`
	ParentManifestID string            `json:"parent_manifest_id,omitempty"`
	Note             string            `json:"note,omitempty"`
}

type CanonicalState struct {
	ManifestID  string `json:"manifest_id"`
	Generation  uint64 `json:"generation"`
	SourceEpoch string `json:"source_epoch"`
	UpdatedAt   string `json:"updated_at"`
}

type Candidate struct {
	CandidateID     string             `json:"candidate_id"`
	BaseManifestID  string             `json:"base_manifest_id"`
	SourceEpoch     string             `json:"source_epoch"`
	Preimages       map[string]*string `json:"preimages"`
	Changes         map[string]*string `json:"changes"`
	ClaimedWriteSet []string           `json:"claimed_write_set"`
	WriteSetDigest  string             `json:"write_set_digest"`
	CreatedAt       string             `json:"created_at"`
	State           string             `json:"state"`
	Metadata        map[string]any     `json:"metadata,omitempty"`
}

type AdmissionReceipt struct {
	AdmissionID            string   `json:"admission_id"`
	TransactionID          string   `json:"transaction_id,omitempty"`
	CandidateID            string   `json:"candidate_id"`
	BaseManifestID         string   `json:"base_manifest_id"`
	SourceEpoch            string   `json:"source_epoch"`
	PriorCanonicalManifest string   `json:"prior_canonical_manifest_id"`
	NewCanonicalManifest   string   `json:"new_canonical_manifest_id,omitempty"`
	PriorGeneration        uint64   `json:"prior_generation"`
	NewGeneration          uint64   `json:"new_generation,omitempty"`
	ClaimedWriteSet        []string `json:"claimed_write_set"`
	ActualWriteSet         []string `json:"actual_write_set"`
	ObjectHashes           []string `json:"object_hashes"`
	AdmittedAt             string   `json:"admitted_at"`
	Result                 string   `json:"result"`
	Reason                 any      `json:"reason,omitempty"`
}

type AdmissionTxn struct {
	Schema      string           `json:"schema"`
	TxnID       string           `json:"txn_id"`
	AdmissionID string           `json:"admission_id"`
	CandidateID string           `json:"candidate_id"`
	PriorState  CanonicalState   `json:"prior_state"`
	NewState    CanonicalState   `json:"new_state"`
	Receipt     AdmissionReceipt `json:"receipt"`
	State       string           `json:"state"`
	PreparedAt  string           `json:"prepared_at"`
	CommittedAt string           `json:"committed_at,omitempty"`
	FinalizedAt string           `json:"finalized_at,omitempty"`
	AbortedAt   string           `json:"aborted_at,omitempty"`
	AbortReason string           `json:"abort_reason,omitempty"`
}

type RollbackReceipt struct {
	RollbackID             string `json:"rollback_id"`
	AdmissionID            string `json:"admission_id"`
	SourceEpoch            string `json:"source_epoch"`
	PriorCanonicalManifest string `json:"prior_canonical_manifest_id"`
	RolledBackManifest     string `json:"rolled_back_manifest_id"`
	PriorGeneration        uint64 `json:"prior_generation"`
	NewGeneration          uint64 `json:"new_generation"`
	RolledBackAt           string `json:"rolled_back_at"`
	Result                 string `json:"result"`
	Reason                 any    `json:"reason,omitempty"`
}

type Event struct {
	EventID   string         `json:"event_id"`
	Seq       int64          `json:"seq,omitempty"`
	PrevHash  string         `json:"prev_hash,omitempty"`
	EventHash string         `json:"event_hash,omitempty"`
	EventType string         `json:"event_type"`
	SubjectID string         `json:"subject_id"`
	Timestamp string         `json:"timestamp"`
	Payload   map[string]any `json:"payload"`
}

type AuditReport struct {
	Status                string   `json:"status"`
	Version               string   `json:"version"`
	CanonicalManifestID   string   `json:"canonical_manifest_id"`
	CanonicalFiles        int      `json:"canonical_files"`
	ObjectsVerified       int      `json:"objects_verified"`
	ManifestsVerified     int      `json:"manifests_verified"`
	JournalEventsVerified int      `json:"journal_events_verified"`
	AdmissionsVerified    int      `json:"admissions_verified"`
	AdmissionTxnsVerified int      `json:"admission_txns_verified"`
	Errors                []string `json:"errors"`
}

type SnapshotReceipt struct {
	Schema      string `json:"schema"`
	Version     string `json:"version"`
	ManifestID  string `json:"manifest_id"`
	FileCount   int    `json:"file_count"`
	SourceEpoch string `json:"source_epoch,omitempty"`
}

type Fabric struct {
	Root string
	mu   sync.Mutex
	// Test-only deterministic concurrency barrier. Nil in production.
	admitAfterReadHook func(string, CanonicalState)
	// Test-only fault injection. Nil in production.
	faultHook func(string) error
}

func newFabric(root string) *Fabric { return &Fabric{Root: root} }

func (f *Fabric) ensureDirs() error {
	for _, d := range []string{"objects", "manifests", "candidates", "candidate-contracts", "admissions", "admission-txns", "rollbacks", "locks", "checkouts", "snapshots"} {
		if err := os.MkdirAll(filepath.Join(f.Root, d), 0o700); err != nil {
			return err
		}
	}
	return nil
}

func now() string { return time.Now().UTC().Format(time.RFC3339Nano) }

func randomID() string {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}

func (f *Fabric) maybeFault(point string) error {
	if f.faultHook == nil {
		return nil
	}
	return f.faultHook(point)
}

func digestBytes(b []byte) string { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }

func atomicWrite(path string, data []byte, mode os.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), ".tmp-")
	if err != nil {
		return err
	}
	name := tmp.Name()
	defer os.Remove(name)
	if err := tmp.Chmod(mode); err != nil {
		tmp.Close()
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Rename(name, path); err != nil {
		return err
	}
	return syncDir(filepath.Dir(path))
}

func syncDir(dir string) error {
	if runtime.GOOS == "windows" {
		return nil
	}
	fh, err := os.Open(dir)
	if err != nil {
		return err
	}
	defer fh.Close()
	return fh.Sync()
}

func normRel(s string) (string, error) {
	s = strings.ReplaceAll(s, "\\", "/")
	c := path.Clean(s)
	if c == "." || c == "/" || strings.HasPrefix(c, "/") || c == ".." || strings.HasPrefix(c, "../") {
		return "", fmt.Errorf("unsafe path: %s", s)
	}
	return c, nil
}

func physicalExistingPath(p string) (string, error) {
	abs, err := filepath.Abs(p)
	if err != nil {
		return "", err
	}
	real, err := filepath.EvalSymlinks(abs)
	if err != nil {
		return "", err
	}
	return filepath.Clean(real), nil
}

func ensurePhysicalContained(rootPhysical, childPhysical string) error {
	rel, err := filepath.Rel(rootPhysical, childPhysical)
	if err != nil {
		return err
	}
	if rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) || filepath.IsAbs(rel) {
		return fmt.Errorf("physical path escapes root: %s", childPhysical)
	}
	return nil
}

func safeWriteContained(root, rel string, data []byte, mode os.FileMode) error {
	norm, err := normRel(rel)
	if err != nil {
		return err
	}
	rootPhysical, err := physicalExistingPath(root)
	if err != nil {
		return err
	}
	target := filepath.Join(root, filepath.FromSlash(norm))
	if err := os.MkdirAll(filepath.Dir(target), 0o700); err != nil {
		return err
	}
	parentPhysical, err := physicalExistingPath(filepath.Dir(target))
	if err != nil {
		return err
	}
	if err := ensurePhysicalContained(rootPhysical, parentPhysical); err != nil {
		return err
	}
	if err := os.WriteFile(target, data, mode); err != nil {
		return err
	}
	targetPhysical, err := physicalExistingPath(target)
	if err != nil {
		_ = os.Remove(target)
		return err
	}
	if err := ensurePhysicalContained(rootPhysical, targetPhysical); err != nil {
		_ = os.Remove(target)
		return err
	}
	return nil
}

func verifyExistingContained(root, child string) error {
	rootPhysical, err := physicalExistingPath(root)
	if err != nil {
		return err
	}
	childPhysical, err := physicalExistingPath(child)
	if err != nil {
		return err
	}
	return ensurePhysicalContained(rootPhysical, childPhysical)
}

func (f *Fabric) objectPath(hash string) string {
	return filepath.Join(f.Root, "objects", hash[:2], hash[2:])
}

func (f *Fabric) putBytes(b []byte) (string, error) {
	h := digestBytes(b)
	p := f.objectPath(h)
	if existing, err := os.ReadFile(p); err == nil {
		if digestBytes(existing) != h {
			return "", errors.New("existing CAS integrity mismatch")
		}
		return h, nil
	}
	if err := atomicWrite(p, b, 0o600); err != nil {
		return "", err
	}
	return h, nil
}

func (f *Fabric) getBytes(h string) ([]byte, error) {
	b, err := os.ReadFile(f.objectPath(h))
	if err != nil {
		return nil, err
	}
	if digestBytes(b) != h {
		return nil, errors.New("CAS integrity mismatch")
	}
	return b, nil
}

func manifestID(files map[string]string) string {
	keys := make([]string, 0, len(files))
	for k := range files {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	var sb strings.Builder
	for _, k := range keys {
		fmt.Fprintf(&sb, "%s\x00%s\n", k, files[k])
	}
	return digestBytes([]byte(sb.String()))
}

func (f *Fabric) saveManifest(files map[string]string, parent, note string) (Manifest, error) {
	m := Manifest{ManifestID: manifestID(files), Files: cloneMap(files), CreatedAt: now(), ParentManifestID: parent, Note: note}
	b, _ := json.MarshalIndent(m, "", "  ")
	p := filepath.Join(f.Root, "manifests", m.ManifestID+".json")
	if _, err := os.Stat(p); errors.Is(err, os.ErrNotExist) {
		if err := atomicWrite(p, b, 0o600); err != nil {
			return Manifest{}, err
		}
	}
	return m, nil
}

func cloneMap(in map[string]string) map[string]string {
	out := map[string]string{}
	for k, v := range in {
		out[k] = v
	}
	return out
}

func (f *Fabric) canonicalState() (CanonicalState, error) {
	var st CanonicalState
	b, err := os.ReadFile(filepath.Join(f.Root, "canonical.json"))
	if err != nil {
		return st, err
	}
	if err := json.Unmarshal(b, &st); err != nil {
		return st, err
	}
	if st.ManifestID == "" {
		return st, errors.New("canonical manifest missing")
	}
	// Backward-compatible read of v0.4 pointer.
	if st.Generation == 0 {
		st.Generation = 1
	}
	if st.SourceEpoch == "" {
		st.SourceEpoch = st.ManifestID
	}
	return st, nil
}

func (f *Fabric) writeCanonicalState(st CanonicalState) error {
	if st.ManifestID == "" || st.Generation == 0 || st.SourceEpoch == "" {
		return errors.New("invalid canonical state")
	}
	st.UpdatedAt = now()
	b, _ := json.MarshalIndent(st, "", "  ")
	return atomicWrite(filepath.Join(f.Root, "canonical.json"), b, 0o600)
}

func (f *Fabric) setCanonicalInitial(mid, sourceEpoch string) error {
	if sourceEpoch == "" {
		sourceEpoch = mid
	}
	return f.writeCanonicalState(CanonicalState{ManifestID: mid, Generation: 1, SourceEpoch: sourceEpoch})
}

func (f *Fabric) canonicalID() (string, error) {
	st, err := f.canonicalState()
	if err != nil {
		return "", err
	}
	return st.ManifestID, nil
}

func (f *Fabric) canonical() (Manifest, error) {
	st, err := f.canonicalState()
	if err != nil {
		return Manifest{}, err
	}
	return f.loadManifest(st.ManifestID)
}

func (f *Fabric) canonicalStateAndManifest() (CanonicalState, Manifest, error) {
	st, err := f.canonicalState()
	if err != nil {
		return st, Manifest{}, err
	}
	m, err := f.loadManifest(st.ManifestID)
	return st, m, err
}

func (f *Fabric) loadManifest(mid string) (Manifest, error) {
	var m Manifest
	b, err := os.ReadFile(filepath.Join(f.Root, "manifests", mid+".json"))
	if err != nil {
		return m, err
	}
	if err := json.Unmarshal(b, &m); err != nil {
		return m, err
	}
	if m.ManifestID != mid || manifestID(m.Files) != mid {
		return Manifest{}, errors.New("manifest integrity mismatch")
	}
	return m, nil
}

func (f *Fabric) lock(name string, timeout time.Duration) (func(), error) {
	p := filepath.Join(f.Root, "locks", name+".lock")
	deadline := time.Now().Add(timeout)
	for {
		if err := os.Mkdir(p, 0o700); err == nil {
			return func() { _ = os.Remove(p) }, nil
		}
		if time.Now().After(deadline) {
			return nil, fmt.Errorf("lock timeout: %s", name)
		}
		time.Sleep(20 * time.Millisecond)
	}
}

func eventHash(e Event) string {
	x := struct {
		EventID   string         `json:"event_id"`
		Seq       int64          `json:"seq"`
		PrevHash  string         `json:"prev_hash"`
		EventType string         `json:"event_type"`
		SubjectID string         `json:"subject_id"`
		Timestamp string         `json:"timestamp"`
		Payload   map[string]any `json:"payload"`
	}{e.EventID, e.Seq, e.PrevHash, e.EventType, e.SubjectID, e.Timestamp, e.Payload}
	b, _ := json.Marshal(x)
	return digestBytes(b)
}

func (f *Fabric) readJournalRaw() ([]Event, [][]byte, error) {
	p := filepath.Join(f.Root, "journal.jsonl")
	fh, err := os.Open(p)
	if errors.Is(err, os.ErrNotExist) {
		return []Event{}, [][]byte{}, nil
	}
	if err != nil {
		return nil, nil, err
	}
	defer fh.Close()
	events := []Event{}
	raws := [][]byte{}
	sc := bufio.NewScanner(fh)
	buf := make([]byte, 64*1024)
	sc.Buffer(buf, 4*1024*1024)
	for sc.Scan() {
		raw := append([]byte(nil), sc.Bytes()...)
		var e Event
		if err := json.Unmarshal(raw, &e); err != nil {
			return nil, nil, fmt.Errorf("journal json: %w", err)
		}
		events = append(events, e)
		raws = append(raws, raw)
	}
	if err := sc.Err(); err != nil {
		return nil, nil, err
	}
	return events, raws, nil
}

func (f *Fabric) journalTail() (seq int64, hash string, err error) {
	events, raws, err := f.readJournalRaw()
	if err != nil {
		return 0, "", err
	}
	if len(events) == 0 {
		return 0, "", nil
	}
	last := events[len(events)-1]
	if last.EventHash != "" {
		return last.Seq, last.EventHash, nil
	}
	// v0.2 migration bridge: bind first v0.3 event to exact last legacy line.
	return int64(len(events)), "legacy:" + digestBytes(raws[len(raws)-1]), nil
}

func (f *Fabric) appendEvent(t, subject string, payload map[string]any) error {
	unlock, err := f.lock("journal", 5*time.Second)
	if err != nil {
		return err
	}
	defer unlock()
	seq, prev, err := f.journalTail()
	if err != nil {
		return err
	}
	e := Event{EventID: randomID(), Seq: seq + 1, PrevHash: prev, EventType: t, SubjectID: subject, Timestamp: now(), Payload: payload}
	e.EventHash = eventHash(e)
	b, _ := json.Marshal(e)
	b = append(b, '\n')
	p := filepath.Join(f.Root, "journal.jsonl")
	fh, err := os.OpenFile(p, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0o600)
	if err != nil {
		return err
	}
	defer fh.Close()
	if _, err := fh.Write(b); err != nil {
		return err
	}
	return fh.Sync()
}

func (f *Fabric) VerifyJournal() (int, error) {
	events, raws, err := f.readJournalRaw()
	if err != nil {
		return 0, err
	}
	var priorHash string
	var priorSeq int64
	hashedStarted := false
	for i, e := range events {
		if e.EventHash == "" {
			if hashedStarted {
				return i, fmt.Errorf("legacy event after hashed chain at line %d", i+1)
			}
			priorHash = "legacy:" + digestBytes(raws[i])
			priorSeq = int64(i + 1)
			continue
		}
		hashedStarted = true
		if e.Seq != priorSeq+1 {
			return i, fmt.Errorf("journal seq mismatch line %d: got %d want %d", i+1, e.Seq, priorSeq+1)
		}
		if e.PrevHash != priorHash {
			return i, fmt.Errorf("journal prev hash mismatch line %d", i+1)
		}
		if eventHash(e) != e.EventHash {
			return i, fmt.Errorf("journal event hash mismatch line %d", i+1)
		}
		priorHash = e.EventHash
		priorSeq = e.Seq
	}
	return len(events), nil
}

func (f *Fabric) Bootstrap(source string) (Manifest, error) { return f.BootstrapAtEpoch(source, "") }

func (f *Fabric) BootstrapAtEpoch(source, sourceEpoch string) (Manifest, error) {
	if err := f.ensureDirs(); err != nil {
		return Manifest{}, err
	}
	if _, err := os.Stat(filepath.Join(f.Root, "canonical.json")); err == nil {
		return Manifest{}, errors.New("already bootstrapped")
	}
	sourcePhysical, err := physicalExistingPath(source)
	if err != nil {
		return Manifest{}, err
	}
	files := map[string]string{}
	err = filepath.WalkDir(source, func(p string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.Type()&os.ModeSymlink != 0 {
			return fmt.Errorf("symlink/reparse entry rejected: %s", p)
		}
		if d.IsDir() {
			return nil
		}
		if err := verifyExistingContained(sourcePhysical, p); err != nil {
			return err
		}
		rel, err := filepath.Rel(source, p)
		if err != nil {
			return err
		}
		rel, err = normRel(filepath.ToSlash(rel))
		if err != nil {
			return err
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		h, err := f.putBytes(b)
		if err != nil {
			return err
		}
		files[rel] = h
		return nil
	})
	if err != nil {
		return Manifest{}, err
	}
	m, err := f.saveManifest(files, "", "bootstrap")
	if err != nil {
		return Manifest{}, err
	}
	if sourceEpoch == "" {
		sourceEpoch = m.ManifestID
	}
	if err := f.setCanonicalInitial(m.ManifestID, sourceEpoch); err != nil {
		return Manifest{}, err
	}
	_ = f.appendEvent("BOOTSTRAP", m.ManifestID, map[string]any{"files": len(files), "manifest_id": m.ManifestID, "source_epoch": sourceEpoch, "generation": 1})
	return m, nil
}

func ptr(s string) *string { return &s }

func candidateContractDigest(c Candidate) string {
	x := struct {
		BaseManifestID  string             `json:"base_manifest_id"`
		SourceEpoch     string             `json:"source_epoch"`
		Preimages       map[string]*string `json:"preimages"`
		Changes         map[string]*string `json:"changes"`
		ClaimedWriteSet []string           `json:"claimed_write_set"`
	}{c.BaseManifestID, c.SourceEpoch, c.Preimages, c.Changes, c.ClaimedWriteSet}
	b, _ := json.Marshal(x)
	return digestBytes(b)
}

func (f *Fabric) candidateContractPath(cid string) string {
	return filepath.Join(f.Root, "candidate-contracts", cid+".sha256")
}

func validateWriteSetShape(c Candidate) error {
	changes := sortedKeysPtr(c.Changes)
	pre := sortedKeysPtr(c.Preimages)
	if strings.Join(changes, "\x00") != strings.Join(c.ClaimedWriteSet, "\x00") || strings.Join(pre, "\x00") != strings.Join(c.ClaimedWriteSet, "\x00") {
		return errors.New("claimed write set mismatch")
	}
	if c.WriteSetDigest == "" || c.WriteSetDigest != candidateContractDigest(c) {
		return errors.New("candidate write-set digest mismatch")
	}
	return nil
}

func (f *Fabric) validateCandidateContract(c Candidate) error {
	if c.SourceEpoch == "" {
		return errors.New("candidate source epoch missing")
	}
	if err := validateWriteSetShape(c); err != nil {
		return err
	}
	sealed, err := os.ReadFile(f.candidateContractPath(c.CandidateID))
	if err != nil {
		return fmt.Errorf("candidate contract seal: %w", err)
	}
	if strings.TrimSpace(string(sealed)) != c.WriteSetDigest {
		return errors.New("candidate contract seal mismatch")
	}
	for p, h := range c.Changes {
		if _, err := normRel(p); err != nil {
			return err
		}
		if h != nil {
			if _, err := f.getBytes(*h); err != nil {
				return err
			}
		}
	}
	return nil
}

func (f *Fabric) CreateCandidate(baseID string, sets map[string][]byte, deletes []string, meta map[string]any) (Candidate, error) {
	return f.CreateCandidateAtEpoch(baseID, "", sets, deletes, meta)
}

func (f *Fabric) CreateCandidateAtEpoch(baseID, sourceEpoch string, sets map[string][]byte, deletes []string, meta map[string]any) (Candidate, error) {
	if err := f.ensureDirs(); err != nil {
		return Candidate{}, err
	}
	st, current, err := f.canonicalStateAndManifest()
	if err != nil {
		return Candidate{}, err
	}
	if sourceEpoch == "" {
		sourceEpoch = st.SourceEpoch
	}
	if sourceEpoch != st.SourceEpoch {
		return Candidate{}, errors.New("SOURCE_EPOCH_MISMATCH")
	}
	base := current
	if baseID != "" {
		base, err = f.loadManifest(baseID)
		if err != nil {
			return Candidate{}, err
		}
	}
	pre := map[string]*string{}
	changes := map[string]*string{}
	for raw, b := range sets {
		p, err := normRel(raw)
		if err != nil {
			return Candidate{}, err
		}
		if old, ok := base.Files[p]; ok {
			pre[p] = ptr(old)
		} else {
			pre[p] = nil
		}
		h, err := f.putBytes(b)
		if err != nil {
			return Candidate{}, err
		}
		changes[p] = ptr(h)
	}
	for _, raw := range deletes {
		p, err := normRel(raw)
		if err != nil {
			return Candidate{}, err
		}
		if old, ok := base.Files[p]; ok {
			pre[p] = ptr(old)
		} else {
			pre[p] = nil
		}
		changes[p] = nil
	}
	claimed := sortedKeysPtr(changes)
	c := Candidate{CandidateID: digestBytes([]byte(base.ManifestID + sourceEpoch + randomID())), BaseManifestID: base.ManifestID, SourceEpoch: sourceEpoch, Preimages: pre, Changes: changes, ClaimedWriteSet: claimed, CreatedAt: now(), State: "READY", Metadata: meta}
	c.WriteSetDigest = candidateContractDigest(c)
	if err := validateWriteSetShape(c); err != nil {
		return Candidate{}, err
	}
	b, _ := json.MarshalIndent(c, "", "  ")
	if err := atomicWrite(filepath.Join(f.Root, "candidates", c.CandidateID+".json"), b, 0o600); err != nil {
		return Candidate{}, err
	}
	if err := atomicWrite(f.candidateContractPath(c.CandidateID), []byte(c.WriteSetDigest+"\n"), 0o400); err != nil {
		return Candidate{}, err
	}
	_ = f.appendEvent("CANDIDATE_READY", c.CandidateID, map[string]any{"base_manifest_id": c.BaseManifestID, "source_epoch": c.SourceEpoch, "claimed_write_set": claimed, "write_set_digest": c.WriteSetDigest})
	return c, nil
}

func sortedKeysPtr(m map[string]*string) []string {
	ks := make([]string, 0, len(m))
	for k := range m {
		ks = append(ks, k)
	}
	sort.Strings(ks)
	return ks
}

func (f *Fabric) loadCandidate(cid string) (Candidate, error) {
	var c Candidate
	b, err := os.ReadFile(filepath.Join(f.Root, "candidates", cid+".json"))
	if err != nil {
		return c, err
	}
	err = json.Unmarshal(b, &c)
	return c, err
}
func (f *Fabric) saveCandidate(c Candidate) error {
	b, _ := json.MarshalIndent(c, "", "  ")
	return atomicWrite(filepath.Join(f.Root, "candidates", c.CandidateID+".json"), b, 0o600)
}

func deref(p *string) string {
	if p == nil {
		return ""
	}
	return *p
}

func (f *Fabric) admissionConflict(c Candidate, st CanonicalState, conflicts []map[string]any, result string, reason any) (AdmissionReceipt, error) {
	rec := AdmissionReceipt{AdmissionID: randomID(), CandidateID: c.CandidateID, BaseManifestID: c.BaseManifestID, SourceEpoch: c.SourceEpoch, PriorCanonicalManifest: st.ManifestID, PriorGeneration: st.Generation, ClaimedWriteSet: append([]string(nil), c.ClaimedWriteSet...), ActualWriteSet: sortedKeysPtr(c.Changes), AdmittedAt: now(), Result: result, Reason: reason}
	for _, h := range c.Changes {
		if h != nil {
			rec.ObjectHashes = append(rec.ObjectHashes, *h)
		}
	}
	sort.Strings(rec.ObjectHashes)
	if result == "CONFLICT" || result == "EPOCH_CONFLICT" {
		c.State = result
		_ = f.saveCandidate(c)
	}
	_ = f.saveAdmission(rec)
	_ = f.appendEvent("ADMISSION_"+result, c.CandidateID, map[string]any{"admission_id": rec.AdmissionID, "generation": st.Generation, "source_epoch": st.SourceEpoch, "reason": reason})
	return rec, nil
}

func (f *Fabric) preimageConflicts(c Candidate, current Manifest) []map[string]any {
	conflicts := []map[string]any{}
	for p, expected := range c.Preimages {
		actual, ok := current.Files[p]
		var ap *string
		if ok {
			ap = ptr(actual)
		}
		if deref(ap) != deref(expected) || (ap == nil) != (expected == nil) {
			conflicts = append(conflicts, map[string]any{"path": p, "expected": expected, "actual": ap})
		}
	}
	sort.Slice(conflicts, func(i, j int) bool { return conflicts[i]["path"].(string) < conflicts[j]["path"].(string) })
	return conflicts
}

func sameCanonicalState(a, b CanonicalState) bool {
	return a.ManifestID == b.ManifestID && a.Generation == b.Generation && a.SourceEpoch == b.SourceEpoch
}

func (f *Fabric) admissionTxnPath(txnID string) string {
	return filepath.Join(f.Root, "admission-txns", txnID+".json")
}

func (f *Fabric) saveAdmissionTxn(txn AdmissionTxn) error {
	b, _ := json.MarshalIndent(txn, "", "  ")
	return atomicWrite(f.admissionTxnPath(txn.TxnID), b, 0o600)
}

func (f *Fabric) loadAdmissionTxn(txnID string) (AdmissionTxn, error) {
	var txn AdmissionTxn
	b, err := os.ReadFile(f.admissionTxnPath(txnID))
	if err != nil {
		return txn, err
	}
	if err := json.Unmarshal(b, &txn); err != nil {
		return txn, err
	}
	return txn, nil
}

func (f *Fabric) pendingAdmissionTxnForCandidate(candidateID string) (AdmissionTxn, bool, error) {
	ents, err := os.ReadDir(filepath.Join(f.Root, "admission-txns"))
	if errors.Is(err, os.ErrNotExist) {
		return AdmissionTxn{}, false, nil
	}
	if err != nil {
		return AdmissionTxn{}, false, err
	}
	var found *AdmissionTxn
	for _, ent := range ents {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		txn, err := f.loadAdmissionTxn(strings.TrimSuffix(ent.Name(), ".json"))
		if err != nil {
			return AdmissionTxn{}, false, err
		}
		if txn.CandidateID != candidateID || txn.State == "FINALIZED" || txn.State == "ABORTED" {
			continue
		}
		if found != nil {
			return AdmissionTxn{}, false, fmt.Errorf("multiple nonterminal admission transactions for candidate %s", candidateID)
		}
		copyTxn := txn
		found = &copyTxn
	}
	if found == nil {
		return AdmissionTxn{}, false, nil
	}
	return *found, true, nil
}

func (f *Fabric) journalHasAdmissionEvent(eventType, admissionID string) (bool, error) {
	events, _, err := f.readJournalRaw()
	if err != nil {
		return false, err
	}
	for _, e := range events {
		if e.EventType != eventType {
			continue
		}
		if v, ok := e.Payload["admission_id"]; ok && fmt.Sprint(v) == admissionID {
			return true, nil
		}
	}
	return false, nil
}

func (f *Fabric) ensureAdmissionEvent(eventType, candidateID, admissionID string, payload map[string]any) error {
	has, err := f.journalHasAdmissionEvent(eventType, admissionID)
	if err != nil {
		return err
	}
	if has {
		return nil
	}
	if payload == nil {
		payload = map[string]any{}
	}
	payload["admission_id"] = admissionID
	return f.appendEvent(eventType, candidateID, payload)
}

func (f *Fabric) manifestDescendsFrom(manifestID, ancestorID string) (bool, error) {
	seen := map[string]bool{}
	cur := manifestID
	for cur != "" {
		if cur == ancestorID {
			return true, nil
		}
		if seen[cur] {
			return false, errors.New("manifest ancestry cycle")
		}
		seen[cur] = true
		m, err := f.loadManifest(cur)
		if err != nil {
			return false, err
		}
		cur = m.ParentManifestID
	}
	return false, nil
}

func (f *Fabric) admissionTxnCanonicalCommitted(txn AdmissionTxn) (bool, error) {
	st, err := f.canonicalState()
	if err != nil {
		return false, err
	}
	if st.SourceEpoch != txn.NewState.SourceEpoch || st.Generation < txn.NewState.Generation {
		return false, nil
	}
	if st.ManifestID == txn.NewState.ManifestID {
		return true, nil
	}
	return f.manifestDescendsFrom(st.ManifestID, txn.NewState.ManifestID)
}

func (f *Fabric) abortAdmissionTxn(txn *AdmissionTxn, reason string) error {
	txn.State = "ABORTED"
	txn.AbortedAt = now()
	txn.AbortReason = reason
	rec := txn.Receipt
	rec.Result = "ABORTED_PRECOMMIT"
	rec.Reason = map[string]any{"reason": reason}
	txn.Receipt = rec
	var errs []string
	if err := f.saveAdmission(rec); err != nil {
		errs = append(errs, "receipt:"+err.Error())
	}
	if err := f.ensureAdmissionEvent("ADMISSION_ABORTED_PRECOMMIT", txn.CandidateID, txn.AdmissionID, map[string]any{"txn_id": txn.TxnID, "reason": reason}); err != nil {
		errs = append(errs, "journal:"+err.Error())
	}
	if err := f.saveAdmissionTxn(*txn); err != nil {
		errs = append(errs, "txn:"+err.Error())
	}
	if len(errs) > 0 {
		return errors.New(strings.Join(errs, ";"))
	}
	return nil
}

func (f *Fabric) finalizeAdmissionTxn(txn *AdmissionTxn) (AdmissionReceipt, error) {
	committed, err := f.admissionTxnCanonicalCommitted(*txn)
	if err != nil {
		return AdmissionReceipt{}, err
	}
	if !committed {
		return AdmissionReceipt{}, errors.New("admission transaction canonical commit not present")
	}
	rec := txn.Receipt
	rec.Result = "ADMITTED"
	if err := f.saveAdmission(rec); err != nil {
		return AdmissionReceipt{}, err
	}
	c, err := f.loadCandidate(txn.CandidateID)
	if err != nil {
		return AdmissionReceipt{}, err
	}
	c.State = "ADMITTED"
	if err := f.saveCandidate(c); err != nil {
		return AdmissionReceipt{}, err
	}
	if err := f.ensureAdmissionEvent("ADMITTED", txn.CandidateID, txn.AdmissionID, map[string]any{
		"txn_id":            txn.TxnID,
		"prior_manifest":    txn.PriorState.ManifestID,
		"new_manifest":      txn.NewState.ManifestID,
		"prior_generation":  txn.PriorState.Generation,
		"new_generation":    txn.NewState.Generation,
		"source_epoch":      txn.NewState.SourceEpoch,
		"claimed_write_set": rec.ClaimedWriteSet,
		"actual_write_set":  rec.ActualWriteSet,
	}); err != nil {
		return AdmissionReceipt{}, err
	}
	txn.State = "FINALIZED"
	txn.FinalizedAt = now()
	txn.Receipt = rec
	if err := f.saveAdmissionTxn(*txn); err != nil {
		return AdmissionReceipt{}, err
	}
	return rec, nil
}

func (f *Fabric) recoverCandidateAdmission(candidateID string) (*AdmissionReceipt, error) {
	txn, ok, err := f.pendingAdmissionTxnForCandidate(candidateID)
	if err != nil || !ok {
		return nil, err
	}
	st, err := f.canonicalState()
	if err != nil {
		return nil, err
	}
	if sameCanonicalState(st, txn.PriorState) {
		if err := f.abortAdmissionTxn(&txn, "PRECOMMIT_RECOVERY_CANONICAL_UNCHANGED"); err != nil {
			return nil, err
		}
		return nil, nil
	}
	committed, err := f.admissionTxnCanonicalCommitted(txn)
	if err != nil {
		return nil, err
	}
	if committed {
		rec, err := f.finalizeAdmissionTxn(&txn)
		if err != nil {
			return nil, err
		}
		return &rec, nil
	}
	return nil, fmt.Errorf("admission transaction %s ambiguous against current canonical state", txn.TxnID)
}

// recoverAdmissionTransactionsLocked reconciles every nonterminal admission transaction.
// The caller MUST hold the canonical-cas lock. This creates a global transaction fence:
// no unrelated admission may advance canonical state while a PREPARED/committed transaction
// is unresolved. That prevents a later disjoint admission from turning a recoverable
// precommit crash into an ambiguous transaction.
func (f *Fabric) recoverAdmissionTransactionsLocked() (map[string]int, error) {
	out := map[string]int{"finalized": 0, "aborted_precommit": 0, "already_terminal": 0}
	ents, err := os.ReadDir(filepath.Join(f.Root, "admission-txns"))
	if errors.Is(err, os.ErrNotExist) {
		return out, nil
	}
	if err != nil {
		return out, err
	}
	for _, ent := range ents {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		txn, err := f.loadAdmissionTxn(strings.TrimSuffix(ent.Name(), ".json"))
		if err != nil {
			return out, err
		}
		if txn.State == "FINALIZED" || txn.State == "ABORTED" {
			out["already_terminal"]++
			continue
		}
		st, err := f.canonicalState()
		if err != nil {
			return out, err
		}
		if sameCanonicalState(st, txn.PriorState) {
			if err := f.abortAdmissionTxn(&txn, "PRECOMMIT_RECOVERY_CANONICAL_UNCHANGED"); err != nil {
				return out, err
			}
			out["aborted_precommit"]++
			continue
		}
		committed, err := f.admissionTxnCanonicalCommitted(txn)
		if err != nil {
			return out, err
		}
		if !committed {
			return out, fmt.Errorf("admission transaction %s ambiguous against current canonical state", txn.TxnID)
		}
		if _, err := f.finalizeAdmissionTxn(&txn); err != nil {
			return out, err
		}
		out["finalized"]++
	}
	return out, nil
}

func (f *Fabric) RecoverAdmissionTransactions() (map[string]int, error) {
	if err := f.ensureDirs(); err != nil {
		return nil, err
	}
	unlockCAS, err := f.lock("canonical-cas", 10*time.Second)
	if err != nil {
		return nil, err
	}
	defer unlockCAS()
	return f.recoverAdmissionTransactionsLocked()
}

func (f *Fabric) Admit(cid string) (AdmissionReceipt, error) {
	c, err := f.loadCandidate(cid)
	if err != nil {
		return AdmissionReceipt{}, err
	}
	return f.AdmitAgainstEpoch(cid, c.SourceEpoch)
}

func (f *Fabric) AdmitAgainstEpoch(cid, expectedSourceEpoch string) (AdmissionReceipt, error) {
	// Global recovery is mandatory before candidate-specific work. It is intentionally
	// independent of cid: a crashed transaction for candidate A must be reconciled/fenced
	// before candidate B can create a new canonical generation.
	if _, err := f.RecoverAdmissionTransactions(); err != nil {
		return AdmissionReceipt{}, fmt.Errorf("global admission recovery: %w", err)
	}
	unlockCandidate, err := f.lock("candidate-"+cid, 10*time.Second)
	if err != nil {
		return AdmissionReceipt{}, err
	}
	defer unlockCandidate()
	if recovered, err := f.recoverCandidateAdmission(cid); err != nil {
		return AdmissionReceipt{}, err
	} else if recovered != nil {
		return *recovered, nil
	}
	c, err := f.loadCandidate(cid)
	if err != nil {
		return AdmissionReceipt{}, err
	}
	if c.State != "READY" {
		return AdmissionReceipt{}, fmt.Errorf("candidate not READY: %s", c.State)
	}
	if err := f.validateCandidateContract(c); err != nil {
		return AdmissionReceipt{}, err
	}
	if expectedSourceEpoch == "" || c.SourceEpoch != expectedSourceEpoch {
		return f.admissionConflict(c, CanonicalState{}, nil, "EPOCH_CONFLICT", map[string]any{"candidate_source_epoch": c.SourceEpoch, "expected_source_epoch": expectedSourceEpoch})
	}
	for attempt := 0; attempt < 32; attempt++ {
		st, current, err := f.canonicalStateAndManifest()
		if err != nil {
			return AdmissionReceipt{}, err
		}
		if st.SourceEpoch != expectedSourceEpoch {
			return f.admissionConflict(c, st, nil, "EPOCH_CONFLICT", map[string]any{"current_source_epoch": st.SourceEpoch, "expected_source_epoch": expectedSourceEpoch})
		}
		if f.admitAfterReadHook != nil {
			f.admitAfterReadHook(cid, st)
		}
		conflicts := f.preimageConflicts(c, current)
		if len(conflicts) > 0 {
			return f.admissionConflict(c, st, conflicts, "CONFLICT", map[string]any{"conflicts": conflicts})
		}
		files := cloneMap(current.Files)
		for p, h := range c.Changes {
			if h == nil {
				delete(files, p)
			} else {
				files[p] = *h
			}
		}
		m, err := f.saveManifest(files, current.ManifestID, "admit:"+c.CandidateID)
		if err != nil {
			return AdmissionReceipt{}, err
		}
		unlockCAS, err := f.lock("canonical-cas", 10*time.Second)
		if err != nil {
			return AdmissionReceipt{}, err
		}
		// Close the race between the initial global recovery and this CAS section.
		// Any PREPARED transaction created/crashed in that interval is resolved now,
		// while canonical state is fenced, before this admission may proceed.
		if _, err := f.recoverAdmissionTransactionsLocked(); err != nil {
			unlockCAS()
			return AdmissionReceipt{}, fmt.Errorf("global admission fence: %w", err)
		}
		latest, err := f.canonicalState()
		if err != nil {
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if latest.ManifestID != st.ManifestID || latest.Generation != st.Generation || latest.SourceEpoch != st.SourceEpoch {
			unlockCAS()
			continue
		}
		newState := CanonicalState{ManifestID: m.ManifestID, Generation: st.Generation + 1, SourceEpoch: st.SourceEpoch}
		txnID := randomID()
		admissionID := randomID()
		rec := AdmissionReceipt{AdmissionID: admissionID, TransactionID: txnID, CandidateID: c.CandidateID, BaseManifestID: c.BaseManifestID, SourceEpoch: c.SourceEpoch, PriorCanonicalManifest: st.ManifestID, NewCanonicalManifest: m.ManifestID, PriorGeneration: st.Generation, NewGeneration: newState.Generation, ClaimedWriteSet: append([]string(nil), c.ClaimedWriteSet...), ActualWriteSet: sortedKeysPtr(c.Changes), AdmittedAt: now(), Result: "PREPARED"}
		for _, h := range c.Changes {
			if h != nil {
				rec.ObjectHashes = append(rec.ObjectHashes, *h)
			}
		}
		sort.Strings(rec.ObjectHashes)
		txn := AdmissionTxn{Schema: "FNSF_ADMISSION_TXN_V1", TxnID: txnID, AdmissionID: admissionID, CandidateID: c.CandidateID, PriorState: st, NewState: newState, Receipt: rec, State: "PREPARED", PreparedAt: now()}
		if err := f.maybeFault("before_admission_txn_prepare"); err != nil {
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if err := f.saveAdmissionTxn(txn); err != nil {
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if err := f.saveAdmission(rec); err != nil {
			txn.State = "ABORTED"
			txn.AbortedAt = now()
			txn.AbortReason = "PREPARED_RECEIPT_WRITE_FAILED"
			_ = f.saveAdmissionTxn(txn)
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if err := f.ensureAdmissionEvent("ADMISSION_PREPARED", c.CandidateID, admissionID, map[string]any{"txn_id": txnID, "prior_manifest": st.ManifestID, "new_manifest": newState.ManifestID, "prior_generation": st.Generation, "new_generation": newState.Generation, "source_epoch": st.SourceEpoch}); err != nil {
			_ = f.abortAdmissionTxn(&txn, "PREPARED_JOURNAL_WRITE_FAILED")
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if err := f.maybeFault("after_admission_prepare_before_canonical"); err != nil {
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if err := f.writeCanonicalState(newState); err != nil {
			_ = f.abortAdmissionTxn(&txn, "CANONICAL_WRITE_FAILED")
			unlockCAS()
			return AdmissionReceipt{}, err
		}
		if err := f.maybeFault("after_canonical_commit_before_finalize"); err != nil {
			unlockCAS()
			return AdmissionReceipt{}, fmt.Errorf("canonical committed; admission recovery required: %w", err)
		}
		txn.State = "CANONICAL_COMMITTED"
		txn.CommittedAt = now()
		if err := f.saveAdmissionTxn(txn); err != nil {
			unlockCAS()
			return AdmissionReceipt{}, fmt.Errorf("canonical committed; admission recovery required: %w", err)
		}
		finalRec, err := f.finalizeAdmissionTxn(&txn)
		unlockCAS()
		if err != nil {
			return AdmissionReceipt{}, fmt.Errorf("canonical committed; admission recovery required: %w", err)
		}
		return finalRec, nil
	}
	st, _, _ := f.canonicalStateAndManifest()
	return f.admissionConflict(c, st, nil, "CAS_RETRY_EXHAUSTED", map[string]any{"attempts": 32})
}

func (f *Fabric) loadAdmission(id string) (AdmissionReceipt, error) {
	var r AdmissionReceipt
	b, err := os.ReadFile(filepath.Join(f.Root, "admissions", id+".json"))
	if err != nil {
		return r, err
	}
	err = json.Unmarshal(b, &r)
	return r, err
}

func (f *Fabric) RollbackAdmission(admissionID string) (RollbackReceipt, error) {
	r, err := f.loadAdmission(admissionID)
	if err != nil {
		return RollbackReceipt{}, err
	}
	if r.Result == "PREPARED" && r.TransactionID != "" {
		txn, err := f.loadAdmissionTxn(r.TransactionID)
		if err != nil {
			return RollbackReceipt{}, err
		}
		committed, err := f.admissionTxnCanonicalCommitted(txn)
		if err != nil {
			return RollbackReceipt{}, err
		}
		if committed {
			r, err = f.finalizeAdmissionTxn(&txn)
			if err != nil {
				return RollbackReceipt{}, err
			}
		}
	}
	if r.Result != "ADMITTED" {
		return RollbackReceipt{}, errors.New("admission not rollback-eligible")
	}
	unlock, err := f.lock("canonical-cas", 10*time.Second)
	if err != nil {
		return RollbackReceipt{}, err
	}
	defer unlock()
	st, err := f.canonicalState()
	if err != nil {
		return RollbackReceipt{}, err
	}
	out := RollbackReceipt{RollbackID: randomID(), AdmissionID: r.AdmissionID, SourceEpoch: r.SourceEpoch, PriorCanonicalManifest: st.ManifestID, RolledBackManifest: r.PriorCanonicalManifest, PriorGeneration: st.Generation, RolledBackAt: now()}
	if st.SourceEpoch != r.SourceEpoch || st.ManifestID != r.NewCanonicalManifest {
		out.Result = "ROLLBACK_CONFLICT"
		out.Reason = map[string]any{"current_manifest": st.ManifestID, "expected_manifest": r.NewCanonicalManifest, "current_source_epoch": st.SourceEpoch, "expected_source_epoch": r.SourceEpoch}
		return out, nil
	}
	if _, err := f.loadManifest(r.PriorCanonicalManifest); err != nil {
		return RollbackReceipt{}, err
	}
	newSt := CanonicalState{ManifestID: r.PriorCanonicalManifest, Generation: st.Generation + 1, SourceEpoch: st.SourceEpoch}
	if err := f.writeCanonicalState(newSt); err != nil {
		return RollbackReceipt{}, err
	}
	out.NewGeneration = newSt.Generation
	out.Result = "ROLLED_BACK"
	b, _ := json.MarshalIndent(out, "", "  ")
	_ = atomicWrite(filepath.Join(f.Root, "rollbacks", out.RollbackID+".json"), b, 0o600)
	_ = f.appendEvent("ADMISSION_ROLLED_BACK", r.CandidateID, map[string]any{"rollback_id": out.RollbackID, "admission_id": r.AdmissionID, "from_manifest": st.ManifestID, "to_manifest": r.PriorCanonicalManifest, "prior_generation": st.Generation, "new_generation": newSt.Generation, "source_epoch": st.SourceEpoch})
	return out, nil
}

func (f *Fabric) saveAdmission(r AdmissionReceipt) error {
	b, _ := json.MarshalIndent(r, "", "  ")
	return atomicWrite(filepath.Join(f.Root, "admissions", r.AdmissionID+".json"), b, 0o600)
}

func (f *Fabric) Checkout(mid, dest string) error {
	var m Manifest
	var err error
	if mid == "" {
		m, err = f.canonical()
	} else {
		m, err = f.loadManifest(mid)
	}
	if err != nil {
		return err
	}
	tmp := dest + ".tmp-" + randomID()
	if err := os.MkdirAll(tmp, 0o700); err != nil {
		return err
	}
	defer os.RemoveAll(tmp)
	for rel, h := range m.Files {
		b, err := f.getBytes(h)
		if err != nil {
			return err
		}
		if err := safeWriteContained(tmp, rel, b, 0o600); err != nil {
			return err
		}
	}
	marker, _ := json.MarshalIndent(map[string]any{"manifest_id": m.ManifestID, "files": len(m.Files), "materialized_at": now()}, "", "  ")
	_ = safeWriteContained(tmp, ".fuse-manifest.json", marker, 0o600)
	_ = os.RemoveAll(dest)
	return os.Rename(tmp, dest)
}

func (f *Fabric) Status() (map[string]any, error) {
	m, err := f.canonical()
	if err != nil {
		return nil, err
	}
	counts := map[string]int{}
	ents, _ := os.ReadDir(filepath.Join(f.Root, "candidates"))
	for _, e := range ents {
		if e.IsDir() {
			continue
		}
		c, err := f.loadCandidate(strings.TrimSuffix(e.Name(), ".json"))
		if err == nil {
			counts[c.State]++
		}
	}
	events, jerr := f.VerifyJournal()
	journalStatus := "ok"
	if jerr != nil {
		journalStatus = "fail"
	}
	st, _ := f.canonicalState()
	return map[string]any{"status": "ok", "version": Version, "canonical_manifest_id": m.ManifestID, "canonical_generation": st.Generation, "source_epoch": st.SourceEpoch, "canonical_files": len(m.Files), "candidate_states": counts, "journal_events": events, "journal_integrity": journalStatus}, nil
}

func (f *Fabric) Journal(limit int) ([]Event, error) {
	if _, err := f.VerifyJournal(); err != nil {
		return nil, err
	}
	all, _, err := f.readJournalRaw()
	if err != nil {
		return nil, err
	}
	if limit > 0 && len(all) > limit {
		all = all[len(all)-limit:]
	}
	return all, nil
}

func (f *Fabric) auditAdmissionBindings(rep *AuditReport) {
	admissions := map[string]AdmissionReceipt{}
	admissionEntries, err := os.ReadDir(filepath.Join(f.Root, "admissions"))
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		rep.Errors = append(rep.Errors, "admissions_read:"+err.Error())
		return
	}
	for _, ent := range admissionEntries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		id := strings.TrimSuffix(ent.Name(), ".json")
		r, err := f.loadAdmission(id)
		if err != nil {
			rep.Errors = append(rep.Errors, "admission_read:"+id)
			continue
		}
		admissions[id] = r
		if r.Result == "PREPARED" {
			rep.Errors = append(rep.Errors, "admission_receipt_nonterminal:"+id)
		}
		if r.Result == "ADMITTED" && r.TransactionID != "" {
			txn, err := f.loadAdmissionTxn(r.TransactionID)
			if err != nil {
				rep.Errors = append(rep.Errors, "admission_txn_missing:"+r.TransactionID)
				continue
			}
			if txn.State != "FINALIZED" || txn.AdmissionID != r.AdmissionID || txn.CandidateID != r.CandidateID || txn.NewState.ManifestID != r.NewCanonicalManifest || txn.NewState.Generation != r.NewGeneration {
				rep.Errors = append(rep.Errors, "admission_txn_cross_binding:"+r.TransactionID)
				continue
			}
			has, err := f.journalHasAdmissionEvent("ADMITTED", r.AdmissionID)
			if err != nil || !has {
				rep.Errors = append(rep.Errors, "admission_journal_cross_binding:"+r.AdmissionID)
				continue
			}
			rep.AdmissionsVerified++
		}
	}

	txnEntries, err := os.ReadDir(filepath.Join(f.Root, "admission-txns"))
	if err != nil && !errors.Is(err, os.ErrNotExist) {
		rep.Errors = append(rep.Errors, "admission_txns_read:"+err.Error())
		return
	}
	for _, ent := range txnEntries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		id := strings.TrimSuffix(ent.Name(), ".json")
		txn, err := f.loadAdmissionTxn(id)
		if err != nil {
			rep.Errors = append(rep.Errors, "admission_txn_read:"+id)
			continue
		}
		switch txn.State {
		case "FINALIZED":
			r, ok := admissions[txn.AdmissionID]
			if !ok || r.Result != "ADMITTED" || r.TransactionID != txn.TxnID {
				rep.Errors = append(rep.Errors, "admission_txn_receipt_cross_binding:"+id)
				continue
			}
			has, err := f.journalHasAdmissionEvent("ADMITTED", txn.AdmissionID)
			if err != nil || !has {
				rep.Errors = append(rep.Errors, "admission_txn_journal_cross_binding:"+id)
				continue
			}
			rep.AdmissionTxnsVerified++
		case "ABORTED":
			rep.AdmissionTxnsVerified++
		default:
			rep.Errors = append(rep.Errors, "admission_txn_nonterminal:"+id+":"+txn.State)
		}
	}
}

func (f *Fabric) Audit() (AuditReport, error) {
	rep := AuditReport{Status: "ok", Version: Version, Errors: []string{}}
	m, err := f.canonical()
	if err != nil {
		rep.Status = "fail"
		rep.Errors = append(rep.Errors, "canonical:"+err.Error())
		return rep, errors.New("audit failed")
	}
	rep.CanonicalManifestID = m.ManifestID
	rep.CanonicalFiles = len(m.Files)
	if st, err := f.canonicalState(); err != nil || st.Generation == 0 || st.SourceEpoch == "" {
		rep.Errors = append(rep.Errors, "canonical_state_invalid")
	}
	manifestEntries, err := os.ReadDir(filepath.Join(f.Root, "manifests"))
	if err != nil {
		return rep, err
	}
	referenced := map[string]bool{}
	for _, ent := range manifestEntries {
		if ent.IsDir() || !strings.HasSuffix(ent.Name(), ".json") {
			continue
		}
		mid := strings.TrimSuffix(ent.Name(), ".json")
		mm, err := f.loadManifest(mid)
		if err != nil {
			rep.Errors = append(rep.Errors, "manifest_read:"+mid)
			continue
		}
		if manifestID(mm.Files) != mm.ManifestID || mm.ManifestID != mid {
			rep.Errors = append(rep.Errors, "manifest_integrity:"+mid)
			continue
		}
		rep.ManifestsVerified++
		for _, h := range mm.Files {
			referenced[h] = true
		}
	}
	for h := range referenced {
		if _, err := f.getBytes(h); err != nil {
			rep.Errors = append(rep.Errors, "object_integrity:"+h)
			continue
		}
		rep.ObjectsVerified++
	}
	n, jerr := f.VerifyJournal()
	if jerr != nil {
		rep.Errors = append(rep.Errors, "journal_integrity:"+jerr.Error())
	} else {
		rep.JournalEventsVerified = n
	}
	f.auditAdmissionBindings(&rep)
	if len(rep.Errors) > 0 {
		rep.Status = "fail"
		return rep, errors.New("audit failed")
	}
	return rep, nil
}

func fixedZipHeader(name string, mode os.FileMode) *zip.FileHeader {
	h := &zip.FileHeader{Name: name, Method: zip.Deflate}
	h.SetMode(mode)
	h.Modified = time.Date(1980, 1, 1, 0, 0, 0, 0, time.UTC)
	return h
}

func (f *Fabric) ExportSnapshot(mid, dest, sourceEpoch string) (SnapshotReceipt, error) {
	st, err := f.canonicalState()
	if err != nil {
		return SnapshotReceipt{}, err
	}
	if sourceEpoch == "" {
		sourceEpoch = st.SourceEpoch
	}
	if sourceEpoch != st.SourceEpoch {
		return SnapshotReceipt{}, errors.New("SOURCE_EPOCH_MISMATCH")
	}
	var m Manifest
	if mid == "" {
		m, err = f.canonical()
	} else {
		m, err = f.loadManifest(mid)
	}
	if err != nil {
		return SnapshotReceipt{}, err
	}
	if err := os.MkdirAll(filepath.Dir(dest), 0o700); err != nil {
		return SnapshotReceipt{}, err
	}
	tmp := dest + ".tmp-" + randomID()
	out, err := os.Create(tmp)
	if err != nil {
		return SnapshotReceipt{}, err
	}
	zw := zip.NewWriter(out)
	fail := func(e error) (SnapshotReceipt, error) {
		_ = zw.Close()
		_ = out.Close()
		_ = os.Remove(tmp)
		return SnapshotReceipt{}, e
	}
	keys := make([]string, 0, len(m.Files))
	for k := range m.Files {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, rel := range keys {
		b, err := f.getBytes(m.Files[rel])
		if err != nil {
			return fail(err)
		}
		h := fixedZipHeader("source/"+rel, 0o600)
		w, err := zw.CreateHeader(h)
		if err != nil {
			return fail(err)
		}
		if _, err := w.Write(b); err != nil {
			return fail(err)
		}
	}
	manifestBytes, _ := json.MarshalIndent(m, "", "  ")
	mh := fixedZipHeader("FUSE-MANIFEST.json", 0o600)
	mw, err := zw.CreateHeader(mh)
	if err != nil {
		return fail(err)
	}
	if _, err := mw.Write(manifestBytes); err != nil {
		return fail(err)
	}
	receipt := SnapshotReceipt{Schema: "FUSE_NATIVE_SOURCE_SNAPSHOT_V1", Version: Version, ManifestID: m.ManifestID, FileCount: len(m.Files), SourceEpoch: sourceEpoch}
	rb, _ := json.MarshalIndent(receipt, "", "  ")
	rh := fixedZipHeader("FUSE-SNAPSHOT-RECEIPT.json", 0o600)
	rw, err := zw.CreateHeader(rh)
	if err != nil {
		return fail(err)
	}
	if _, err := rw.Write(rb); err != nil {
		return fail(err)
	}
	if err := zw.Close(); err != nil {
		return fail(err)
	}
	if err := out.Sync(); err != nil {
		_ = out.Close()
		_ = os.Remove(tmp)
		return SnapshotReceipt{}, err
	}
	if err := out.Close(); err != nil {
		_ = os.Remove(tmp)
		return SnapshotReceipt{}, err
	}
	if err := os.Rename(tmp, dest); err != nil {
		_ = os.Remove(tmp)
		return SnapshotReceipt{}, err
	}
	_ = f.appendEvent("SNAPSHOT_EXPORTED", m.ManifestID, map[string]any{"dest": dest, "files": len(m.Files), "source_epoch": sourceEpoch})
	return receipt, nil
}

func VerifySnapshotBundle(bundle string) (SnapshotReceipt, error) {
	zr, err := zip.OpenReader(bundle)
	if err != nil {
		return SnapshotReceipt{}, err
	}
	defer zr.Close()
	var m Manifest
	var receipt SnapshotReceipt
	source := map[string][]byte{}
	for _, zf := range zr.File {
		rc, err := zf.Open()
		if err != nil {
			return receipt, err
		}
		b, err := io.ReadAll(rc)
		_ = rc.Close()
		if err != nil {
			return receipt, err
		}
		switch zf.Name {
		case "FUSE-MANIFEST.json":
			if err := json.Unmarshal(b, &m); err != nil {
				return receipt, err
			}
		case "FUSE-SNAPSHOT-RECEIPT.json":
			if err := json.Unmarshal(b, &receipt); err != nil {
				return receipt, err
			}
		default:
			if strings.HasPrefix(zf.Name, "source/") {
				source[strings.TrimPrefix(zf.Name, "source/")] = b
			}
		}
	}
	if m.ManifestID == "" || receipt.ManifestID == "" {
		return receipt, errors.New("snapshot metadata missing")
	}
	if manifestID(m.Files) != m.ManifestID {
		return receipt, errors.New("snapshot manifest integrity mismatch")
	}
	if receipt.ManifestID != m.ManifestID {
		return receipt, errors.New("snapshot receipt manifest mismatch")
	}
	if receipt.FileCount != len(m.Files) {
		return receipt, errors.New("snapshot receipt file count mismatch")
	}
	if len(source) != len(m.Files) {
		return receipt, errors.New("snapshot source file count mismatch")
	}
	for rel, h := range m.Files {
		b, ok := source[rel]
		if !ok {
			return receipt, fmt.Errorf("snapshot missing source file: %s", rel)
		}
		if digestBytes(b) != h {
			return receipt, fmt.Errorf("snapshot source hash mismatch: %s", rel)
		}
	}
	return receipt, nil
}

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	if err := os.MkdirAll(filepath.Dir(dst), 0o700); err != nil {
		return err
	}
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	_, err = io.Copy(out, in)
	cerr := out.Close()
	if err != nil {
		return err
	}
	return cerr
}

func ensureToken(root string) (string, string, error) {
	p := filepath.Join(root, "service.token")
	if b, err := os.ReadFile(p); err == nil {
		return strings.TrimSpace(string(b)), p, nil
	}
	buf := make([]byte, 32)
	if _, err := rand.Read(buf); err != nil {
		return "", "", err
	}
	tok := base64.RawURLEncoding.EncodeToString(buf)
	if err := atomicWrite(p, []byte(tok+"\n"), 0o600); err != nil {
		return "", "", err
	}
	return tok, p, nil
}

func serve(f *Fabric, listen string) error {
	if err := f.ensureDirs(); err != nil {
		return err
	}
	if _, err := f.RecoverAdmissionTransactions(); err != nil {
		return fmt.Errorf("admission recovery: %w", err)
	}
	token, tokenFile, err := ensureToken(f.Root)
	if err != nil {
		return err
	}
	mux := http.NewServeMux()
	auth := func(next http.HandlerFunc) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			if r.Header.Get("Authorization") != "Bearer "+token {
				writeJSON(w, 401, map[string]any{"error": "unauthorized"})
				return
			}
			next(w, r)
		}
	}
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, 200, map[string]any{"status": "ok", "service": "fuse-native-source-fabric", "version": Version})
	})
	mux.HandleFunc("/v1/status", auth(func(w http.ResponseWriter, r *http.Request) {
		s, e := f.Status()
		if e != nil {
			writeJSON(w, 500, map[string]any{"error": e.Error()})
			return
		}
		writeJSON(w, 200, s)
	}))
	mux.HandleFunc("/v1/canonical", auth(func(w http.ResponseWriter, r *http.Request) {
		m, e := f.canonical()
		if e != nil {
			writeJSON(w, 500, map[string]any{"error": e.Error()})
			return
		}
		writeJSON(w, 200, m)
	}))
	mux.HandleFunc("/v1/journal", auth(func(w http.ResponseWriter, r *http.Request) {
		e, er := f.Journal(100)
		if er != nil {
			writeJSON(w, 500, map[string]any{"error": er.Error()})
			return
		}
		writeJSON(w, 200, map[string]any{"events": e})
	}))
	fmt.Printf("{\"status\":\"READY\",\"listen\":%q,\"token_file\":%q}\n", listen, tokenFile)
	return http.ListenAndServe(listen, mux)
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	b, _ := json.Marshal(v)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_, _ = w.Write(b)
}

type stringList []string

func (s *stringList) String() string     { return strings.Join(*s, ",") }
func (s *stringList) Set(v string) error { *s = append(*s, v); return nil }

func usage() {
	fmt.Fprintf(os.Stderr, "FUSE Native Source Fabric %s\ncommands: init status candidate admit rollback recover-admissions checkout mirror audit export verify-export replica-export replica-verify replica-compare replica-restore serve selftest\n", Version)
}

func main() {
	if len(os.Args) < 2 {
		usage()
		os.Exit(2)
	}
	cmd := os.Args[1]
	switch cmd {
	case "init":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		src := fs.String("source", "", "source directory")
		epoch := fs.String("source-epoch", "", "immutable external source epoch")
		_ = fs.Parse(os.Args[2:])
		require(*root, *src)
		f := newFabric(*root)
		m, err := f.BootstrapAtEpoch(*src, *epoch)
		mustJSON(m, err)
	case "status":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		_ = fs.Parse(os.Args[2:])
		require(*root)
		s, err := newFabric(*root).Status()
		mustJSON(s, err)
	case "candidate":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		base := fs.String("base", "", "base manifest")
		epoch := fs.String("source-epoch", "", "expected source epoch")
		var sets, deletes stringList
		fs.Var(&sets, "set", "rel=sourcefile repeatable")
		fs.Var(&deletes, "delete", "relative path repeatable")
		_ = fs.Parse(os.Args[2:])
		require(*root)
		data := map[string][]byte{}
		for _, x := range sets {
			parts := strings.SplitN(x, "=", 2)
			if len(parts) != 2 {
				fatal("bad --set")
			}
			b, err := os.ReadFile(parts[1])
			if err != nil {
				fatal(err.Error())
			}
			data[parts[0]] = b
		}
		c, err := newFabric(*root).CreateCandidateAtEpoch(*base, *epoch, data, deletes, nil)
		mustJSON(c, err)
	case "admit":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		cid := fs.String("candidate", "", "candidate id")
		epoch := fs.String("source-epoch", "", "required source epoch")
		_ = fs.Parse(os.Args[2:])
		require(*root, *cid, *epoch)
		r, err := newFabric(*root).AdmitAgainstEpoch(*cid, *epoch)
		mustJSON(r, err)
		if r.Result != "ADMITTED" {
			os.Exit(3)
		}
	case "rollback":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		aid := fs.String("admission", "", "admission id")
		_ = fs.Parse(os.Args[2:])
		require(*root, *aid)
		r, err := newFabric(*root).RollbackAdmission(*aid)
		mustJSON(r, err)
		if r.Result != "ROLLED_BACK" {
			os.Exit(3)
		}
	case "recover-admissions":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		_ = fs.Parse(os.Args[2:])
		require(*root)
		f := newFabric(*root)
		fatalIf(f.ensureDirs())
		r, err := f.RecoverAdmissionTransactions()
		mustJSON(r, err)
	case "checkout":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		mid := fs.String("manifest", "", "manifest id")
		dest := fs.String("dest", "", "destination")
		_ = fs.Parse(os.Args[2:])
		require(*root, *dest)
		err := newFabric(*root).Checkout(*mid, *dest)
		mustJSON(map[string]any{"status": "ok", "dest": *dest}, err)
	case "mirror":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		dest := fs.String("dest", "", "destination")
		_ = fs.Parse(os.Args[2:])
		require(*root, *dest)
		f := newFabric(*root)
		err := f.Checkout("", *dest)
		if err == nil {
			m, _ := f.canonical()
			receipt := map[string]any{"mirror": "filesystem", "manifest_id": m.ManifestID, "path": *dest, "exported_at": now()}
			b, _ := json.MarshalIndent(receipt, "", "  ")
			err = os.WriteFile(filepath.Join(*dest, ".fuse-mirror-receipt.json"), b, 0o600)
		}
		mustJSON(map[string]any{"status": "ok", "dest": *dest}, err)
	case "audit":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		_ = fs.Parse(os.Args[2:])
		require(*root)
		rep, err := newFabric(*root).Audit()
		mustJSON(rep, err)
	case "export":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		mid := fs.String("manifest", "", "manifest id")
		dest := fs.String("dest", "", "zip destination")
		epoch := fs.String("source-epoch", "", "source epoch label")
		_ = fs.Parse(os.Args[2:])
		require(*root, *dest)
		rep, err := newFabric(*root).ExportSnapshot(*mid, *dest, *epoch)
		mustJSON(rep, err)
	case "verify-export":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		bundle := fs.String("bundle", "", "snapshot zip")
		_ = fs.Parse(os.Args[2:])
		require(*bundle)
		rep, err := VerifySnapshotBundle(*bundle)
		mustJSON(rep, err)
	case "replica-export":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		dest := fs.String("dest", "", "replica snapshot zip")
		epoch := fs.String("source-epoch", "", "source epoch label")
		_ = fs.Parse(os.Args[2:])
		require(*root, *dest)
		rep, err := newFabric(*root).ExportReplicaSnapshot(*dest, *epoch)
		mustJSON(rep, err)
	case "replica-verify":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		bundle := fs.String("bundle", "", "replica snapshot zip")
		_ = fs.Parse(os.Args[2:])
		require(*bundle)
		rep, err := VerifyReplicaSnapshot(*bundle)
		mustJSON(rep, err)
	case "replica-compare":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		bundle := fs.String("bundle", "", "replica snapshot zip")
		_ = fs.Parse(os.Args[2:])
		require(*root, *bundle)
		rep, err := newFabric(*root).CompareReplicaSnapshot(*bundle)
		mustJSON(rep, err)
	case "replica-restore":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "empty target state root")
		bundle := fs.String("bundle", "", "replica snapshot zip")
		_ = fs.Parse(os.Args[2:])
		require(*root, *bundle)
		rep, err := RestoreReplicaSnapshot(*root, *bundle)
		mustJSON(rep, err)
	case "serve":
		fs := flag.NewFlagSet(cmd, flag.ExitOnError)
		root := fs.String("root", "", "state root")
		listen := fs.String("listen", "127.0.0.1:8765", "listen address")
		_ = fs.Parse(os.Args[2:])
		require(*root)
		fatalIf(serve(newFabric(*root), *listen))
	case "selftest":
		fatalIf(selfTest())
	default:
		usage()
		os.Exit(2)
	}
}

func require(xs ...string) {
	for _, x := range xs {
		if x == "" {
			fatal("missing required argument")
		}
	}
}
func fatal(s string) { fmt.Fprintln(os.Stderr, s); os.Exit(1) }
func fatalIf(err error) {
	if err != nil {
		fatal(err.Error())
	}
}
func mustJSON(v any, err error) {
	if err != nil {
		fatal(err.Error())
	}
	b, _ := json.MarshalIndent(v, "", "  ")
	fmt.Println(string(b))
}

func selfTest() error {
	root, err := os.MkdirTemp("", "fuse-source-fabric-selftest-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(root)
	src := filepath.Join(root, "src")
	_ = os.MkdirAll(src, 0o700)
	_ = os.WriteFile(filepath.Join(src, "a.txt"), []byte("A1"), 0o600)
	_ = os.WriteFile(filepath.Join(src, "b.txt"), []byte("B1"), 0o600)
	f := newFabric(filepath.Join(root, "fabric"))
	m, err := f.BootstrapAtEpoch(src, "SELFTEST-EPOCH")
	if err != nil {
		return err
	}
	c1, _ := f.CreateCandidateAtEpoch(m.ManifestID, "SELFTEST-EPOCH", map[string][]byte{"a.txt": []byte("A2")}, nil, map[string]any{"lane": "A"})
	c2, _ := f.CreateCandidateAtEpoch(m.ManifestID, "SELFTEST-EPOCH", map[string][]byte{"b.txt": []byte("B2")}, nil, map[string]any{"lane": "B"})
	var wg sync.WaitGroup
	wg.Add(2)
	start := make(chan struct{})
	var r1, r2 AdmissionReceipt
	var e1, e2 error
	go func() { defer wg.Done(); <-start; r1, e1 = f.AdmitAgainstEpoch(c1.CandidateID, "SELFTEST-EPOCH") }()
	go func() { defer wg.Done(); <-start; r2, e2 = f.AdmitAgainstEpoch(c2.CandidateID, "SELFTEST-EPOCH") }()
	close(start)
	wg.Wait()
	if e1 != nil || e2 != nil {
		return fmt.Errorf("concurrent admission error %v %v", e1, e2)
	}
	if r1.Result != "ADMITTED" || r2.Result != "ADMITTED" {
		return errors.New("concurrent disjoint admission failed")
	}
	c3, _ := f.CreateCandidateAtEpoch(m.ManifestID, "SELFTEST-EPOCH", map[string][]byte{"a.txt": []byte("A3")}, nil, nil)
	r3, err := f.AdmitAgainstEpoch(c3.CandidateID, "SELFTEST-EPOCH")
	if err != nil {
		return err
	}
	if r3.Result != "CONFLICT" {
		return errors.New("stale overlap did not conflict")
	}
	out := filepath.Join(root, "out")
	if err := f.Checkout("", out); err != nil {
		return err
	}
	a, _ := os.ReadFile(filepath.Join(out, "a.txt"))
	b, _ := os.ReadFile(filepath.Join(out, "b.txt"))
	if string(a) != "A2" || string(b) != "B2" {
		return errors.New("concurrent merge lost change")
	}
	if rep, err := f.Audit(); err != nil || rep.Status != "ok" {
		return fmt.Errorf("audit court failed: %v %#v", err, rep)
	}
	bundle := filepath.Join(root, "snapshot.zip")
	snap, err := f.ExportSnapshot("", bundle, "SELFTEST-EPOCH")
	if err != nil {
		return err
	}
	snap2, err := VerifySnapshotBundle(bundle)
	if err != nil {
		return err
	}
	if snap.ManifestID != snap2.ManifestID {
		return errors.New("snapshot verification mismatch")
	}
	if err := replicaSelfTest(root, f); err != nil {
		return err
	}
	fmt.Printf("{\"selftest\":\"PASS\",\"version\":%q,\"concurrent_disjoint_admissions\":2,\"stale_overlap_conflicts\":1,\"source_epoch\":\"PASS\",\"generation_cas\":\"PASS\",\"audit\":\"PASS\",\"snapshot\":\"PASS\",\"replica_restore\":\"PASS\",\"anti_entropy\":\"PASS\"}\n", Version)
	return nil
}
