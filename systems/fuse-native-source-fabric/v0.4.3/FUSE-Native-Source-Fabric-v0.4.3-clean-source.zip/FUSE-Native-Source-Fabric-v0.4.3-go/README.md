# FUSE Native Source Fabric v0.4.3

Self-contained, provider-independent source fabric designed to move GitHub out of the FUSE engineering critical path.

Core properties:
- SHA-256 CAS object vault.
- Immutable source manifests.
- Independent candidate workspaces built from any prior manifest.
- Object-level optimistic admission: only touched-path preimages are fenced.
- Disjoint candidates from the same stale base can both admit after each other.
- Overlapping stale writes fail closed as CONFLICT.
- Append-only JSONL journal and admission receipts.
- Atomic canonical pointer and checkout materialization.
- Authenticated loopback read API; mutation remains local CLI only.
- No arbitrary shell API, no GitHub dependency, no Python/Node/.NET runtime.
- GitHub is intended as a downstream optional mirror, not the working source authority.

Proof boundary: locally built/tested single binary. Physical owner-PC installation and production durability remain separate courts until executed on the target host.

## v0.3 durability additions

- Hash-chained append-only journal with v0.2 legacy-line migration binding.
- `audit` verifies canonical manifest, every stored manifest, all referenced CAS objects, and journal integrity.
- Deterministic content-addressed source snapshot export (`export`) and independent verification (`verify-export`).
- Snapshot ZIP is reproducible for the same manifest/source-epoch and carries no GitHub dependency.
- Tamper/corrupt-object courts are part of the release test suite.

These improve local provenance and downstream replication. They do not, by themselves, prove physical Windows deployment, canonical Federation admission, or GitHub-downstream-only production behaviour.

## v0.4 — Anti-Entropy / Replica Intelligence

Adds a GitHub-independent replica/recovery plane:

- `replica-export` packages current source, complete reachable CAS closure,
  manifest lineage and hash-chained journal state.
- `replica-verify` independently verifies files, objects, ancestry and journal.
- `replica-compare` classifies replicas as SAME, LOCAL_ANCESTOR,
  REMOTE_ANCESTOR, DIVERGED, UNRELATED or LOCAL_EMPTY and reports path deltas.
- `replica-restore` reconstructs only into an empty target, audits before
  committing, appends a restore event, re-audits, then atomically installs.
- Historical objects referenced by ancestor manifests are included; incomplete
  reachable-object closure fails restore.
- Journal tampering and non-empty-target restore fail closed.

This is local/cross-replica proof. It does not by itself prove an independent
off-device durable replica, physical Windows deployment, canonical Federation
source admission, or production availability.

## v0.4.1 — One-Ledger Convergence Repair

- Candidate contracts now bind immutable `source_epoch`, exact claimed write set, preimages and object hashes behind a sealed digest sidecar.
- `AdmitAgainstEpoch` requires the exact source epoch and uses a narrow canonical generation compare-and-swap rather than a broad whole-admission lock.
- Distinct candidates can execute admission work concurrently; only the canonical pointer swap serializes. A losing CAS re-reads current state and safely rebases only when its touched preimages remain unchanged.
- Overlapping stale candidates fail without changing the canonical generation.
- Rollback is exact-currentness gated: it is allowed only while the admission being rolled back is still the current canonical manifest, and generation remains monotonic.
- Bootstrap rejects symlink/reparse entries; checkout writes resolve physical paths and reject parent/final-path escape. Physical Windows execution of the containment court remains a separate proof requirement.

This candidate repairs the exact-source falsifiers raised against v0.4. It remains source-independent until independently judged and does not replace FDOF canonical authority by itself.


## v0.4.3 — Post-CAS Durability / Admission WAL Repair

This release repairs the J104 failure where the canonical pointer could advance even when the durable admission receipt was not persisted.

- Every successful admission now begins with a durable `FNSF_ADMISSION_TXN_V1` write-ahead transaction and a PREPARED admission receipt before the canonical compare-and-swap.
- A durable `ADMISSION_PREPARED` journal event is required before the canonical pointer may advance.
- Failure to persist the prepared receipt or prepared journal leaves canonical state unchanged.
- If a process fails after the canonical CAS but before final receipt/journal completion, the PREPARED transaction is retained and restart recovery can deterministically finalize the exact admission.
- `recover-admissions` explicitly reconciles nonterminal admission transactions; `serve` runs that reconciliation before accepting traffic.
- Recovery is idempotent and does not duplicate the final `ADMITTED` journal event.
- `audit` now cross-binds finalized admission transaction, durable admission receipt, and final ADMITTED journal event, and fails closed on nonterminal PREPARED/CANONICAL_COMMITTED transactions.
- Exact rollback by the recovered admission ID is verified after a simulated post-CAS crash.
- Atomic file replacement now syncs the containing directory on non-Windows platforms after rename to strengthen crash durability semantics.

Proof boundary: these are source-independent local filesystem durability/recovery courts. They do not prove provider-native transactions, physical Windows execution, canonical Federation source admission, production availability, or go-live.
