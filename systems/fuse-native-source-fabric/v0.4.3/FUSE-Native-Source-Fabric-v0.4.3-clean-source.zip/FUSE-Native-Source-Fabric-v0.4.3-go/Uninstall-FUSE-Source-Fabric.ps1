param([string]$InstallRoot = "$env:LOCALAPPDATA\FUSE\SourceFabric")
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$RunKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
Remove-ItemProperty -Path $RunKey -Name 'FUSESourceFabric' -ErrorAction SilentlyContinue
Get-Process -Name 'FUSE-Source-Fabric' -ErrorAction SilentlyContinue | Stop-Process -Force
$Receipt=[ordered]@{schema='FUSE_SOURCE_FABRIC_WINDOWS_UNINSTALL_RECEIPT_V1';install_root=$InstallRoot;startup_removed=$true;process_stopped=$true;data_preserved=$true;uninstalled_at=(Get-Date).ToUniversalTime().ToString('o')}
$Receipt | ConvertTo-Json -Depth 5
# State/data is deliberately preserved. Remove $InstallRoot manually only after backup/retention policy authorizes deletion.
