module fuse.local/sourcefabric

go 1.23
