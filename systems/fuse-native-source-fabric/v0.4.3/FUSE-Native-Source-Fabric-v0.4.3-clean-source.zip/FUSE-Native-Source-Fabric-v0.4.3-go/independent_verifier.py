#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from collections import OrderedDict
from pathlib import Path

def h(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def compact(obj) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

def candidate_contract_digest(c: dict) -> str:
    # Match Go struct field order; nested maps are normalized by sorted key.
    def sorted_map(m):
        return OrderedDict((k, m[k]) for k in sorted(m))
    x = OrderedDict([
        ("base_manifest_id", c["base_manifest_id"]),
        ("source_epoch", c["source_epoch"]),
        ("preimages", sorted_map(c["preimages"])),
        ("changes", sorted_map(c["changes"])),
        ("claimed_write_set", c["claimed_write_set"]),
    ])
    return h(compact(x))

def verify(root: Path, cid: str, expected_epoch: str) -> dict:
    c = json.loads((root / "candidates" / f"{cid}.json").read_text())
    state = json.loads((root / "canonical.json").read_text())
    if state.get("generation", 0) == 0: state["generation"] = 1
    if not state.get("source_epoch"): state["source_epoch"] = state["manifest_id"]
    result = {"candidate_id": cid, "generation": state["generation"], "manifest_id": state["manifest_id"]}
    if c.get("source_epoch") != expected_epoch or state.get("source_epoch") != expected_epoch:
        result["decision"] = "EPOCH_CONFLICT"; return result
    changes = sorted(c.get("changes", {}))
    pre = sorted(c.get("preimages", {}))
    claimed = c.get("claimed_write_set", [])
    if changes != claimed or pre != claimed:
        result["decision"] = "INVALID_WRITE_SET"; return result
    digest = candidate_contract_digest(c)
    seal = (root / "candidate-contracts" / f"{cid}.sha256").read_text().strip()
    if digest != c.get("write_set_digest") or seal != digest:
        result["decision"] = "INVALID_SEAL"; return result
    manifest = json.loads((root / "manifests" / f"{state['manifest_id']}.json").read_text())
    conflicts=[]
    for path, expected in c["preimages"].items():
        actual = manifest["files"].get(path)
        if actual != expected:
            conflicts.append({"path": path, "expected": expected, "actual": actual})
    result["decision"] = "CONFLICT" if conflicts else "ADMITTABLE"
    result["conflicts"] = conflicts
    result["write_set_digest"] = digest
    return result

if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit("usage: independent_verifier.py ROOT CANDIDATE_ID SOURCE_EPOCH")
    print(json.dumps(verify(Path(sys.argv[1]), sys.argv[2], sys.argv[3]), sort_keys=True))
