package main

import (
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func oneTxnForCandidate(t *testing.T, f *Fabric, candidateID string) AdmissionTxn {
	t.Helper()
	ents, err := os.ReadDir(filepath.Join(f.Root, "admission-txns"))
	if err != nil {
		t.Fatal(err)
	}
	var matches []AdmissionTxn
	for _, ent := range ents {
		if ent.IsDir() || filepath.Ext(ent.Name()) != ".json" {
			continue
		}
		txn, err := f.loadAdmissionTxn(ent.Name()[:len(ent.Name())-len(filepath.Ext(ent.Name()))])
		if err != nil {
			t.Fatal(err)
		}
		if txn.CandidateID == candidateID {
			matches = append(matches, txn)
		}
	}
	if len(matches) != 1 {
		t.Fatalf("expected one txn for candidate, got %d", len(matches))
	}
	return matches[0]
}

func TestPreparedReceiptFailureCannotAdvanceCanonical(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	before, _ := f.canonicalState()

	admissions := filepath.Join(f.Root, "admissions")
	if err := os.RemoveAll(admissions); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(admissions, []byte("fault"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := f.AdmitAgainstEpoch(c.CandidateID, "repo@abc"); err == nil {
		t.Fatal("expected prepared receipt persistence failure")
	}
	after, _ := f.canonicalState()
	if !sameCanonicalState(before, after) {
		t.Fatalf("canonical advanced despite receipt failure: before=%#v after=%#v", before, after)
	}

	if err := os.Remove(admissions); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(admissions, 0o700); err != nil {
		t.Fatal(err)
	}
	if _, err := f.RecoverAdmissionTransactions(); err != nil {
		t.Fatal(err)
	}
	rep, err := f.Audit()
	if err != nil || rep.Status != "ok" {
		t.Fatalf("audit after precommit failure recovery: err=%v rep=%#v", err, rep)
	}
}

func TestPreparedCrashRecoveryAbortsWithoutCanonicalMutationThenRetryAdmits(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	before, _ := f.canonicalState()
	fired := false
	f.faultHook = func(point string) error {
		if point == "after_admission_prepare_before_canonical" && !fired {
			fired = true
			return errors.New("simulated precommit crash")
		}
		return nil
	}
	if _, err := f.AdmitAgainstEpoch(c.CandidateID, "repo@abc"); err == nil {
		t.Fatal("expected simulated precommit crash")
	}
	after, _ := f.canonicalState()
	if !sameCanonicalState(before, after) {
		t.Fatal("precommit crash changed canonical")
	}
	if rep, err := f.Audit(); err == nil || rep.Status != "fail" {
		t.Fatal("audit failed to detect nonterminal prepared transaction")
	}

	fresh := newFabric(f.Root)
	recovery, err := fresh.RecoverAdmissionTransactions()
	if err != nil {
		t.Fatal(err)
	}
	if recovery["aborted_precommit"] != 1 {
		t.Fatalf("unexpected recovery %#v", recovery)
	}
	rep, err := fresh.Audit()
	if err != nil || rep.Status != "ok" {
		t.Fatalf("audit after abort recovery: err=%v rep=%#v", err, rep)
	}
	r, err := fresh.AdmitAgainstEpoch(c.CandidateID, "repo@abc")
	if err != nil || r.Result != "ADMITTED" {
		t.Fatalf("retry did not admit: %#v err=%v", r, err)
	}
}

func TestPostCanonicalCrashRecoveryFinalizesCrossBindingsAndRollback(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	fired := false
	f.faultHook = func(point string) error {
		if point == "after_canonical_commit_before_finalize" && !fired {
			fired = true
			return errors.New("simulated post-cas crash")
		}
		return nil
	}
	if _, err := f.AdmitAgainstEpoch(c.CandidateID, "repo@abc"); err == nil {
		t.Fatal("expected simulated post-cas crash")
	}
	st, _ := f.canonicalState()
	if st.Generation != 2 || st.ManifestID == m.ManifestID {
		t.Fatalf("expected committed canonical state, got %#v", st)
	}
	if rep, err := f.Audit(); err == nil || rep.Status != "fail" {
		t.Fatal("audit failed to detect unfinalized committed transaction")
	}

	txn := oneTxnForCandidate(t, f, c.CandidateID)
	if txn.State != "PREPARED" {
		t.Fatalf("expected WAL PREPARED after crash, got %s", txn.State)
	}

	fresh := newFabric(f.Root)
	recovery, err := fresh.RecoverAdmissionTransactions()
	if err != nil {
		t.Fatal(err)
	}
	if recovery["finalized"] != 1 {
		t.Fatalf("unexpected recovery %#v", recovery)
	}
	rep, err := fresh.Audit()
	if err != nil || rep.Status != "ok" || rep.AdmissionsVerified < 1 || rep.AdmissionTxnsVerified < 1 {
		t.Fatalf("audit after finalization: err=%v rep=%#v", err, rep)
	}
	recoveredTxn, err := fresh.loadAdmissionTxn(txn.TxnID)
	if err != nil {
		t.Fatal(err)
	}
	if recoveredTxn.State != "FINALIZED" || recoveredTxn.Receipt.Result != "ADMITTED" {
		t.Fatalf("bad recovered txn %#v", recoveredTxn)
	}

	rb, err := fresh.RollbackAdmission(recoveredTxn.AdmissionID)
	if err != nil || rb.Result != "ROLLED_BACK" {
		t.Fatalf("rollback failed after recovery: %#v err=%v", rb, err)
	}
	rolled, _ := fresh.canonicalState()
	if rolled.ManifestID != m.ManifestID || rolled.Generation != 3 {
		t.Fatalf("bad rollback state %#v", rolled)
	}
}

func TestAdmissionRecoveryIsIdempotentAndDoesNotDuplicateAdmittedEvent(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	f.faultHook = func(point string) error {
		if point == "after_canonical_commit_before_finalize" {
			f.faultHook = nil
			return errors.New("simulated crash")
		}
		return nil
	}
	_, _ = f.AdmitAgainstEpoch(c.CandidateID, "repo@abc")
	fresh := newFabric(f.Root)
	if _, err := fresh.RecoverAdmissionTransactions(); err != nil {
		t.Fatal(err)
	}
	if _, err := fresh.RecoverAdmissionTransactions(); err != nil {
		t.Fatal(err)
	}
	txn := oneTxnForCandidate(t, fresh, c.CandidateID)
	events, _, err := fresh.readJournalRaw()
	if err != nil {
		t.Fatal(err)
	}
	count := 0
	for _, e := range events {
		if e.EventType == "ADMITTED" && e.Payload["admission_id"] == txn.AdmissionID {
			count++
		}
	}
	if count != 1 {
		t.Fatalf("expected exactly one ADMITTED event, got %d", count)
	}
}
