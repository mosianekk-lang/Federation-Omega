package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"testing"
)

func testFabricEpoch(t *testing.T) (*Fabric, Manifest, string) {
	t.Helper()
	root := t.TempDir()
	src := filepath.Join(root, "src")
	if err := os.MkdirAll(src, 0o700); err != nil {
		t.Fatal(err)
	}
	_ = os.WriteFile(filepath.Join(src, "a.txt"), []byte("A1"), 0o600)
	_ = os.WriteFile(filepath.Join(src, "b.txt"), []byte("B1"), 0o600)
	f := newFabric(filepath.Join(root, "fabric"))
	m, err := f.BootstrapAtEpoch(src, "repo@abc")
	if err != nil {
		t.Fatal(err)
	}
	return f, m, root
}

func TestSourceEpochFailClosedNoPointerChange(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	before, _ := f.canonicalState()
	r, err := f.AdmitAgainstEpoch(c.CandidateID, "repo@wrong")
	if err != nil {
		t.Fatal(err)
	}
	after, _ := f.canonicalState()
	if r.Result != "EPOCH_CONFLICT" || before.ManifestID != after.ManifestID || before.Generation != after.Generation {
		t.Fatal("epoch conflict mutated canonical pointer")
	}
}

func TestGenuineConcurrentDisjointCAS(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c1, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	c2, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"b.txt": []byte("B2")}, nil, nil)
	var ready sync.WaitGroup
	ready.Add(2)
	release := make(chan struct{})
	var once sync.Map
	f.admitAfterReadHook = func(cid string, st CanonicalState) {
		if st.Generation != 1 {
			return
		}
		if _, loaded := once.LoadOrStore(cid, true); loaded {
			return
		}
		ready.Done()
		<-release
	}
	var wg sync.WaitGroup
	wg.Add(2)
	var r1, r2 AdmissionReceipt
	var e1, e2 error
	go func() { defer wg.Done(); r1, e1 = f.AdmitAgainstEpoch(c1.CandidateID, "repo@abc") }()
	go func() { defer wg.Done(); r2, e2 = f.AdmitAgainstEpoch(c2.CandidateID, "repo@abc") }()
	ready.Wait()
	close(release)
	wg.Wait()
	if e1 != nil || e2 != nil || r1.Result != "ADMITTED" || r2.Result != "ADMITTED" {
		t.Fatalf("results %#v %#v err %v %v", r1, r2, e1, e2)
	}
	st, mf, err := f.canonicalStateAndManifest()
	if err != nil {
		t.Fatal(err)
	}
	if st.Generation != 3 || mf.Files["a.txt"] == "" || mf.Files["b.txt"] == "" {
		t.Fatalf("bad final state %#v", st)
	}
}

func TestConcurrentStaleOverlapRejectsOne(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c1, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	c2, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A3")}, nil, nil)
	var ready sync.WaitGroup
	ready.Add(2)
	release := make(chan struct{})
	var once sync.Map
	f.admitAfterReadHook = func(cid string, st CanonicalState) {
		if st.Generation != 1 {
			return
		}
		if _, loaded := once.LoadOrStore(cid, true); loaded {
			return
		}
		ready.Done()
		<-release
	}
	var wg sync.WaitGroup
	wg.Add(2)
	results := make(chan AdmissionReceipt, 2)
	errs := make(chan error, 2)
	for _, c := range []Candidate{c1, c2} {
		c := c
		go func() {
			defer wg.Done()
			r, e := f.AdmitAgainstEpoch(c.CandidateID, "repo@abc")
			results <- r
			errs <- e
		}()
	}
	ready.Wait()
	close(release)
	wg.Wait()
	close(results)
	close(errs)
	for e := range errs {
		if e != nil {
			t.Fatal(e)
		}
	}
	admit, conflict := 0, 0
	for r := range results {
		if r.Result == "ADMITTED" {
			admit++
		}
		if r.Result == "CONFLICT" {
			conflict++
		}
	}
	if admit != 1 || conflict != 1 {
		t.Fatalf("admit=%d conflict=%d", admit, conflict)
	}
	st, _ := f.canonicalState()
	if st.Generation != 2 {
		t.Fatalf("failed CAS changed generation %#v", st)
	}
}

func TestCandidateWriteSetTamperFailsClosed(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	p := filepath.Join(f.Root, "candidates", c.CandidateID+".json")
	b, _ := os.ReadFile(p)
	var raw map[string]any
	if err := json.Unmarshal(b, &raw); err != nil {
		t.Fatal(err)
	}
	changes := raw["changes"].(map[string]any)
	changes["b.txt"] = nil
	tampered, _ := json.MarshalIndent(raw, "", "  ")
	if err := os.WriteFile(p, tampered, 0o600); err != nil {
		t.Fatal(err)
	}
	before, _ := f.canonicalState()
	if _, err := f.AdmitAgainstEpoch(c.CandidateID, "repo@abc"); err == nil {
		t.Fatal("tampered candidate admitted")
	}
	after, _ := f.canonicalState()
	if before != after {
		t.Fatal("tamper changed canonical")
	}
}

func TestRollbackExactCurrentness(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	r, err := f.AdmitAgainstEpoch(c.CandidateID, "repo@abc")
	if err != nil {
		t.Fatal(err)
	}
	rb, err := f.RollbackAdmission(r.AdmissionID)
	if err != nil {
		t.Fatal(err)
	}
	if rb.Result != "ROLLED_BACK" {
		t.Fatalf("%#v", rb)
	}
	st, _ := f.canonicalState()
	if st.ManifestID != m.ManifestID || st.Generation != 3 {
		t.Fatalf("bad rollback state %#v", st)
	}
}

func TestRollbackRejectsAfterSubsequentAdmission(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	c1, _ := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	r1, _ := f.AdmitAgainstEpoch(c1.CandidateID, "repo@abc")
	c2, _ := f.CreateCandidateAtEpoch("", "repo@abc", map[string][]byte{"b.txt": []byte("B2")}, nil, nil)
	_, _ = f.AdmitAgainstEpoch(c2.CandidateID, "repo@abc")
	before, _ := f.canonicalState()
	rb, err := f.RollbackAdmission(r1.AdmissionID)
	if err != nil {
		t.Fatal(err)
	}
	after, _ := f.canonicalState()
	if rb.Result != "ROLLBACK_CONFLICT" || before != after {
		t.Fatal("unsafe rollback mutated state")
	}
}

func TestBootstrapRejectsSymlinkEscape(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "src")
	outside := filepath.Join(root, "outside.txt")
	_ = os.MkdirAll(src, 0o700)
	_ = os.WriteFile(outside, []byte("secret"), 0o600)
	if err := os.Symlink(outside, filepath.Join(src, "link.txt")); err != nil {
		t.Skip("symlink unsupported")
	}
	f := newFabric(filepath.Join(root, "fabric"))
	if _, err := f.BootstrapAtEpoch(src, "repo@abc"); err == nil {
		t.Fatal("symlink escape accepted")
	}
}

func TestContainedWriteRejectsSymlinkParent(t *testing.T) {
	root := t.TempDir()
	dest := filepath.Join(root, "dest")
	outside := filepath.Join(root, "outside")
	_ = os.MkdirAll(dest, 0o700)
	_ = os.MkdirAll(outside, 0o700)
	if err := os.Symlink(outside, filepath.Join(dest, "link")); err != nil {
		t.Skip("symlink unsupported")
	}
	if err := safeWriteContained(dest, "link/pwn.txt", []byte("x"), 0o600); err == nil {
		t.Fatal("symlink parent escape accepted")
	}
	if _, err := os.Stat(filepath.Join(outside, "pwn.txt")); !os.IsNotExist(err) {
		t.Fatal("outside write occurred")
	}
}
