package main

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func TestNormRel(t *testing.T) {
	good, err := normRel(`dir\\file.txt`)
	if err != nil || good != "dir/file.txt" {
		t.Fatalf("got %q %v", good, err)
	}
	for _, bad := range []string{"../x", "/x", ".."} {
		if _, err := normRel(bad); err == nil {
			t.Fatalf("accepted unsafe %q", bad)
		}
	}
}

func TestManifestStable(t *testing.T) {
	a := map[string]string{"b": "2", "a": "1"}
	b := map[string]string{"a": "1", "b": "2"}
	if manifestID(a) != manifestID(b) {
		t.Fatal("manifest id order-dependent")
	}
}

func TestJournalTamperDetected(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "src")
	if err := os.MkdirAll(src, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "x.txt"), []byte("x"), 0o600); err != nil {
		t.Fatal(err)
	}
	f := newFabric(filepath.Join(root, "fabric"))
	if _, err := f.Bootstrap(src); err != nil {
		t.Fatal(err)
	}
	c, err := f.CreateCandidate("", map[string][]byte{"x.txt": []byte("y")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := f.Admit(c.CandidateID); err != nil {
		t.Fatal(err)
	}
	if _, err := f.VerifyJournal(); err != nil {
		t.Fatal(err)
	}
	p := filepath.Join(f.Root, "journal.jsonl")
	b, err := os.ReadFile(p)
	if err != nil {
		t.Fatal(err)
	}
	b = bytes.Replace(b, []byte(`"ADMITTED"`), []byte(`"ADMITTEZ"`), 1)
	if err := os.WriteFile(p, b, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := f.VerifyJournal(); err == nil {
		t.Fatal("tampered journal passed")
	}
}

func TestSnapshotExportDeterministicAndVerifiable(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "src")
	if err := os.MkdirAll(filepath.Join(src, "d"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "a.txt"), []byte("A"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "d", "b.txt"), []byte("B"), 0o600); err != nil {
		t.Fatal(err)
	}
	f := newFabric(filepath.Join(root, "fabric"))
	if _, err := f.Bootstrap(src); err != nil {
		t.Fatal(err)
	}
	p1 := filepath.Join(root, "one.zip")
	p2 := filepath.Join(root, "two.zip")
	if _, err := f.ExportSnapshot("", p1, ""); err != nil {
		t.Fatal(err)
	}
	if _, err := f.ExportSnapshot("", p2, ""); err != nil {
		t.Fatal(err)
	}
	b1, _ := os.ReadFile(p1)
	b2, _ := os.ReadFile(p2)
	if digestBytes(b1) != digestBytes(b2) {
		t.Fatal("snapshot export not deterministic")
	}
	if _, err := VerifySnapshotBundle(p1); err != nil {
		t.Fatal(err)
	}
}

func TestAuditDetectsCorruptObject(t *testing.T) {
	root := t.TempDir()
	src := filepath.Join(root, "src")
	if err := os.MkdirAll(src, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(src, "a.txt"), []byte("A"), 0o600); err != nil {
		t.Fatal(err)
	}
	f := newFabric(filepath.Join(root, "fabric"))
	m, err := f.Bootstrap(src)
	if err != nil {
		t.Fatal(err)
	}
	h := m.Files["a.txt"]
	if err := os.WriteFile(f.objectPath(h), []byte("CORRUPT"), 0o600); err != nil {
		t.Fatal(err)
	}
	rep, err := f.Audit()
	if err == nil || rep.Status != "fail" {
		t.Fatal("corrupt object audit did not fail")
	}
}
