package main

import (
	"archive/zip"
	"bufio"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type ReplicaSnapshotReceipt struct {
	Schema          string   `json:"schema"`
	Version         string   `json:"version"`
	ManifestID      string   `json:"manifest_id"`
	FileCount       int      `json:"file_count"`
	SourceEpoch     string   `json:"source_epoch,omitempty"`
	Ancestors       []string `json:"ancestors"`
	JournalSeq      int64    `json:"journal_seq"`
	JournalTailHash string   `json:"journal_tail_hash"`
}

type ReplicaComparison struct {
	Status            string            `json:"status"`
	LocalManifestID   string            `json:"local_manifest_id,omitempty"`
	RemoteManifestID  string            `json:"remote_manifest_id"`
	CommonAncestor    string            `json:"common_ancestor,omitempty"`
	AddedPaths        []string          `json:"added_paths,omitempty"`
	RemovedPaths      []string          `json:"removed_paths,omitempty"`
	ChangedPaths      []string          `json:"changed_paths,omitempty"`
	LocalJournalSeq   int64             `json:"local_journal_seq,omitempty"`
	LocalJournalHash  string            `json:"local_journal_hash,omitempty"`
	RemoteJournalSeq  int64             `json:"remote_journal_seq"`
	RemoteJournalHash string            `json:"remote_journal_hash"`
	Proof             map[string]string `json:"proof"`
}

type ReplicaRestoreReceipt struct {
	Status        string `json:"status"`
	Version       string `json:"version"`
	ManifestID    string `json:"manifest_id"`
	FileCount     int    `json:"file_count"`
	JournalEvents int    `json:"journal_events"`
	SourceEpoch   string `json:"source_epoch,omitempty"`
	RestoredRoot  string `json:"restored_root"`
	AuditStatus   string `json:"audit_status"`
}

type replicaBundleData struct {
	Receipt  ReplicaSnapshotReceipt
	Manifest Manifest
	Source   map[string][]byte
	Objects  map[string][]byte
	Lineage  map[string][]byte
	Journal  []byte
}

func (f *Fabric) manifestLineage(mid string) ([]string, error) {
	if mid == "" {
		m, err := f.canonical()
		if err != nil {
			return nil, err
		}
		mid = m.ManifestID
	}
	seen := map[string]bool{}
	out := []string{}
	for mid != "" {
		if seen[mid] {
			return nil, errors.New("manifest ancestry cycle")
		}
		seen[mid] = true
		out = append(out, mid)
		m, err := f.loadManifest(mid)
		if err != nil {
			return nil, err
		}
		mid = m.ParentManifestID
		if len(out) > 100000 {
			return nil, errors.New("manifest ancestry too deep")
		}
	}
	return out, nil
}

func parseJournalBytes(raw []byte) ([]Event, error) {
	if len(raw) == 0 {
		return []Event{}, nil
	}
	sc := bufio.NewScanner(strings.NewReader(string(raw)))
	buf := make([]byte, 64*1024)
	sc.Buffer(buf, 4*1024*1024)
	events := []Event{}
	raws := [][]byte{}
	for sc.Scan() {
		line := append([]byte(nil), sc.Bytes()...)
		var e Event
		if err := json.Unmarshal(line, &e); err != nil {
			return nil, fmt.Errorf("journal json: %w", err)
		}
		events = append(events, e)
		raws = append(raws, line)
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	var priorHash string
	var priorSeq int64
	hashedStarted := false
	for i, e := range events {
		if e.EventHash == "" {
			if hashedStarted {
				return nil, fmt.Errorf("legacy event after hashed chain at line %d", i+1)
			}
			priorHash = "legacy:" + digestBytes(raws[i])
			priorSeq = int64(i + 1)
			continue
		}
		hashedStarted = true
		if e.Seq != priorSeq+1 {
			return nil, fmt.Errorf("journal seq mismatch line %d", i+1)
		}
		if e.PrevHash != priorHash {
			return nil, fmt.Errorf("journal prev hash mismatch line %d", i+1)
		}
		if eventHash(e) != e.EventHash {
			return nil, fmt.Errorf("journal event hash mismatch line %d", i+1)
		}
		priorHash = e.EventHash
		priorSeq = e.Seq
	}
	return events, nil
}

func journalBytesTail(raw []byte) (int64, string, error) {
	events, err := parseJournalBytes(raw)
	if err != nil {
		return 0, "", err
	}
	if len(events) == 0 {
		return 0, "", nil
	}
	lines := strings.Split(strings.TrimSpace(string(raw)), "\n")
	last := events[len(events)-1]
	if last.EventHash != "" {
		return last.Seq, last.EventHash, nil
	}
	return int64(len(events)), "legacy:" + digestBytes([]byte(lines[len(lines)-1])), nil
}

func (f *Fabric) ExportReplicaSnapshot(dest, sourceEpoch string) (ReplicaSnapshotReceipt, error) {
	st, err := f.canonicalState()
	if err != nil {
		return ReplicaSnapshotReceipt{}, err
	}
	if sourceEpoch == "" {
		sourceEpoch = st.SourceEpoch
	}
	if sourceEpoch != st.SourceEpoch {
		return ReplicaSnapshotReceipt{}, errors.New("SOURCE_EPOCH_MISMATCH")
	}
	m, err := f.canonical()
	if err != nil {
		return ReplicaSnapshotReceipt{}, err
	}
	lineage, err := f.manifestLineage(m.ManifestID)
	if err != nil {
		return ReplicaSnapshotReceipt{}, err
	}
	journalPath := filepath.Join(f.Root, "journal.jsonl")
	journal, _ := os.ReadFile(journalPath)
	seq, tail, err := journalBytesTail(journal)
	if err != nil {
		return ReplicaSnapshotReceipt{}, err
	}
	receipt := ReplicaSnapshotReceipt{Schema: "FUSE_NATIVE_SOURCE_REPLICA_SNAPSHOT_V2", Version: Version, ManifestID: m.ManifestID, FileCount: len(m.Files), SourceEpoch: sourceEpoch, Ancestors: lineage, JournalSeq: seq, JournalTailHash: tail}
	if err := os.MkdirAll(filepath.Dir(dest), 0o700); err != nil {
		return receipt, err
	}
	tmp := dest + ".tmp-" + randomID()
	out, err := os.Create(tmp)
	if err != nil {
		return receipt, err
	}
	zw := zip.NewWriter(out)
	fail := func(e error) (ReplicaSnapshotReceipt, error) {
		_ = zw.Close()
		_ = out.Close()
		_ = os.Remove(tmp)
		return receipt, e
	}
	keys := make([]string, 0, len(m.Files))
	for k := range m.Files {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, rel := range keys {
		b, err := f.getBytes(m.Files[rel])
		if err != nil {
			return fail(err)
		}
		w, err := zw.CreateHeader(fixedZipHeader("source/"+rel, 0o600))
		if err != nil {
			return fail(err)
		}
		if _, err := w.Write(b); err != nil {
			return fail(err)
		}
	}
	objectSet := map[string]bool{}
	for _, mid := range lineage {
		b, err := os.ReadFile(filepath.Join(f.Root, "manifests", mid+".json"))
		if err != nil {
			return fail(err)
		}
		var lm Manifest
		if err := json.Unmarshal(b, &lm); err != nil {
			return fail(err)
		}
		for _, h := range lm.Files {
			objectSet[h] = true
		}
		w, err := zw.CreateHeader(fixedZipHeader("manifests/"+mid+".json", 0o600))
		if err != nil {
			return fail(err)
		}
		if _, err := w.Write(b); err != nil {
			return fail(err)
		}
	}
	objectHashes := make([]string, 0, len(objectSet))
	for h := range objectSet {
		objectHashes = append(objectHashes, h)
	}
	sort.Strings(objectHashes)
	for _, h := range objectHashes {
		b, err := f.getBytes(h)
		if err != nil {
			return fail(err)
		}
		w, err := zw.CreateHeader(fixedZipHeader("objects/"+h, 0o600))
		if err != nil {
			return fail(err)
		}
		if _, err := w.Write(b); err != nil {
			return fail(err)
		}
	}
	mb, _ := json.MarshalIndent(m, "", "  ")
	mw, err := zw.CreateHeader(fixedZipHeader("FUSE-MANIFEST.json", 0o600))
	if err != nil {
		return fail(err)
	}
	if _, err := mw.Write(mb); err != nil {
		return fail(err)
	}
	rb, _ := json.MarshalIndent(receipt, "", "  ")
	rw, err := zw.CreateHeader(fixedZipHeader("FUSE-REPLICA-RECEIPT.json", 0o600))
	if err != nil {
		return fail(err)
	}
	if _, err := rw.Write(rb); err != nil {
		return fail(err)
	}
	if len(journal) > 0 {
		jw, err := zw.CreateHeader(fixedZipHeader("FUSE-JOURNAL.jsonl", 0o600))
		if err != nil {
			return fail(err)
		}
		if _, err := jw.Write(journal); err != nil {
			return fail(err)
		}
	}
	if err := zw.Close(); err != nil {
		return fail(err)
	}
	if err := out.Sync(); err != nil {
		_ = out.Close()
		_ = os.Remove(tmp)
		return receipt, err
	}
	if err := out.Close(); err != nil {
		_ = os.Remove(tmp)
		return receipt, err
	}
	if err := os.Rename(tmp, dest); err != nil {
		_ = os.Remove(tmp)
		return receipt, err
	}
	_ = f.appendEvent("REPLICA_SNAPSHOT_EXPORTED", m.ManifestID, map[string]any{"dest": dest, "files": len(m.Files), "source_epoch": sourceEpoch, "journal_seq": seq, "journal_tail_hash": tail})
	return receipt, nil
}

func readReplicaSnapshot(bundle string) (replicaBundleData, error) {
	var d replicaBundleData
	zr, err := zip.OpenReader(bundle)
	if err != nil {
		return d, err
	}
	defer zr.Close()
	d.Source = map[string][]byte{}
	d.Objects = map[string][]byte{}
	d.Lineage = map[string][]byte{}
	for _, zf := range zr.File {
		rc, err := zf.Open()
		if err != nil {
			return d, err
		}
		b, err := io.ReadAll(rc)
		_ = rc.Close()
		if err != nil {
			return d, err
		}
		switch {
		case zf.Name == "FUSE-MANIFEST.json":
			if err := json.Unmarshal(b, &d.Manifest); err != nil {
				return d, err
			}
		case zf.Name == "FUSE-REPLICA-RECEIPT.json":
			if err := json.Unmarshal(b, &d.Receipt); err != nil {
				return d, err
			}
		case zf.Name == "FUSE-JOURNAL.jsonl":
			d.Journal = b
		case strings.HasPrefix(zf.Name, "source/"):
			rel := strings.TrimPrefix(zf.Name, "source/")
			n, err := normRel(rel)
			if err != nil {
				return d, err
			}
			d.Source[n] = b
		case strings.HasPrefix(zf.Name, "objects/"):
			h := strings.TrimPrefix(zf.Name, "objects/")
			if len(h) != 64 || digestBytes(b) != h {
				return d, errors.New("replica object integrity mismatch")
			}
			d.Objects[h] = b
		case strings.HasPrefix(zf.Name, "manifests/") && strings.HasSuffix(zf.Name, ".json"):
			mid := strings.TrimSuffix(strings.TrimPrefix(zf.Name, "manifests/"), ".json")
			d.Lineage[mid] = b
		}
	}
	if d.Receipt.Schema != "FUSE_NATIVE_SOURCE_REPLICA_SNAPSHOT_V2" {
		return d, errors.New("replica snapshot schema mismatch")
	}
	if d.Manifest.ManifestID == "" || d.Receipt.ManifestID != d.Manifest.ManifestID {
		return d, errors.New("replica manifest identity mismatch")
	}
	if manifestID(d.Manifest.Files) != d.Manifest.ManifestID {
		return d, errors.New("replica manifest integrity mismatch")
	}
	if d.Receipt.FileCount != len(d.Manifest.Files) || len(d.Source) != len(d.Manifest.Files) {
		return d, errors.New("replica file count mismatch")
	}
	for rel, h := range d.Manifest.Files {
		b, ok := d.Source[rel]
		if !ok {
			return d, fmt.Errorf("replica missing source file: %s", rel)
		}
		if digestBytes(b) != h {
			return d, fmt.Errorf("replica source hash mismatch: %s", rel)
		}
	}
	if len(d.Receipt.Ancestors) == 0 || d.Receipt.Ancestors[0] != d.Manifest.ManifestID {
		return d, errors.New("replica ancestry root mismatch")
	}
	for i, mid := range d.Receipt.Ancestors {
		raw, ok := d.Lineage[mid]
		if !ok {
			return d, fmt.Errorf("replica lineage manifest missing: %s", mid)
		}
		var m Manifest
		if err := json.Unmarshal(raw, &m); err != nil {
			return d, err
		}
		if m.ManifestID != mid || manifestID(m.Files) != mid {
			return d, fmt.Errorf("replica lineage integrity mismatch: %s", mid)
		}
		if i+1 < len(d.Receipt.Ancestors) && m.ParentManifestID != d.Receipt.Ancestors[i+1] {
			return d, errors.New("replica ancestry chain mismatch")
		}
		if i+1 == len(d.Receipt.Ancestors) && m.ParentManifestID != "" {
			return d, errors.New("replica ancestry does not terminate")
		}
	}
	for _, raw := range d.Lineage {
		var lm Manifest
		if err := json.Unmarshal(raw, &lm); err != nil {
			return d, err
		}
		for _, h := range lm.Files {
			if _, ok := d.Objects[h]; !ok {
				return d, fmt.Errorf("replica historical object missing: %s", h)
			}
		}
	}
	seq, tail, err := journalBytesTail(d.Journal)
	if err != nil {
		return d, err
	}
	if seq != d.Receipt.JournalSeq || tail != d.Receipt.JournalTailHash {
		return d, errors.New("replica journal receipt mismatch")
	}
	return d, nil
}

func VerifyReplicaSnapshot(bundle string) (ReplicaSnapshotReceipt, error) {
	d, err := readReplicaSnapshot(bundle)
	return d.Receipt, err
}

func diffManifests(local, remote Manifest) (added, removed, changed []string) {
	for p, rh := range remote.Files {
		lh, ok := local.Files[p]
		if !ok {
			added = append(added, p)
		} else if lh != rh {
			changed = append(changed, p)
		}
	}
	for p := range local.Files {
		if _, ok := remote.Files[p]; !ok {
			removed = append(removed, p)
		}
	}
	sort.Strings(added)
	sort.Strings(removed)
	sort.Strings(changed)
	return
}

func firstCommon(a, b []string) string {
	set := map[string]bool{}
	for _, x := range a {
		set[x] = true
	}
	for _, x := range b {
		if set[x] {
			return x
		}
	}
	return ""
}
func containsString(xs []string, s string) bool {
	for _, x := range xs {
		if x == s {
			return true
		}
	}
	return false
}

func (f *Fabric) CompareReplicaSnapshot(bundle string) (ReplicaComparison, error) {
	d, err := readReplicaSnapshot(bundle)
	if err != nil {
		return ReplicaComparison{}, err
	}
	comp := ReplicaComparison{RemoteManifestID: d.Manifest.ManifestID, RemoteJournalSeq: d.Receipt.JournalSeq, RemoteJournalHash: d.Receipt.JournalTailHash, Proof: map[string]string{"snapshot": "VERIFIED", "ancestry": "VERIFIED", "journal": "VERIFIED"}}
	local, err := f.canonical()
	if errors.Is(err, os.ErrNotExist) {
		comp.Status = "LOCAL_EMPTY"
		return comp, nil
	}
	if err != nil {
		return comp, err
	}
	comp.LocalManifestID = local.ManifestID
	comp.LocalJournalSeq, comp.LocalJournalHash, _ = f.journalTail()
	comp.AddedPaths, comp.RemovedPaths, comp.ChangedPaths = diffManifests(local, d.Manifest)
	if local.ManifestID == d.Manifest.ManifestID {
		comp.Status = "SAME"
		comp.CommonAncestor = local.ManifestID
		return comp, nil
	}
	localLineage, err := f.manifestLineage(local.ManifestID)
	if err != nil {
		return comp, err
	}
	if containsString(d.Receipt.Ancestors, local.ManifestID) {
		comp.Status = "LOCAL_ANCESTOR"
		comp.CommonAncestor = local.ManifestID
		return comp, nil
	}
	if containsString(localLineage, d.Manifest.ManifestID) {
		comp.Status = "REMOTE_ANCESTOR"
		comp.CommonAncestor = d.Manifest.ManifestID
		return comp, nil
	}
	comp.CommonAncestor = firstCommon(localLineage, d.Receipt.Ancestors)
	if comp.CommonAncestor != "" {
		comp.Status = "DIVERGED"
	} else {
		comp.Status = "UNRELATED"
	}
	return comp, nil
}

func dirEmpty(p string) (bool, error) {
	ents, err := os.ReadDir(p)
	if errors.Is(err, os.ErrNotExist) {
		return true, nil
	}
	if err != nil {
		return false, err
	}
	return len(ents) == 0, nil
}

func RestoreReplicaSnapshot(root, bundle string) (ReplicaRestoreReceipt, error) {
	d, err := readReplicaSnapshot(bundle)
	if err != nil {
		return ReplicaRestoreReceipt{}, err
	}
	empty, err := dirEmpty(root)
	if err != nil {
		return ReplicaRestoreReceipt{}, err
	}
	if !empty {
		return ReplicaRestoreReceipt{}, errors.New("restore target not empty")
	}
	parent := filepath.Dir(root)
	if err := os.MkdirAll(parent, 0o700); err != nil {
		return ReplicaRestoreReceipt{}, err
	}
	stage := root + ".restore-" + randomID()
	_ = os.RemoveAll(stage)
	f := newFabric(stage)
	if err := f.ensureDirs(); err != nil {
		return ReplicaRestoreReceipt{}, err
	}
	cleanup := func() { _ = os.RemoveAll(stage) }
	for expected, b := range d.Objects {
		h, err := f.putBytes(b)
		if err != nil {
			cleanup()
			return ReplicaRestoreReceipt{}, err
		}
		if h != expected {
			cleanup()
			return ReplicaRestoreReceipt{}, errors.New("restore object digest mismatch")
		}
	}
	for mid, raw := range d.Lineage {
		if err := atomicWrite(filepath.Join(stage, "manifests", mid+".json"), raw, 0o600); err != nil {
			cleanup()
			return ReplicaRestoreReceipt{}, err
		}
	}
	if len(d.Journal) > 0 {
		if err := atomicWrite(filepath.Join(stage, "journal.jsonl"), d.Journal, 0o600); err != nil {
			cleanup()
			return ReplicaRestoreReceipt{}, err
		}
	}
	if err := f.setCanonicalInitial(d.Manifest.ManifestID, d.Receipt.SourceEpoch); err != nil {
		cleanup()
		return ReplicaRestoreReceipt{}, err
	}
	if rep, err := f.Audit(); err != nil || rep.Status != "ok" {
		cleanup()
		return ReplicaRestoreReceipt{}, fmt.Errorf("restore pre-commit audit failed: %v", err)
	}
	_ = f.appendEvent("REPLICA_SNAPSHOT_RESTORED", d.Manifest.ManifestID, map[string]any{"source_epoch": d.Receipt.SourceEpoch, "snapshot_journal_seq": d.Receipt.JournalSeq, "snapshot_journal_tail_hash": d.Receipt.JournalTailHash})
	rep, err := f.Audit()
	if err != nil || rep.Status != "ok" {
		cleanup()
		return ReplicaRestoreReceipt{}, fmt.Errorf("restore post-event audit failed: %v", err)
	}
	if _, err := os.Stat(root); err == nil {
		if err := os.Remove(root); err != nil {
			cleanup()
			return ReplicaRestoreReceipt{}, err
		}
	}
	if err := os.Rename(stage, root); err != nil {
		cleanup()
		return ReplicaRestoreReceipt{}, err
	}
	return ReplicaRestoreReceipt{Status: "RESTORED_VERIFIED", Version: Version, ManifestID: d.Manifest.ManifestID, FileCount: len(d.Manifest.Files), JournalEvents: rep.JournalEventsVerified, SourceEpoch: d.Receipt.SourceEpoch, RestoredRoot: root, AuditStatus: "PASS"}, nil
}

func replicaSelfTest(root string, f *Fabric) error {
	snap := filepath.Join(root, "replica.zip")
	rep, err := f.ExportReplicaSnapshot(snap, "")
	if err != nil {
		return err
	}
	vr, err := VerifyReplicaSnapshot(snap)
	if err != nil {
		return err
	}
	if vr.ManifestID != rep.ManifestID {
		return errors.New("replica verify mismatch")
	}
	restoredRoot := filepath.Join(root, "restored")
	rr, err := RestoreReplicaSnapshot(restoredRoot, snap)
	if err != nil {
		return err
	}
	if rr.ManifestID != rep.ManifestID {
		return errors.New("replica restore mismatch")
	}
	rf := newFabric(restoredRoot)
	cmp, err := rf.CompareReplicaSnapshot(snap)
	if err != nil {
		return err
	}
	if cmp.Status != "SAME" {
		return fmt.Errorf("restored replica not SAME: %s", cmp.Status)
	}
	// Advance original: old snapshot becomes remote ancestor from original's perspective.
	c, err := f.CreateCandidate(rep.ManifestID, map[string][]byte{"a.txt": []byte("A4")}, nil, nil)
	if err != nil {
		return err
	}
	ar, err := f.Admit(c.CandidateID)
	if err != nil || ar.Result != "ADMITTED" {
		return errors.New("replica selftest original advance failed")
	}
	cmp, err = f.CompareReplicaSnapshot(snap)
	if err != nil {
		return err
	}
	if cmp.Status != "REMOTE_ANCESTOR" {
		return fmt.Errorf("expected REMOTE_ANCESTOR got %s", cmp.Status)
	}
	// Independently advance restored replica from same base on a different path -> divergence.
	c2, err := rf.CreateCandidate(rep.ManifestID, map[string][]byte{"b.txt": []byte("B4")}, nil, nil)
	if err != nil {
		return err
	}
	ar2, err := rf.Admit(c2.CandidateID)
	if err != nil || ar2.Result != "ADMITTED" {
		return errors.New("replica selftest restored advance failed")
	}
	newer := filepath.Join(root, "newer.zip")
	_, err = f.ExportReplicaSnapshot(newer, "")
	if err != nil {
		return err
	}
	cmp2, err := rf.CompareReplicaSnapshot(newer)
	if err != nil {
		return err
	}
	if cmp2.Status != "DIVERGED" {
		return fmt.Errorf("expected DIVERGED got %s", cmp2.Status)
	}
	if cmp2.CommonAncestor != rep.ManifestID {
		return errors.New("divergence common ancestor mismatch")
	}
	return nil
}

var _ = time.RFC3339Nano
