package main

import (
	"errors"
	"testing"
)

// J105 regression: candidate A crashes after PREPARED is durable but before canonical CAS.
// Candidate B is unrelated/disjoint. A fresh B admission must globally reconcile A first,
// rather than advancing canonical and making A ambiguous.
func TestJ105CrossCandidatePrecommitCrashGloballyFencedBeforeUnrelatedAdmission(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	a, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	b, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"b.txt": []byte("B2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}

	fired := false
	f.faultHook = func(point string) error {
		if point == "after_admission_prepare_before_canonical" && !fired {
			fired = true
			return errors.New("J105 simulated candidate-A precommit crash")
		}
		return nil
	}
	if _, err := f.AdmitAgainstEpoch(a.CandidateID, "repo@abc"); err == nil {
		t.Fatal("expected candidate A precommit crash")
	}
	beforeB, err := f.canonicalState()
	if err != nil {
		t.Fatal(err)
	}
	if !sameCanonicalState(beforeB, CanonicalState{ManifestID: m.ManifestID, Generation: 1, SourceEpoch: "repo@abc", UpdatedAt: beforeB.UpdatedAt}) {
		// Compare only semantic fields because UpdatedAt is implementation detail.
		if beforeB.ManifestID != m.ManifestID || beforeB.Generation != 1 || beforeB.SourceEpoch != "repo@abc" {
			t.Fatalf("A precommit crash changed canonical: %#v", beforeB)
		}
	}

	// Simulate a fresh process and remove the fault hook.
	fresh := newFabric(f.Root)
	rb, err := fresh.AdmitAgainstEpoch(b.CandidateID, "repo@abc")
	if err != nil || rb.Result != "ADMITTED" {
		t.Fatalf("unrelated B admission failed after global recovery: %#v err=%v", rb, err)
	}

	atxn := oneTxnForCandidate(t, fresh, a.CandidateID)
	if atxn.State != "ABORTED" || atxn.AbortReason != "PRECOMMIT_RECOVERY_CANONICAL_UNCHANGED" {
		t.Fatalf("A was not globally precommit-aborted before B: %#v", atxn)
	}
	if rep, err := fresh.Audit(); err != nil || rep.Status != "ok" {
		t.Fatalf("audit after B/global recovery: err=%v rep=%#v", err, rep)
	}

	// A remains semantically mergeable because its write is disjoint from B.
	ra, err := fresh.AdmitAgainstEpoch(a.CandidateID, "repo@abc")
	if err != nil || ra.Result != "ADMITTED" {
		t.Fatalf("A retry after B should admit disjoint change: %#v err=%v", ra, err)
	}
	if rep, err := fresh.Audit(); err != nil || rep.Status != "ok" {
		t.Fatalf("final audit: err=%v rep=%#v", err, rep)
	}
}

// A committed-but-unfinalized A must be finalized globally before B advances canonical.
func TestJ105CrossCandidateCommittedCrashFinalizedBeforeUnrelatedAdmission(t *testing.T) {
	f, m, _ := testFabricEpoch(t)
	a, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"a.txt": []byte("A2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	b, err := f.CreateCandidateAtEpoch(m.ManifestID, "repo@abc", map[string][]byte{"b.txt": []byte("B2")}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}

	fired := false
	f.faultHook = func(point string) error {
		if point == "after_canonical_commit_before_finalize" && !fired {
			fired = true
			return errors.New("J105 simulated candidate-A postcommit crash")
		}
		return nil
	}
	if _, err := f.AdmitAgainstEpoch(a.CandidateID, "repo@abc"); err == nil {
		t.Fatal("expected candidate A postcommit crash")
	}

	fresh := newFabric(f.Root)
	rb, err := fresh.AdmitAgainstEpoch(b.CandidateID, "repo@abc")
	if err != nil || rb.Result != "ADMITTED" {
		t.Fatalf("B admission failed after committed-A recovery: %#v err=%v", rb, err)
	}
	atxn := oneTxnForCandidate(t, fresh, a.CandidateID)
	if atxn.State != "FINALIZED" || atxn.Receipt.Result != "ADMITTED" {
		t.Fatalf("A was not finalized before B: %#v", atxn)
	}
	st, err := fresh.canonicalState()
	if err != nil {
		t.Fatal(err)
	}
	if st.Generation != 3 {
		t.Fatalf("expected generation 3 after A then B, got %#v", st)
	}
	if rep, err := fresh.Audit(); err != nil || rep.Status != "ok" {
		t.Fatalf("audit after committed-A recovery + B: err=%v rep=%#v", err, rep)
	}
}
