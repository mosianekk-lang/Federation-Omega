param(
  [string]$InstallRoot = "$env:LOCALAPPDATA\FUSE\SourceFabric",
  [int]$Port = 8766
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ExpectedSha = '9e36b842dc97ab44ae925b5eb9a2a2dea9da3f80cd2c4574c30c912e84e79205'
$SourceExe = Join-Path $PSScriptRoot 'FUSE-Source-Fabric.exe'
if (-not (Test-Path -LiteralPath $SourceExe)) { throw "Missing FUSE-Source-Fabric.exe" }
$ActualSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $SourceExe).Hash.ToLowerInvariant()
if ($ActualSha -ne $ExpectedSha) { throw "SHA256 mismatch: $ActualSha" }
$BinDir = Join-Path $InstallRoot 'bin'
$StateDir = Join-Path $InstallRoot 'state'
$SeedDir = Join-Path $InstallRoot 'seed'
$ReceiptDir = Join-Path $InstallRoot 'receipts'
New-Item -ItemType Directory -Force -Path $BinDir,$StateDir,$SeedDir,$ReceiptDir | Out-Null
$InstalledExe = Join-Path $BinDir 'FUSE-Source-Fabric.exe'
Copy-Item -LiteralPath $SourceExe -Destination $InstalledExe -Force
if (-not (Test-Path -LiteralPath (Join-Path $StateDir 'canonical.json'))) {
  Set-Content -LiteralPath (Join-Path $SeedDir 'FUSE_SOURCE_FABRIC_BOOTSTRAP.txt') -Value "FUSE Source Fabric bootstrap seed. Bind an actual source workspace through the governed FUSE execution fabric." -Encoding UTF8
  & $InstalledExe init --root $StateDir --source $SeedDir | Out-File -LiteralPath (Join-Path $ReceiptDir 'bootstrap.json') -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw "Source Fabric bootstrap failed with exit code $LASTEXITCODE" }
}
$Existing = Get-Process -Name 'FUSE-Source-Fabric' -ErrorAction SilentlyContinue
if (-not $Existing) {
  Start-Process -FilePath $InstalledExe -ArgumentList @('serve','--root',$StateDir,'--listen',"127.0.0.1:$Port") -WindowStyle Hidden
}
$Ready = $false
for ($i=0; $i -lt 20; $i++) {
  Start-Sleep -Milliseconds 250
  try {
    $Health = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/healthz" -Method Get -TimeoutSec 2
    if ($Health.status -eq 'ok') { $Ready = $true; break }
  } catch {}
}
if (-not $Ready) { throw "FUSE Source Fabric health check did not become ready" }
$TokenPath = Join-Path $StateDir 'service.token'
$Token = (Get-Content -LiteralPath $TokenPath -Raw).Trim()
$Status = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/v1/status" -Headers @{Authorization="Bearer $Token"} -Method Get -TimeoutSec 3
$StartupCmd = "cmd.exe /c start `"`" /min `"$InstalledExe`" serve --root `"$StateDir`" --listen 127.0.0.1:$Port"
$RunKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
New-ItemProperty -Path $RunKey -Name 'FUSESourceFabric' -Value $StartupCmd -PropertyType String -Force | Out-Null
$Receipt = [ordered]@{
  schema = 'FUSE_SOURCE_FABRIC_WINDOWS_INSTALL_RECEIPT_V1'
  version = '0.4.3'
  installed_exe = $InstalledExe
  sha256 = $ActualSha
  state_root = $StateDir
  listen = "127.0.0.1:$Port"
  health = $Health.status
  canonical_manifest_id = $Status.canonical_manifest_id
  canonical_files = $Status.canonical_files
  startup = 'HKCU_RUN_CURRENT_USER'
  admin_required = $false
  public_listener = $false
  arbitrary_shell_api = $false
  installed_at = (Get-Date).ToUniversalTime().ToString('o')
}
$ReceiptPath = Join-Path $ReceiptDir 'install-receipt.json'
$Receipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $ReceiptPath -Encoding UTF8
$Receipt | ConvertTo-Json -Depth 6
