#!/usr/bin/env bash
set -Eeuo pipefail
set +x

PROJECT_ID="${PROJECT_ID:-sov-hybrid-suite}"
PROJECT_NUMBER="${PROJECT_NUMBER:-257649435135}"
REGION="${REGION:-africa-south1}"
AR_REPOSITORY="${AR_REPOSITORY:-federation-omega}"
DEPLOYER_SA="${DEPLOYER_SA:-superior-logic-deployer@${PROJECT_ID}.iam.gserviceaccount.com}"
RUNTIME_SA="${RUNTIME_SA:-superior-logic-runtime@${PROJECT_ID}.iam.gserviceaccount.com}"
CANARY_SERVICE="${CANARY_SERVICE:-sovara-model-gateway-v230-canary}"
PRODUCTION_SERVICE="${PRODUCTION_SERVICE:-sovara-model-gateway}"
RELEASE_DIR="${RELEASE_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
RECEIPT_DIR="${RECEIPT_DIR:-${RELEASE_DIR}/receipts}"
CONFIG_FILE="${CONFIG_FILE:-${RELEASE_DIR}/litellm_config.v2.3.0-converged-proof-ready.yaml}"
PREDECESSOR_FILE="${PREDECESSOR_FILE:-${RELEASE_DIR}/litellm_config.v2.2.0-proof-ready.rollback.yaml}"
CONTROL_FILE="${CONTROL_FILE:-${RELEASE_DIR}/sovara_gateway_control_v2_3.py}"
DIRECT_PROBE="${DIRECT_PROBE:-${RELEASE_DIR}/SOVARA_PROVIDER_ADMISSION_PROBE_V2.3.0.py}"
MATRIX_FILE="${MATRIX_FILE:-${RELEASE_DIR}/SOVARA_PROVIDER_CANARY_MATRIX_PRODUCTION_V2.3.0.json}"
IMAGE_TAG="${REGION}-docker.pkg.dev/${PROJECT_ID}/${AR_REPOSITORY}/sovara-model-gateway:${GITHUB_SHA:-manual-$(date -u +%Y%m%d%H%M%S)}"

mkdir -p "${RECEIPT_DIR}"

log() { printf '[SOVARA-v2.3] %s\n' "$*" >&2; }

safe_json() {
  python3 - "$@" <<'PY'
import json, sys
print(json.dumps(sys.argv[1:], sort_keys=True))
PY
}

write_state() {
  local state="$1"
  local stage="$2"
  python3 - "${RECEIPT_DIR}/STATE.json" "$state" "$stage" <<'PY'
from __future__ import annotations
import hashlib, json, sys
from datetime import datetime, timezone
from pathlib import Path
path = Path(sys.argv[1]); state = sys.argv[2]; stage = sys.argv[3]
obj = {
  "schema": "SOVARA-LITELLM-V2.3-PROVIDER-ADMISSION-STATE-1",
  "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
  "state": state,
  "stage": stage,
  "credential_values_recorded": False,
}
obj["receipt_sha256"] = hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
PY
}

record_error() {
  local stage="$1"
  local message="$2"
  python3 - "${RECEIPT_DIR}/ERRORS.jsonl" "$stage" "$message" <<'PY'
import json, sys
from datetime import datetime, timezone
with open(sys.argv[1], "a", encoding="utf-8") as handle:
    handle.write(json.dumps({
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "stage": sys.argv[2],
        "message": sys.argv[3][:2000],
    }, sort_keys=True) + "\n")
PY
}

require() {
  command -v "$1" >/dev/null 2>&1 || {
    record_error "preflight" "missing command: $1"
    return 1
  }
}

for command in gcloud docker python3 curl sha256sum; do
  require "$command" || true
done

write_state "RUNNING" "identity-preflight"

ACTIVE_ACCOUNT="$(gcloud auth list --filter=status:ACTIVE --format='value(account)' 2>/dev/null | head -n1 || true)"
ACTIVE_PROJECT="$(gcloud config get-value project 2>/dev/null | head -n1 || true)"
OBSERVED_PROJECT_NUMBER="$(gcloud projects describe "${PROJECT_ID}" --format='value(projectNumber)' 2>/dev/null | head -n1 || true)"

python3 - "${RECEIPT_DIR}/IDENTITY_PREFLIGHT.json" <<PY
import hashlib, json
obj = {
  "schema": "SOVARA-GCP-IDENTITY-PREFLIGHT-1",
  "project_id_expected": "${PROJECT_ID}",
  "project_number_expected": "${PROJECT_NUMBER}",
  "project_number_observed": "${OBSERVED_PROJECT_NUMBER}",
  "active_project": "${ACTIVE_PROJECT}",
  "active_principal_sha256": hashlib.sha256("${ACTIVE_ACCOUNT}".encode()).hexdigest() if "${ACTIVE_ACCOUNT}" else None,
  "principal_present": bool("${ACTIVE_ACCOUNT}"),
  "project_match": "${OBSERVED_PROJECT_NUMBER}" == "${PROJECT_NUMBER}",
  "credential_value_recorded": False,
}
open("${RECEIPT_DIR}/IDENTITY_PREFLIGHT.json", "w", encoding="utf-8").write(json.dumps(obj, indent=2, sort_keys=True) + "\n")
PY

if [[ -z "${ACTIVE_ACCOUNT}" || "${OBSERVED_PROJECT_NUMBER}" != "${PROJECT_NUMBER}" ]]; then
  record_error "identity-preflight" "active Google principal or project-number verification failed"
  write_state "BLOCKED" "identity-preflight"
  exit 2
fi

gcloud config set project "${PROJECT_ID}" >/dev/null

python3 "${CONTROL_FILE}" validate "${CONFIG_FILE}" \
  --predecessor "${PREDECESSOR_FILE}" \
  --expected-alias-count 33 \
  > "${RECEIPT_DIR}/STRUCTURAL_VALIDATION.json"

CONFIG_SHA="$(sha256sum "${CONFIG_FILE}" | awk '{print $1}')"
[[ "${CONFIG_SHA}" == "8cad48d954cd960b37b8c94559a19de244ffbd6d0ca1f7450dcec7b054d7d554" ]] || {
  record_error "structural-validation" "candidate configuration SHA-256 mismatch: ${CONFIG_SHA}"
  write_state "BLOCKED" "structural-validation"
  exit 3
}

# Environment binding contracts. GH_* values are injected by GitHub Actions and
# masked before any use. Existing Secret Manager versions take precedence.
declare -A ENV_TO_SECRET=(
  [SOVARA_GATEWAY_MASTER_KEY]="sovara-gateway-master-key"
  [GEMINI_API_KEY]="gemini-api-key"
  [OPENAI_API_KEY]="openai-api-key"
  [ANTHROPIC_API_KEY]="anthropic-api-key"
  [DEEPSEEK_API_KEY]="deepseek-api-key"
  [OPENROUTER_API_KEY]="openrouter-api-key"
  [OLLAMA_API_BASE]="ollama-api-base"
)

declare -A BINDING_SOURCE=()
declare -A SECRET_STATE=()

ensure_secret_container() {
  local secret="$1"
  if gcloud secrets describe "$secret" --project "$PROJECT_ID" >/dev/null 2>&1; then
    return 0
  fi
  gcloud secrets create "$secret" --project "$PROJECT_ID" --replication-policy=automatic --quiet >/dev/null 2>&1
}

load_binding() {
  local env_name="$1"
  local secret_name="${ENV_TO_SECRET[$env_name]}"
  local gh_name="GH_${env_name}"
  local value=""
  local state=""

  state="$(gcloud secrets versions describe latest --secret="$secret_name" --project="$PROJECT_ID" --format='value(state)' 2>/dev/null || true)"
  SECRET_STATE[$env_name]="${state:-NOT_FOUND}"
  if [[ "$state" == "ENABLED" ]]; then
    value="$(gcloud secrets versions access latest --secret="$secret_name" --project="$PROJECT_ID" 2>/dev/null || true)"
    if [[ -n "$value" ]]; then
      printf '::add-mask::%s\n' "$value"
      printf -v "$env_name" '%s' "$value"
      export "$env_name"
      BINDING_SOURCE[$env_name]="GCP_SECRET_MANAGER"
      return 0
    fi
  fi

  value="${!gh_name:-}"
  if [[ -n "$value" ]]; then
    printf '::add-mask::%s\n' "$value"
    printf -v "$env_name" '%s' "$value"
    export "$env_name"
    BINDING_SOURCE[$env_name]="GITHUB_ACTIONS_SECRET"
    if ensure_secret_container "$secret_name"; then
      if printf '%s' "$value" | gcloud secrets versions add "$secret_name" --project="$PROJECT_ID" --data-file=- --quiet >/dev/null 2>&1; then
        SECRET_STATE[$env_name]="ENABLED_CREATED_FROM_GITHUB_SECRET"
      else
        record_error "secret-binding" "could not add Secret Manager version for ${secret_name}"
      fi
    else
      record_error "secret-binding" "could not create Secret Manager secret ${secret_name}"
    fi
    return 0
  fi

  BINDING_SOURCE[$env_name]="MISSING"
  return 1
}

for env_name in "${!ENV_TO_SECRET[@]}"; do
  load_binding "$env_name" || true
done

if [[ "${BINDING_SOURCE[SOVARA_GATEWAY_MASTER_KEY]}" == "MISSING" ]]; then
  GENERATED_GATEWAY_KEY="sk-sovara-$(openssl rand -hex 32 2>/dev/null || python3 - <<'PY'
import secrets
print(secrets.token_hex(32))
PY
)"
  printf '::add-mask::%s\n' "$GENERATED_GATEWAY_KEY"
  export SOVARA_GATEWAY_MASTER_KEY="$GENERATED_GATEWAY_KEY"
  BINDING_SOURCE[SOVARA_GATEWAY_MASTER_KEY]="GENERATED_IN_TRUSTED_WORKFLOW"
  if ensure_secret_container "${ENV_TO_SECRET[SOVARA_GATEWAY_MASTER_KEY]}" && \
     printf '%s' "$GENERATED_GATEWAY_KEY" | gcloud secrets versions add "${ENV_TO_SECRET[SOVARA_GATEWAY_MASTER_KEY]}" --project="$PROJECT_ID" --data-file=- --quiet >/dev/null 2>&1; then
    SECRET_STATE[SOVARA_GATEWAY_MASTER_KEY]="ENABLED_GENERATED"
  else
    record_error "secret-binding" "gateway master key generated in memory but could not be persisted to Secret Manager"
  fi
fi

BINDING_JSON="$(for env_name in "${!ENV_TO_SECRET[@]}"; do printf '%s\t%s\t%s\t%s\n' "$env_name" "${ENV_TO_SECRET[$env_name]}" "${BINDING_SOURCE[$env_name]}" "${SECRET_STATE[$env_name]}"; done | sort | python3 -c 'import json,sys; rows=[]
for line in sys.stdin:
 p=line.rstrip("\n").split("\t"); rows.append({"environment_alias":p[0],"secret_name":p[1],"binding_source":p[2],"secret_state":p[3]})
print(json.dumps(rows))')"
python3 - "${RECEIPT_DIR}/SECRET_REFERENCE_METADATA.json" "$BINDING_JSON" <<'PY'
import hashlib, json, sys
rows = json.loads(sys.argv[2])
obj = {
  "schema": "SOVARA-SECRET-REFERENCE-METADATA-1",
  "bindings": rows,
  "all_runtime_values_resolved": all(row["binding_source"] != "MISSING" for row in rows),
  "all_secret_versions_enabled_or_created": all(row["secret_state"].startswith("ENABLED") for row in rows),
  "credential_values_recorded": False,
}
obj["receipt_sha256"] = hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
open(sys.argv[1], "w", encoding="utf-8").write(json.dumps(obj, indent=2, sort_keys=True) + "\n")
PY

write_state "RUNNING" "direct-provider-canaries"
set +e
python3 "${DIRECT_PROBE}" --execute --timeout 120 \
  --output "${RECEIPT_DIR}/DIRECT_PROVIDER_ADMISSION_RECEIPT.json" \
  > "${RECEIPT_DIR}/DIRECT_PROVIDER_ADMISSION_STDOUT.json"
DIRECT_RC=$?
set -e

ALL_PROVIDER_VALUES=true
for env_name in GEMINI_API_KEY OPENAI_API_KEY ANTHROPIC_API_KEY DEEPSEEK_API_KEY OPENROUTER_API_KEY OLLAMA_API_BASE; do
  [[ "${BINDING_SOURCE[$env_name]}" != "MISSING" ]] || ALL_PROVIDER_VALUES=false
done
ALL_SECRET_REFS=true
for env_name in SOVARA_GATEWAY_MASTER_KEY GEMINI_API_KEY OPENAI_API_KEY ANTHROPIC_API_KEY DEEPSEEK_API_KEY OPENROUTER_API_KEY OLLAMA_API_BASE; do
  [[ "${SECRET_STATE[$env_name]}" == ENABLED* ]] || ALL_SECRET_REFS=false
done

# Read Secret Manager metadata only. This never accesses values.
python3 - "${RECEIPT_DIR}/SECRET_MANAGER_PROVIDER_READBACK.json" <<'PY'
import json, os, subprocess, sys
mapping = {
 "SOVARA_GATEWAY_MASTER_KEY":"sovara-gateway-master-key",
 "GEMINI_API_KEY":"gemini-api-key",
 "OPENAI_API_KEY":"openai-api-key",
 "ANTHROPIC_API_KEY":"anthropic-api-key",
 "DEEPSEEK_API_KEY":"deepseek-api-key",
 "OPENROUTER_API_KEY":"openrouter-api-key",
 "OLLAMA_API_BASE":"ollama-api-base",
}
rows=[]
for alias, secret in mapping.items():
 p=subprocess.run(["gcloud","secrets","describe",secret,"--project",os.environ["PROJECT_ID"],"--format=json"],capture_output=True,text=True)
 v=subprocess.run(["gcloud","secrets","versions","describe","latest",f"--secret={secret}",f"--project={os.environ['PROJECT_ID']}","--format=json"],capture_output=True,text=True)
 meta={}
 ver={}
 try: meta=json.loads(p.stdout) if p.returncode==0 else {}
 except Exception: meta={}
 try: ver=json.loads(v.stdout) if v.returncode==0 else {}
 except Exception: ver={}
 rows.append({
   "environment_alias": alias,
   "secret_name": secret,
   "metadata_http_equivalent_success": p.returncode==0,
   "version_readback_success": v.returncode==0,
   "version_state": ver.get("state"),
   "replication": meta.get("replication"),
   "create_time": meta.get("createTime"),
   "etag_present": bool(meta.get("etag")),
 })
obj={"schema":"SOVARA-SECRET-MANAGER-PROVIDER-READBACK-1","project":os.environ["PROJECT_ID"],"bindings":rows,"all_metadata_read_back":all(x["metadata_http_equivalent_success"] for x in rows),"all_latest_versions_enabled":all(x["version_state"]=="ENABLED" for x in rows),"credential_values_recorded":False}
open(sys.argv[1],"w",encoding="utf-8").write(json.dumps(obj,indent=2,sort_keys=True)+"\n")
PY

if [[ "$ALL_SECRET_REFS" != "true" ]]; then
  record_error "gateway-deployment" "one or more required Secret Manager references are absent, inaccessible, or not enabled"
  write_state "PARTIAL_PROVIDER_PROOF" "gateway-deployment"
  exit 4
fi

write_state "RUNNING" "image-build"
gcloud artifacts repositories describe "$AR_REPOSITORY" --project "$PROJECT_ID" --location "$REGION" --format=json > "${RECEIPT_DIR}/ARTIFACT_REPOSITORY_READBACK.json"
gcloud auth configure-docker "${REGION}-docker.pkg.dev" --quiet >/dev/null

BASE_IMAGE="docker.litellm.ai/berriai/litellm:v1.94.0"
docker pull "$BASE_IMAGE" > "${RECEIPT_DIR}/BASE_IMAGE_PULL.log" 2>&1
BASE_DIGEST="$(docker image inspect "$BASE_IMAGE" --format='{{index .RepoDigests 0}}' 2>/dev/null || true)"
[[ "$BASE_DIGEST" == *@sha256:* ]] || {
  record_error "image-build" "official LiteLLM base image digest could not be resolved"
  write_state "BLOCKED" "image-build"
  exit 5
}

docker build --pull -t "$IMAGE_TAG" "$RELEASE_DIR" > "${RECEIPT_DIR}/IMAGE_BUILD.log" 2>&1
docker push "$IMAGE_TAG" > "${RECEIPT_DIR}/IMAGE_PUSH.log" 2>&1
IMAGE_DIGEST="$(gcloud artifacts docker images describe "$IMAGE_TAG" --project "$PROJECT_ID" --format='value(image_summary.digest)' 2>/dev/null || true)"
[[ "$IMAGE_DIGEST" =~ ^sha256:[a-f0-9]{64}$ ]] || {
  record_error "image-build" "derived image digest missing"
  write_state "BLOCKED" "image-build"
  exit 6
}
IMAGE_DIGEST_URI="${IMAGE_TAG%@*}@${IMAGE_DIGEST}"

python3 - "${RECEIPT_DIR}/IMAGE_ADMISSION_RECEIPT.json" <<PY
import hashlib, json
obj={
 "schema":"SOVARA-LITELLM-IMAGE-ADMISSION-1",
 "base_image":"${BASE_IMAGE}",
 "base_image_digest":"${BASE_DIGEST}",
 "derived_image_tag":"${IMAGE_TAG}",
 "derived_image_digest":"${IMAGE_DIGEST}",
 "derived_image_digest_uri":"${IMAGE_DIGEST_URI}",
 "config_sha256":"${CONFIG_SHA}",
 "state":"PASS",
}
obj["receipt_sha256"]=hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(",", ":")).encode()).hexdigest()
open("${RECEIPT_DIR}/IMAGE_ADMISSION_RECEIPT.json","w",encoding="utf-8").write(json.dumps(obj,indent=2,sort_keys=True)+"\n")
PY

SECRET_BINDINGS="SOVARA_GATEWAY_MASTER_KEY=sovara-gateway-master-key:latest,GEMINI_API_KEY=gemini-api-key:latest,OPENAI_API_KEY=openai-api-key:latest,ANTHROPIC_API_KEY=anthropic-api-key:latest,DEEPSEEK_API_KEY=deepseek-api-key:latest,OPENROUTER_API_KEY=openrouter-api-key:latest,OLLAMA_API_BASE=ollama-api-base:latest"
COMMON_ENV="LITELLM_MODE=PRODUCTION,SOVARA_GATEWAY_CONFIG_VERSION=2.3.0-converged-proof-ready,OR_APP_NAME=SOVARA_Omega,OPENROUTER_API_BASE=https://openrouter.ai/api/v1"

PREVIOUS_PROD_REVISION="$(gcloud run services describe "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format='value(status.latestReadyRevisionName)' 2>/dev/null || true)"
PREVIOUS_PROD_IMAGE="$(gcloud run services describe "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format='value(spec.template.spec.containers[0].image)' 2>/dev/null || true)"
PROD_EXISTED=false
[[ -n "$PREVIOUS_PROD_REVISION" ]] && PROD_EXISTED=true

rollback_production() {
  local reason="$1"
  record_error "production-rollback" "$reason"
  if [[ "$PROD_EXISTED" == "true" && -n "$PREVIOUS_PROD_REVISION" ]]; then
    gcloud run services update-traffic "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --to-revisions="${PREVIOUS_PROD_REVISION}=100" --quiet >/dev/null 2>&1 || true
  else
    gcloud run services delete "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --quiet >/dev/null 2>&1 || true
  fi
}

cleanup_canary() {
  gcloud run services delete "$CANARY_SERVICE" --project "$PROJECT_ID" --region "$REGION" --quiet >/dev/null 2>&1 || true
}
trap cleanup_canary EXIT

write_state "RUNNING" "cloud-run-canary-deployment"
set +e
gcloud run deploy "$CANARY_SERVICE" \
  --project "$PROJECT_ID" --region "$REGION" --platform managed \
  --image "$IMAGE_DIGEST_URI" --service-account "$RUNTIME_SA" \
  --port 8080 --cpu 1 --memory 1Gi --concurrency 40 --timeout 300 --min 0 --max 3 \
  --ingress all --allow-unauthenticated \
  --set-env-vars "$COMMON_ENV" --set-secrets "$SECRET_BINDINGS" --quiet \
  > "${RECEIPT_DIR}/CANARY_DEPLOY.log" 2>&1
CANARY_DEPLOY_RC=$?
set -e
if [[ $CANARY_DEPLOY_RC -ne 0 ]]; then
  record_error "cloud-run-canary-deployment" "Cloud Run canary deployment failed; see CANARY_DEPLOY.log"
  write_state "PARTIAL_PROVIDER_PROOF" "cloud-run-canary-deployment"
  exit 7
fi

CANARY_URL="$(gcloud run services describe "$CANARY_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format='value(status.url)')"
gcloud run services describe "$CANARY_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format=json > "${RECEIPT_DIR}/CANARY_SERVICE_READBACK.json"

set +e
python3 "$CONTROL_FILE" canary "$CONFIG_FILE" "$MATRIX_FILE" \
  --execute --gateway-url "$CANARY_URL" \
  --receipt "${RECEIPT_DIR}/CANARY_GATEWAY_SEMANTIC_RECEIPT.json" \
  > "${RECEIPT_DIR}/CANARY_GATEWAY_SEMANTIC_STDOUT.json"
CANARY_RC=$?
set -e
if [[ $CANARY_RC -ne 0 ]]; then
  record_error "cloud-run-canary" "gateway provider-family canaries failed"
  write_state "PARTIAL_PROVIDER_PROOF" "cloud-run-canary"
  exit 8
fi

write_state "RUNNING" "production-deployment"
set +e
gcloud run deploy "$PRODUCTION_SERVICE" \
  --project "$PROJECT_ID" --region "$REGION" --platform managed \
  --image "$IMAGE_DIGEST_URI" --service-account "$RUNTIME_SA" \
  --port 8080 --cpu 1 --memory 1Gi --concurrency 80 --timeout 300 --min 0 --max 5 \
  --ingress all --allow-unauthenticated \
  --set-env-vars "$COMMON_ENV" --set-secrets "$SECRET_BINDINGS" --quiet \
  > "${RECEIPT_DIR}/PRODUCTION_DEPLOY.log" 2>&1
PROD_DEPLOY_RC=$?
set -e
if [[ $PROD_DEPLOY_RC -ne 0 ]]; then
  rollback_production "production deployment failed"
  write_state "PARTIAL_PROVIDER_PROOF" "production-deployment"
  exit 9
fi

PRODUCTION_URL="$(gcloud run services describe "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format='value(status.url)')"
gcloud run services describe "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format=json > "${RECEIPT_DIR}/PRODUCTION_SERVICE_READBACK.json"
CURRENT_REVISION="$(gcloud run services describe "$PRODUCTION_SERVICE" --project "$PROJECT_ID" --region "$REGION" --format='value(status.latestReadyRevisionName)')"
CURRENT_IMAGE="$(gcloud run revisions describe "$CURRENT_REVISION" --project "$PROJECT_ID" --region "$REGION" --format='value(spec.containers[0].image)')"
CURRENT_IDENTITY="$(gcloud run revisions describe "$CURRENT_REVISION" --project "$PROJECT_ID" --region "$REGION" --format='value(spec.serviceAccountName)')"

set +e
python3 "$CONTROL_FILE" canary "$CONFIG_FILE" "$MATRIX_FILE" \
  --execute --gateway-url "$PRODUCTION_URL" \
  --receipt "${RECEIPT_DIR}/PRODUCTION_GATEWAY_SEMANTIC_RECEIPT.json" \
  > "${RECEIPT_DIR}/PRODUCTION_GATEWAY_SEMANTIC_STDOUT.json"
PRODUCTION_CANARY_RC=$?
set -e
if [[ $PRODUCTION_CANARY_RC -ne 0 ]]; then
  rollback_production "production semantic canary failed"
  write_state "ROLLED_BACK" "production-semantic-canary"
  exit 10
fi

python3 - "${RECEIPT_DIR}/FINAL_PROVIDER_DEPLOYMENT_RECEIPT.json" <<PY
import hashlib, json
from datetime import datetime, timezone
obj={
 "schema":"SOVARA-LITELLM-V2.3-FINAL-PROVIDER-DEPLOYMENT-1",
 "completed_at_utc":datetime.now(timezone.utc).isoformat(),
 "project_id":"${PROJECT_ID}",
 "project_number":"${PROJECT_NUMBER}",
 "region":"${REGION}",
 "service":"${PRODUCTION_SERVICE}",
 "service_url":"${PRODUCTION_URL}",
 "revision":"${CURRENT_REVISION}",
 "image":"${CURRENT_IMAGE}",
 "runtime_identity":"${CURRENT_IDENTITY}",
 "configuration_sha256":"${CONFIG_SHA}",
 "previous_revision":"${PREVIOUS_PROD_REVISION}",
 "previous_image":"${PREVIOUS_PROD_IMAGE}",
 "direct_provider_canary_return_code":${DIRECT_RC},
 "gateway_canary_passed":True,
 "production_gateway_traffic_proven":True,
 "raw_secret_recorded":False,
 "state":"PROVIDER_DEPLOYED_AND_SEMANTIC_CANARIES_VERIFIED"
}
obj["receipt_sha256"]=hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(",", ":")).encode()).hexdigest()
open("${RECEIPT_DIR}/FINAL_PROVIDER_DEPLOYMENT_RECEIPT.json","w",encoding="utf-8").write(json.dumps(obj,indent=2,sort_keys=True)+"\n")
PY

cleanup_canary
trap - EXIT
write_state "PROVIDER_DEPLOYED_AND_SEMANTIC_CANARIES_VERIFIED" "complete"
log "Provider admission, Cloud Run deployment, semantic canaries, and production traffic proof completed."
