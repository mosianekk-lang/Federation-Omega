#!/usr/bin/env python3
"""Secret-safe provider metadata and semantic canaries for SOVARA LiteLLM v2.3.

This module never writes credential values to output. It makes at most one short
semantic request per configured provider family and emits hashes, model identity,
usage, latency, and bounded metadata only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

SCHEMA = "SOVARA-PROVIDER-ADMISSION-PROBE-2.3.0"
SECRET_FIELDS = {
    "key", "api_key", "api-key", "token", "secret", "authorization",
    "hash", "creator_user_id", "oauth_app_id", "byok_id",
}


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def redact(value: Any) -> Any:
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key, item in value.items():
            lowered = str(key).lower()
            if lowered in SECRET_FIELDS or any(word in lowered for word in ("credential", "password")):
                result[str(key)] = "[REDACTED]"
            else:
                result[str(key)] = redact(item)
        return result
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, str) and len(value) > 512:
        return value[:512] + "...[TRUNCATED]"
    return value


def safe_headers(headers: Mapping[str, str]) -> dict[str, str]:
    allowed = {
        "content-type", "x-request-id", "x-litellm-request-id",
        "x-litellm-model-id", "x-litellm-call-id", "x-litellm-response-cost",
        "openrouter-generation-id", "cf-ray", "server",
        "x-ratelimit-limit-requests", "x-ratelimit-remaining-requests",
        "x-ratelimit-reset-requests",
    }
    return {
        str(key).lower(): str(value)[:300]
        for key, value in headers.items()
        if str(key).lower() in allowed
    }


def http_json(
    url: str,
    *,
    method: str = "GET",
    headers: Mapping[str, str] | None = None,
    payload: Mapping[str, Any] | None = None,
    timeout: float = 90.0,
) -> tuple[int, dict[str, Any], dict[str, str], bytes]:
    data = None if payload is None else json.dumps(payload, separators=(",", ":")).encode()
    request = urllib.request.Request(
        url,
        method=method,
        data=data,
        headers={"Accept": "application/json", **dict(headers or {})},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            status = response.status
            response_headers = safe_headers(dict(response.headers.items()))
    except urllib.error.HTTPError as error:
        raw = error.read()
        status = error.code
        response_headers = safe_headers(dict(error.headers.items()) if error.headers else {})
    except Exception as error:
        return 0, {"transport_error": type(error).__name__, "message": str(error)[:500]}, {}, b""
    try:
        body = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        body = {"unparsed_sha256": sha256_bytes(raw), "size_bytes": len(raw)}
    if not isinstance(body, dict):
        body = {"value": body}
    return status, body, response_headers, raw


def extract_openai_style_content(body: Mapping[str, Any]) -> str:
    choices = body.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    first = choices[0]
    if not isinstance(first, Mapping):
        return ""
    message = first.get("message")
    if not isinstance(message, Mapping):
        return ""
    content = message.get("content")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        return "".join(
            str(item.get("text", ""))
            for item in content
            if isinstance(item, Mapping)
        ).strip()
    return ""


def semantic_result(
    *,
    provider: str,
    model_requested: str,
    expected: str,
    started: float,
    status: int,
    body: Mapping[str, Any],
    headers: Mapping[str, str],
    raw: bytes,
    content: str,
    resolved_model: str | None,
    usage: Any,
) -> dict[str, Any]:
    exact = content == expected
    result = {
        "provider": provider,
        "model_requested": model_requested,
        "resolved_model": resolved_model,
        "http_status": status,
        "latency_ms": round((time.perf_counter() - started) * 1000, 3),
        "semantic_nonce_match": exact,
        "expected_response_sha256": sha256_bytes(expected.encode()),
        "actual_response_sha256": sha256_bytes(content.encode()),
        "response_body_sha256": sha256_bytes(raw),
        "response_id": body.get("id"),
        "usage": redact(usage),
        "headers": dict(headers),
        "state": "PASS" if 200 <= status < 300 and exact else "FAIL",
    }
    if result["state"] != "PASS":
        result["error_summary"] = redact(body.get("error") or body.get("message") or body)
    return result


def choose_model(catalog: list[str], preferred: list[str], contains: tuple[str, ...] = ()) -> str | None:
    for name in preferred:
        if name in catalog:
            return name
    for name in catalog:
        lowered = name.lower()
        if all(part in lowered for part in contains):
            return name
    return catalog[0] if catalog else None


def probe_openrouter(key: str, nonce: str, timeout: float) -> dict[str, Any]:
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://sovara.invalid/provider-canary",
        "X-OpenRouter-Title": "SOVARA Omega Provider Canary",
    }
    key_status, key_body, key_headers, key_raw = http_json(
        "https://openrouter.ai/api/v1/key", headers=headers, timeout=timeout
    )
    credits_status, credits_body, credits_headers, credits_raw = http_json(
        "https://openrouter.ai/api/v1/credits", headers=headers, timeout=timeout
    )
    models_status, models_body, _, _ = http_json(
        "https://openrouter.ai/api/v1/models", headers=headers, timeout=timeout
    )
    catalog = [
        str(item.get("id"))
        for item in models_body.get("data", [])
        if isinstance(item, Mapping) and item.get("id")
    ] if isinstance(models_body.get("data"), list) else []
    model = choose_model(catalog, ["openrouter/auto", "google/gemini-2.5-flash"], ("auto",)) or "openrouter/auto"
    expected = f"SOVARA_CANARY_OK::{nonce}"
    started = time.perf_counter()
    status, body, response_headers, raw = http_json(
        "https://openrouter.ai/api/v1/chat/completions",
        method="POST",
        headers=headers,
        payload={
            "model": model,
            "messages": [{"role": "user", "content": f"Return exactly this token and no other text: {expected}"}],
            "max_tokens": 96,
        },
        timeout=timeout,
    )
    semantic = semantic_result(
        provider="openrouter",
        model_requested=model,
        expected=expected,
        started=started,
        status=status,
        body=body,
        headers=response_headers,
        raw=raw,
        content=extract_openai_style_content(body),
        resolved_model=str(body.get("model") or ""),
        usage=body.get("usage"),
    )
    key_data = key_body.get("data") if isinstance(key_body.get("data"), Mapping) else key_body
    credits_data = credits_body.get("data") if isinstance(credits_body.get("data"), Mapping) else credits_body
    total_credits = credits_data.get("total_credits") if isinstance(credits_data, Mapping) else None
    total_usage = credits_data.get("total_usage") if isinstance(credits_data, Mapping) else None
    remaining = None
    if isinstance(total_credits, (int, float)) and isinstance(total_usage, (int, float)):
        remaining = round(total_credits - total_usage, 8)
    return {
        "provider": "openrouter",
        "key_metadata": {
            "http_status": key_status,
            "valid": 200 <= key_status < 300,
            "limit": key_data.get("limit") if isinstance(key_data, Mapping) else None,
            "limit_remaining": key_data.get("limit_remaining") if isinstance(key_data, Mapping) else None,
            "usage": key_data.get("usage") if isinstance(key_data, Mapping) else None,
            "usage_daily": key_data.get("usage_daily") if isinstance(key_data, Mapping) else None,
            "usage_weekly": key_data.get("usage_weekly") if isinstance(key_data, Mapping) else None,
            "usage_monthly": key_data.get("usage_monthly") if isinstance(key_data, Mapping) else None,
            "is_free_tier": key_data.get("is_free_tier") if isinstance(key_data, Mapping) else None,
            "is_management_key": key_data.get("is_management_key") if isinstance(key_data, Mapping) else None,
            "response_sha256": sha256_bytes(key_raw),
            "headers": key_headers,
            "error": None if 200 <= key_status < 300 else redact(key_body),
        },
        "credits": {
            "http_status": credits_status,
            "available": 200 <= credits_status < 300,
            "total_credits": total_credits,
            "total_usage": total_usage,
            "computed_remaining": remaining,
            "response_sha256": sha256_bytes(credits_raw),
            "headers": credits_headers,
            "error": None if 200 <= credits_status < 300 else redact(credits_body),
        },
        "catalog": {
            "http_status": models_status,
            "model_count": len(catalog),
            "selected_model": model,
        },
        "semantic": semantic,
        "state": "PASS" if 200 <= key_status < 300 and semantic["state"] == "PASS" else "FAIL",
    }


def probe_openai(key: str, nonce: str, timeout: float) -> dict[str, Any]:
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    model_status, models_body, _, _ = http_json("https://api.openai.com/v1/models", headers=headers, timeout=timeout)
    catalog = [str(item.get("id")) for item in models_body.get("data", []) if isinstance(item, Mapping) and item.get("id")] if isinstance(models_body.get("data"), list) else []
    model = choose_model(catalog, ["gpt-4o", "gpt-5.1", "gpt-5"], ("gpt",)) or "gpt-4o"
    expected = f"SOVARA_CANARY_OK::{nonce}"
    started = time.perf_counter()
    status, body, response_headers, raw = http_json(
        "https://api.openai.com/v1/chat/completions",
        method="POST", headers=headers, timeout=timeout,
        payload={"model": model, "messages": [{"role": "user", "content": f"Return exactly this token and no other text: {expected}"}], "max_tokens": 96},
    )
    semantic = semantic_result(provider="openai", model_requested=model, expected=expected, started=started, status=status, body=body, headers=response_headers, raw=raw, content=extract_openai_style_content(body), resolved_model=str(body.get("model") or ""), usage=body.get("usage"))
    return {"provider": "openai", "catalog_http_status": model_status, "catalog_model_count": len(catalog), "semantic": semantic, "state": semantic["state"]}


def probe_anthropic(key: str, nonce: str, timeout: float) -> dict[str, Any]:
    headers = {"x-api-key": key, "anthropic-version": "2023-06-01", "Content-Type": "application/json"}
    model_status, models_body, _, _ = http_json("https://api.anthropic.com/v1/models?limit=100", headers=headers, timeout=timeout)
    catalog = [str(item.get("id")) for item in models_body.get("data", []) if isinstance(item, Mapping) and item.get("id")] if isinstance(models_body.get("data"), list) else []
    model = choose_model(catalog, ["claude-sonnet-5", "claude-sonnet-4-6"], ("sonnet",)) or "claude-sonnet-5"
    expected = f"SOVARA_CANARY_OK::{nonce}"
    started = time.perf_counter()
    status, body, response_headers, raw = http_json(
        "https://api.anthropic.com/v1/messages", method="POST", headers=headers, timeout=timeout,
        payload={"model": model, "max_tokens": 96, "messages": [{"role": "user", "content": f"Return exactly this token and no other text: {expected}"}]},
    )
    content = "".join(str(item.get("text", "")) for item in body.get("content", []) if isinstance(item, Mapping)).strip() if isinstance(body.get("content"), list) else ""
    semantic = semantic_result(provider="anthropic", model_requested=model, expected=expected, started=started, status=status, body=body, headers=response_headers, raw=raw, content=content, resolved_model=str(body.get("model") or ""), usage=body.get("usage"))
    return {"provider": "anthropic", "catalog_http_status": model_status, "catalog_model_count": len(catalog), "semantic": semantic, "state": semantic["state"]}


def probe_deepseek(key: str, nonce: str, timeout: float) -> dict[str, Any]:
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    model_status, models_body, _, _ = http_json("https://api.deepseek.com/models", headers=headers, timeout=timeout)
    catalog = [str(item.get("id")) for item in models_body.get("data", []) if isinstance(item, Mapping) and item.get("id")] if isinstance(models_body.get("data"), list) else []
    model = choose_model(catalog, ["deepseek-v4-flash", "deepseek-chat"], ("deepseek",)) or "deepseek-v4-flash"
    expected = f"SOVARA_CANARY_OK::{nonce}"
    started = time.perf_counter()
    status, body, response_headers, raw = http_json(
        "https://api.deepseek.com/chat/completions", method="POST", headers=headers, timeout=timeout,
        payload={"model": model, "messages": [{"role": "user", "content": f"Return exactly this token and no other text: {expected}"}], "max_tokens": 96},
    )
    semantic = semantic_result(provider="deepseek", model_requested=model, expected=expected, started=started, status=status, body=body, headers=response_headers, raw=raw, content=extract_openai_style_content(body), resolved_model=str(body.get("model") or ""), usage=body.get("usage"))
    return {"provider": "deepseek", "catalog_http_status": model_status, "catalog_model_count": len(catalog), "semantic": semantic, "state": semantic["state"]}


def probe_gemini(key: str, nonce: str, timeout: float) -> dict[str, Any]:
    query_key = urllib.parse.quote(key, safe="")
    model_status, models_body, _, _ = http_json(f"https://generativelanguage.googleapis.com/v1beta/models?key={query_key}", timeout=timeout)
    catalog = []
    if isinstance(models_body.get("models"), list):
        for item in models_body["models"]:
            if not isinstance(item, Mapping):
                continue
            methods = item.get("supportedGenerationMethods") or []
            if "generateContent" in methods and item.get("name"):
                catalog.append(str(item["name"]).removeprefix("models/"))
    model = choose_model(catalog, ["gemini-3.7-flash", "gemini-3.6-flash", "gemini-2.5-flash"], ("flash",)) or "gemini-3.7-flash"
    expected = f"SOVARA_CANARY_OK::{nonce}"
    started = time.perf_counter()
    status, body, response_headers, raw = http_json(
        f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model, safe='')}:generateContent?key={query_key}",
        method="POST", headers={"Content-Type": "application/json"}, timeout=timeout,
        payload={"contents": [{"parts": [{"text": f"Return exactly this token and no other text: {expected}"}]}], "generationConfig": {"maxOutputTokens": 96}},
    )
    content = ""
    candidates = body.get("candidates")
    if isinstance(candidates, list) and candidates:
        first = candidates[0]
        if isinstance(first, Mapping):
            parts = first.get("content", {}).get("parts", []) if isinstance(first.get("content"), Mapping) else []
            if isinstance(parts, list):
                content = "".join(str(part.get("text", "")) for part in parts if isinstance(part, Mapping)).strip()
    usage = body.get("usageMetadata")
    semantic = semantic_result(provider="gemini", model_requested=model, expected=expected, started=started, status=status, body=body, headers=response_headers, raw=raw, content=content, resolved_model=model, usage=usage)
    return {"provider": "gemini", "catalog_http_status": model_status, "catalog_model_count": len(catalog), "semantic": semantic, "state": semantic["state"]}


def probe_ollama(api_base: str, nonce: str, timeout: float) -> dict[str, Any]:
    base = api_base.rstrip("/")
    tags_status, tags_body, _, _ = http_json(base + "/api/tags", timeout=timeout)
    catalog = [str(item.get("name")) for item in tags_body.get("models", []) if isinstance(item, Mapping) and item.get("name")] if isinstance(tags_body.get("models"), list) else []
    model = choose_model(catalog, ["llama3.1:8b", "mistral:7b"], ()) or "llama3.1:8b"
    expected = f"SOVARA_CANARY_OK::{nonce}"
    started = time.perf_counter()
    status, body, response_headers, raw = http_json(
        base + "/api/chat", method="POST", headers={"Content-Type": "application/json"}, timeout=timeout,
        payload={"model": model, "stream": False, "messages": [{"role": "user", "content": f"Return exactly this token and no other text: {expected}"}]},
    )
    content = str(body.get("message", {}).get("content", "")).strip() if isinstance(body.get("message"), Mapping) else ""
    usage = {key: body.get(key) for key in ("prompt_eval_count", "eval_count", "total_duration", "load_duration") if key in body}
    semantic = semantic_result(provider="ollama", model_requested=model, expected=expected, started=started, status=status, body=body, headers=response_headers, raw=raw, content=content, resolved_model=str(body.get("model") or model), usage=usage)
    return {"provider": "ollama", "catalog_http_status": tags_status, "catalog_model_count": len(catalog), "semantic": semantic, "state": semantic["state"]}


def run(timeout: float) -> dict[str, Any]:
    nonce = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + secrets.token_hex(6).upper()
    probes: list[dict[str, Any]] = []
    specs = [
        ("gemini", "GEMINI_API_KEY", probe_gemini),
        ("openai", "OPENAI_API_KEY", probe_openai),
        ("anthropic", "ANTHROPIC_API_KEY", probe_anthropic),
        ("deepseek", "DEEPSEEK_API_KEY", probe_deepseek),
        ("openrouter", "OPENROUTER_API_KEY", probe_openrouter),
        ("ollama", "OLLAMA_API_BASE", probe_ollama),
    ]
    for provider, env_name, function in specs:
        value = os.getenv(env_name, "")
        if not value:
            probes.append({"provider": provider, "environment_reference": env_name, "state": "BLOCKED_MISSING_BINDING"})
            continue
        try:
            probes.append(function(value, nonce, timeout))
        except Exception as error:
            probes.append({"provider": provider, "environment_reference": env_name, "state": "FAIL", "error_type": type(error).__name__, "error_message": str(error)[:500]})
    required = {"gemini", "openai", "anthropic", "deepseek", "openrouter", "ollama"}
    states = {str(item.get("provider")): str(item.get("state")) for item in probes}
    passed = all(states.get(name) == "PASS" for name in required)
    receipt: dict[str, Any] = {
        "schema": SCHEMA,
        "executed_at_utc": now_utc(),
        "nonce_sha256": sha256_bytes(nonce.encode()),
        "required_provider_families": sorted(required),
        "results": probes,
        "pass_count": sum(item.get("state") == "PASS" for item in probes),
        "fail_or_blocked_count": sum(item.get("state") != "PASS" for item in probes),
        "state": "PASS" if passed else "FAIL_OR_BLOCKED",
        "truth_boundary": {
            "network_provider_calls_attempted": True,
            "credential_values_recorded": False,
            "raw_nonce_recorded": False,
            "canonical_truth_promoted": False,
        },
    }
    receipt["receipt_sha256"] = sha256_bytes(canonical(receipt))
    return receipt


def self_test() -> dict[str, Any]:
    value = redact({"api_key": "secret", "usage": 1, "nested": {"token": "x"}})
    assert value["api_key"] == "[REDACTED]"
    assert value["nested"]["token"] == "[REDACTED]"
    assert choose_model(["b", "a"], ["a"]) == "a"
    assert extract_openai_style_content({"choices": [{"message": {"content": "ok"}}]}) == "ok"
    return {"state": "SELF_TEST_PASS", "checks": 4, "network_calls": 0, "credential_values_recorded": False}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=float, default=90.0)
    parser.add_argument("--output", type=Path, default=Path("SOVARA_PROVIDER_ADMISSION_RECEIPT.json"))
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        result = self_test()
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    if not args.execute:
        result = {"state": "PREPARED_NOT_EXECUTED", "network_calls": 0, "required_environment": ["GEMINI_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY", "OPENROUTER_API_KEY", "OLLAMA_API_BASE"]}
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    result = run(args.timeout)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if result["state"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
