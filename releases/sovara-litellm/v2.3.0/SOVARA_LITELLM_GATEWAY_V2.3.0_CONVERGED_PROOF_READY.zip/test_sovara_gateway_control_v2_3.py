from __future__ import annotations

import hashlib
import http.server
import importlib.util
import json
import os
import socketserver
import tempfile
import threading
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "control", ROOT / "sovara_gateway_control_v2_3.py"
)
control = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(control)

CONFIG = ROOT / "litellm_config.v2.3.0-converged-proof-ready.yaml"
PREDECESSOR = ROOT / "litellm_config.v2.2.0-proof-ready.rollback.yaml"
MATRIX = ROOT / "SOVARA_PROVIDER_CANARY_MATRIX_V2.3.0.json"


class MockHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        return

    def _write(self, value, status=200):
        body = json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("X-Request-ID", "mock-request")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health/liveliness":
            self._write({"status": "ok"})
            return
        if self.path == "/v1/models":
            matrix = json.loads(MATRIX.read_text())
            self._write(
                {"data": [{"id": item["alias"]} for item in matrix["canaries"]]}
            )
            return
        self._write({"error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        payload = json.loads(self.rfile.read(length))
        text = payload["messages"][0]["content"]
        expected = text.split(": ", 1)[1]
        self._write(
            {
                "id": "mock-completion",
                "model": "mock/" + payload["model"],
                "choices": [
                    {
                        "message": {"content": expected},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {
                    "prompt_tokens": 10,
                    "completion_tokens": 4,
                    "total_tokens": 14,
                },
            }
        )


class V23Tests(unittest.TestCase):
    def test_candidate_validation_passes(self):
        result = control.validate_config(
            CONFIG, predecessor_path=PREDECESSOR, expected_alias_count=33
        )
        self.assertEqual("PASS", result["state"])
        self.assertEqual(33, result["alias_count"])

    def test_all_31_predecessor_aliases_preserved(self):
        result = control.validate_config(
            CONFIG, predecessor_path=PREDECESSOR, expected_alias_count=33
        )
        self.assertTrue(
            result["compatibility"]["all_predecessor_aliases_preserved"]
        )
        self.assertEqual(31, result["compatibility"]["predecessor_alias_count"])

    def test_exact_two_additive_aliases(self):
        result = control.validate_config(
            CONFIG, predecessor_path=PREDECESSOR, expected_alias_count=33
        )
        self.assertEqual(
            [
                "openrouter-claude-sonnet-4-6",
                "openrouter-gemini-3-7-flash",
            ],
            result["compatibility"]["additive_aliases"],
        )

    def test_fallback_graph_is_acyclic(self):
        config, _ = control.load_yaml(CONFIG)
        self.assertEqual([], control.find_cycles(control.fallback_map(config)))

    def test_no_undefined_fallback_aliases(self):
        config, _ = control.load_yaml(CONFIG)
        aliases = set(control.alias_map(config))
        graph = control.fallback_map(config)
        self.assertFalse(set(graph) - aliases)
        self.assertFalse(
            {target for targets in graph.values() for target in targets} - aliases
        )

    def test_legacy_aliases_are_remapped(self):
        config, _ = control.load_yaml(CONFIG)
        aliases = control.alias_map(config)
        for alias, model in control.EXPECTED_COMPATIBILITY_MODELS.items():
            self.assertEqual(model, aliases[alias]["model"])

    def test_all_mission_aliases_present(self):
        config, _ = control.load_yaml(CONFIG)
        self.assertTrue(
            control.REQUIRED_MISSION_ALIASES.issubset(set(control.alias_map(config)))
        )

    def test_exact_environment_reference_set(self):
        config, _ = control.load_yaml(CONFIG)
        self.assertEqual(
            control.REQUIRED_ENV,
            control.collect_environment_references(config),
        )

    def test_no_temperature_in_canary_request(self):
        source = (ROOT / "sovara_gateway_control_v2_3.py").read_text()
        self.assertNotIn('"temperature":', source)

    def test_secret_reference_plan_contains_no_values(self):
        plan = json.loads(
            (ROOT / "SOVARA_PROVIDER_REFERENCE_BINDING_V2.3.0.json").read_text()
        )
        encoded = json.dumps(plan)
        self.assertNotRegex(encoded, r"\bsk-[A-Za-z0-9_-]{16,}\b")
        self.assertFalse(plan["current_state"]["credential_values_read"])

    def test_cloud_run_template_is_digest_gated(self):
        template = (ROOT / "cloud_run_service.v2.3.0.template.yaml").read_text()
        self.assertIn("IMAGE_DIGEST_URI", template)
        self.assertNotIn("main-latest", template)
        self.assertIn("openrouter-api-key", template)

    def test_deploy_script_has_exact_project_lineage(self):
        script = (ROOT / "deploy_sovara_gateway_v2_3.sh").read_text()
        self.assertIn('PROJECT_NUMBER="257649435135"', script)
        self.assertIn('PROJECT_ID="sov-hybrid-suite"', script)
        self.assertIn("@sha256:[a-f0-9]{64}", script)
        self.assertNotIn("SOVARA_EXECUTE_PROVIDER_DEPLOY", script)

    def test_control_self_test_passes(self):
        result = control.self_test()
        self.assertEqual("SELF_TEST_PASS", result["state"])
        self.assertEqual(0, result["network_calls"])

    def test_local_mock_semantic_canary_passes(self):
        server = socketserver.TCPServer(("127.0.0.1", 0), MockHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            result = control.run_canaries(
                config_path=CONFIG,
                matrix_path=MATRIX,
                gateway_url=f"http://127.0.0.1:{server.server_address[1]}",
                master_key="mock-master-key-long-enough",
                timeout=5,
            )
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)
        self.assertEqual("PASS", result["overall_state"])
        self.assertEqual(0, result["fail_count"])
        self.assertFalse(result["truth_boundary"]["master_key_recorded"])

    def test_predecessor_hash_matches_governance(self):
        config, _ = control.load_yaml(CONFIG)
        expected = hashlib.sha256(PREDECESSOR.read_bytes()).hexdigest()
        self.assertEqual(
            expected,
            config["sovara_governance"]["protected_predecessor_sha256"],
        )


if __name__ == "__main__":
    unittest.main()
