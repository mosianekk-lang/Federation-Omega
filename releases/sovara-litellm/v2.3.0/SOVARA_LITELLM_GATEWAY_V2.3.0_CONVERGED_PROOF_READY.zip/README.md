# SOVARA LiteLLM Gateway v2.3.0 — Converged Proof-Ready Release

This release converges the stronger 31-alias Drive proof-ready lane with
the useful compatibility repairs from the smaller 21-alias candidate.

## Why v2.3 exists

Promoting the smaller candidate would have removed 12 aliases, including
all five mission-level routes. v2.3 therefore uses the 31-alias release as
the protected predecessor, retains every alias, adds two useful routes,
repairs four retired/non-serving backends behind stable compatibility
names, and breaks the single fallback cycle with one edge replacement.

## Result

- protected predecessor aliases: 31
- candidate aliases: 33
- aliases removed: 0
- additive aliases: 2
- compatibility backends repaired: 4
- fallback cycles: 0
- direct/OpenRouter/Ollama families retained
- raw credential values: 0
- provider calls during build/tests: 0
- candidate deployed: no

## Control plane

`sovara_gateway_control_v2_3.py` combines structural validation, a
zero-network self-test, and nonce-bound semantic canaries. It does not
execute provider calls unless the `canary --execute` subcommand is used.

## Automated deployment

`deploy_sovara_gateway_v2_3.sh` is fully automatic when invoked from a
trusted Google runtime. It verifies exact project number 257649435135,
active principal, enabled secret versions, digest-pinned image, candidate
service canaries, production canaries, readback, and automatic rollback.

## Truth boundary

This source release is not a deployment. No credential value was read,
written, logged, or copied. No provider call or production traffic change
occurred in this build cycle.
