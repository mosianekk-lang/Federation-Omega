#!/usr/bin/env python3
"""SOVARA LiteLLM v2.3 control plane: validate, self-test, and semantic canary."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import secrets
import time
import urllib.error
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

import yaml

REQUIRED_ENV = {
    "SOVARA_GATEWAY_MASTER_KEY",
    "GEMINI_API_KEY",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "DEEPSEEK_API_KEY",
    "OPENROUTER_API_KEY",
    "OLLAMA_API_BASE",
}
REQUIRED_MISSION_ALIASES = {
    "sovara-primary",
    "sovara-fast",
    "sovara-frontier",
    "sovara-reasoning",
    "sovara-legal",
    "sovara-code",
    "sovara-router",
}
EXPECTED_COMPATIBILITY_MODELS = {
    "claude-3-5-sonnet": "anthropic/claude-sonnet-5",
    "deepseek-chat": "deepseek/deepseek-v4-flash",
    "openrouter-claude-3-5-sonnet": "openrouter/anthropic/claude-sonnet-5",
    "openrouter-deepseek-v3": "openrouter/deepseek/deepseek-v4-flash",
}
ENV_RE = re.compile(r"^os\.environ/[A-Z][A-Z0-9_]{2,79}$")
RAW_SECRET_PATTERNS = (
    re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
    re.compile(r"\bAIza[A-Za-z0-9_-]{20,}\b"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{16,}\b", re.I),
)
SAFE_HEADERS = {
    "content-type",
    "x-request-id",
    "x-litellm-request-id",
    "x-litellm-model-id",
    "x-litellm-call-id",
    "x-litellm-response-cost",
    "openrouter-generation-id",
    "cf-ray",
}


class ControlError(RuntimeError):
    pass


def canonical(value: Any) -> bytes:
    return (
        json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        + "\n"
    ).encode("utf-8")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_yaml(path: Path) -> tuple[dict[str, Any], bytes]:
    raw = path.read_bytes()
    value = yaml.safe_load(raw)
    if not isinstance(value, dict):
        raise ControlError("configuration root must be an object")
    return value, raw


def alias_map(config: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    entries = config.get("model_list")
    if not isinstance(entries, list) or not entries:
        raise ControlError("model_list must be a non-empty list")
    result: dict[str, Mapping[str, Any]] = {}
    for entry in entries:
        if not isinstance(entry, Mapping):
            raise ControlError("every model entry must be an object")
        name = str(entry.get("model_name", "")).strip()
        params = entry.get("litellm_params")
        if not name or not isinstance(params, Mapping):
            raise ControlError("every model requires model_name and litellm_params")
        if name in result:
            raise ControlError(f"duplicate alias: {name}")
        result[name] = params
    return result


def fallback_map(config: Mapping[str, Any]) -> dict[str, list[str]]:
    entries = config.get("router_settings", {}).get("fallbacks", [])
    if not isinstance(entries, list):
        raise ControlError("fallbacks must be a list")
    result: dict[str, list[str]] = {}
    for entry in entries:
        if not isinstance(entry, Mapping) or len(entry) != 1:
            raise ControlError("each fallback entry must contain one source")
        source, targets = next(iter(entry.items()))
        source = str(source)
        if source in result:
            raise ControlError(f"duplicate fallback source: {source}")
        if not isinstance(targets, list) or not all(isinstance(x, str) for x in targets):
            raise ControlError(f"fallback targets for {source} must be strings")
        result[source] = list(targets)
    return result


def find_cycles(graph: Mapping[str, list[str]]) -> list[list[str]]:
    cycles: set[tuple[str, ...]] = set()
    stack: list[str] = []
    active: set[str] = set()
    done: set[str] = set()

    def normalise(nodes: list[str]) -> tuple[str, ...]:
        body = nodes[:-1]
        rotations = [tuple(body[i:] + body[:i]) for i in range(len(body))]
        selected = min(rotations)
        return selected + (selected[0],)

    def visit(node: str) -> None:
        if node in done:
            return
        if node in active:
            start = stack.index(node)
            cycles.add(normalise(stack[start:] + [node]))
            return
        active.add(node)
        stack.append(node)
        for target in graph.get(node, []):
            if target in graph:
                visit(target)
        stack.pop()
        active.remove(node)
        done.add(node)

    for node in graph:
        visit(node)
    return [list(item) for item in sorted(cycles)]


def collect_environment_references(value: Any) -> set[str]:
    refs: set[str] = set()

    def walk(item: Any, path: str = "config") -> None:
        if isinstance(item, Mapping):
            for key, child in item.items():
                walk(child, f"{path}.{key}")
        elif isinstance(item, list):
            for index, child in enumerate(item):
                walk(child, f"{path}[{index}]")
        elif isinstance(item, str) and item.startswith("os.environ/"):
            if not ENV_RE.fullmatch(item):
                raise ControlError(f"invalid environment reference at {path}: {item}")
            refs.add(item.removeprefix("os.environ/"))

    walk(value)
    return refs


def validate_config(
    config_path: Path,
    *,
    predecessor_path: Path | None = None,
    expected_alias_count: int = 33,
) -> dict[str, Any]:
    config, raw = load_yaml(config_path)
    aliases = alias_map(config)
    graph = fallback_map(config)
    alias_names = set(aliases)

    undefined_sources = sorted(set(graph) - alias_names)
    undefined_targets = sorted(
        {target for targets in graph.values() for target in targets} - alias_names
    )
    if undefined_sources or undefined_targets:
        raise ControlError(
            f"undefined fallback references: sources={undefined_sources}, "
            f"targets={undefined_targets}"
        )

    cycles = find_cycles(graph)
    if cycles:
        raise ControlError(f"fallback cycles detected: {cycles}")

    if len(alias_names) != expected_alias_count:
        raise ControlError(
            f"expected {expected_alias_count} aliases, found {len(alias_names)}"
        )

    missing_mission = sorted(REQUIRED_MISSION_ALIASES - alias_names)
    if missing_mission:
        raise ControlError(f"missing mission aliases: {missing_mission}")

    for alias, expected_model in EXPECTED_COMPATIBILITY_MODELS.items():
        actual = str(aliases.get(alias, {}).get("model", ""))
        if actual != expected_model:
            raise ControlError(
                f"compatibility alias {alias} expected {expected_model}, got {actual}"
            )

    refs = collect_environment_references(config)
    if refs != REQUIRED_ENV:
        raise ControlError(
            f"environment reference set mismatch: expected={sorted(REQUIRED_ENV)}, "
            f"actual={sorted(refs)}"
        )

    for pattern in RAW_SECRET_PATTERNS:
        if pattern.search(raw.decode("utf-8", errors="replace")):
            raise ControlError(f"raw secret-like material matched: {pattern.pattern}")

    governance = config.get("sovara_governance")
    required_governance = {
        "decision_guard": "SOV-DEC-008",
        "provider_model_output_role": "PROPOSAL_ONLY",
        "canonical_truth_promotion": False,
        "fail_closed_on_missing_credentials": True,
        "preserve_provider_diversity": True,
        "preserve_local_open_weights_fallback": True,
        "fallback_graph_acyclic": True,
        "candidate_deployed": False,
        "provider_semantic_canary_executed": False,
    }
    if not isinstance(governance, Mapping):
        raise ControlError("sovara_governance is missing")
    for key, expected in required_governance.items():
        if governance.get(key) != expected:
            raise ControlError(
                f"governance invariant {key} expected {expected!r}, "
                f"got {governance.get(key)!r}"
            )
    if not {"SOV-DIR-005", "SOV-DIR-007"}.issubset(
        set(governance.get("directive_bindings", []))
    ):
        raise ControlError("required directive bindings are missing")

    compatibility: dict[str, Any] | None = None
    if predecessor_path:
        predecessor, predecessor_raw = load_yaml(predecessor_path)
        predecessor_aliases = set(alias_map(predecessor))
        missing = sorted(predecessor_aliases - alias_names)
        if missing:
            raise ControlError(f"predecessor aliases removed: {missing}")
        compatibility = {
            "predecessor_alias_count": len(predecessor_aliases),
            "candidate_alias_count": len(alias_names),
            "all_predecessor_aliases_preserved": True,
            "additive_aliases": sorted(alias_names - predecessor_aliases),
            "predecessor_sha256": sha256(predecessor_raw),
        }

    provider_families = sorted(
        {
            str(params["model"]).split("/", 1)[0]
            for params in aliases.values()
            if isinstance(params.get("model"), str)
        }
    )
    return {
        "state": "PASS",
        "config": str(config_path),
        "config_sha256": sha256(raw),
        "alias_count": len(alias_names),
        "fallback_source_count": len(graph),
        "fallback_edge_count": sum(len(items) for items in graph.values()),
        "fallback_cycles": [],
        "provider_families": provider_families,
        "environment_references": sorted(refs),
        "compatibility": compatibility,
        "governance": "PASS",
    }


def normalise_gateway_url(value: str) -> str:
    url = value.strip().rstrip("/")
    if not url.startswith(("https://", "http://127.0.0.1", "http://localhost")):
        raise ControlError(
            "gateway URL must use HTTPS, except loopback localhost canaries"
        )
    return url


def safe_headers(headers: Mapping[str, str]) -> dict[str, str]:
    return {
        str(key).lower(): str(value)[:300]
        for key, value in headers.items()
        if str(key).lower() in SAFE_HEADERS
    }


def http_json(
    *,
    method: str,
    url: str,
    master_key: str,
    timeout: float,
    payload: Mapping[str, Any] | None = None,
) -> tuple[int, dict[str, Any], dict[str, str], bytes]:
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        method=method,
        headers={
            "Authorization": "Bearer " + master_key,
            "Content-Type": "application/json",
            "User-Agent": "SOVARA-Gateway-Control/2.3.0",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            parsed = json.loads(raw) if raw else {}
            return response.status, parsed, safe_headers(response.headers), raw
    except urllib.error.HTTPError as error:
        raw = error.read()
        try:
            parsed = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            parsed = {"error": {"message": raw.decode(errors="replace")[:1000]}}
        return error.code, parsed, safe_headers(error.headers or {}), raw


def extract_content(response: Mapping[str, Any]) -> str:
    choices = response.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    first = choices[0]
    if not isinstance(first, Mapping):
        return ""
    message = first.get("message")
    if not isinstance(message, Mapping):
        return ""
    content = message.get("content")
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        return "".join(
            str(item.get("text", ""))
            for item in content
            if isinstance(item, Mapping)
        ).strip()
    return ""


def load_matrix(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or not isinstance(value.get("canaries"), list):
        raise ControlError("invalid canary matrix")
    return value


def run_canaries(
    *,
    config_path: Path,
    matrix_path: Path,
    gateway_url: str,
    master_key: str,
    timeout: float,
) -> dict[str, Any]:
    config, raw_config = load_yaml(config_path)
    aliases = alias_map(config)
    matrix = load_matrix(matrix_path)
    base = normalise_gateway_url(gateway_url)
    results: list[dict[str, Any]] = []

    health_status, health_body, health_headers, health_raw = http_json(
        method="GET",
        url=base + "/health/liveliness",
        master_key=master_key,
        timeout=timeout,
    )
    models_status, models_body, models_headers, models_raw = http_json(
        method="GET",
        url=base + "/v1/models",
        master_key=master_key,
        timeout=timeout,
    )

    exposed = []
    if isinstance(models_body.get("data"), list):
        exposed = sorted(
            str(item.get("id"))
            for item in models_body["data"]
            if isinstance(item, Mapping) and item.get("id")
        )

    for item in matrix["canaries"]:
        alias = str(item["alias"])
        if alias not in aliases:
            results.append(
                {
                    "id": item.get("id"),
                    "alias": alias,
                    "state": "FAIL",
                    "error": "ALIAS_NOT_IN_CONFIG",
                }
            )
            continue
        nonce = (
            "SOVARA-LITELLM-"
            + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            + "-"
            + secrets.token_hex(6).upper()
        )
        expected = "SOVARA_CANARY_OK::" + nonce
        payload = {
            "model": alias,
            "messages": [
                {
                    "role": "user",
                    "content": (
                        "Return exactly this token and no other text: " + expected
                    ),
                }
            ],
            "max_tokens": 96,
        }
        started = time.perf_counter()
        status, body, headers, raw = http_json(
            method="POST",
            url=base + "/v1/chat/completions",
            master_key=master_key,
            timeout=timeout,
            payload=payload,
        )
        content = extract_content(body)
        semantic_pass = content == expected
        results.append(
            {
                "id": item.get("id"),
                "alias": alias,
                "provider_family": item.get("provider_family"),
                "required": bool(item.get("required")),
                "http_status": status,
                "latency_ms": round((time.perf_counter() - started) * 1000, 3),
                "semantic_pass": semantic_pass,
                "expected_response_sha256": sha256(expected.encode("utf-8")),
                "actual_response_sha256": sha256(content.encode("utf-8")),
                "resolved_model": body.get("model"),
                "provider_response_id": body.get("id"),
                "usage": body.get("usage"),
                "headers": headers,
                "response_sha256": sha256(raw),
                "state": "PASS" if 200 <= status < 300 and semantic_pass else "FAIL",
            }
        )

    required = [item for item in results if item.get("required")]
    required_pass = bool(required) and all(item["state"] == "PASS" for item in required)
    receipt: dict[str, Any] = {
        "schema": "SOVARA-GATEWAY-CANARY-2.3.0",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "config_sha256": sha256(raw_config),
        "gateway_origin_sha256": sha256(base.encode("utf-8")),
        "health": {
            "http_status": health_status,
            "passed": 200 <= health_status < 300,
            "response_sha256": sha256(health_raw),
            "headers": health_headers,
        },
        "model_inventory": {
            "http_status": models_status,
            "passed": 200 <= models_status < 300,
            "exposed_aliases": exposed,
            "response_sha256": sha256(models_raw),
            "headers": models_headers,
        },
        "results": results,
        "pass_count": sum(item["state"] == "PASS" for item in results),
        "fail_count": sum(item["state"] != "PASS" for item in results),
        "overall_state": (
            "PASS"
            if 200 <= health_status < 300
            and 200 <= models_status < 300
            and required_pass
            else "FAIL"
        ),
        "truth_boundary": {
            "provider_calls_made": True,
            "master_key_recorded": False,
            "raw_nonce_recorded": False,
            "canonical_truth_promoted": False,
        },
    }
    receipt["receipt_sha256"] = sha256(canonical(receipt))
    return receipt


def self_test() -> dict[str, Any]:
    sample = {
        "router_settings": {
            "fallbacks": [
                {"a": ["b"]},
                {"b": ["c"]},
            ]
        }
    }
    assert find_cycles(fallback_map(sample)) == []
    sample["router_settings"]["fallbacks"].append({"c": ["a"]})
    assert find_cycles(fallback_map(sample))
    assert normalise_gateway_url("https://gateway.example/") == "https://gateway.example"
    assert normalise_gateway_url("http://localhost:4000") == "http://localhost:4000"
    assert "authorization" not in safe_headers(
        {"Authorization": "secret", "X-Request-ID": "r1"}
    )
    return {
        "state": "SELF_TEST_PASS",
        "checks": 5,
        "network_calls": 0,
        "raw_secret_recorded": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    validate = sub.add_parser("validate")
    validate.add_argument("config", type=Path)
    validate.add_argument("--predecessor", type=Path)
    validate.add_argument("--expected-alias-count", type=int, default=33)

    sub.add_parser("self-test")

    canary = sub.add_parser("canary")
    canary.add_argument("config", type=Path)
    canary.add_argument("matrix", type=Path)
    canary.add_argument("--gateway-url", default=os.getenv("SOVARA_GATEWAY_URL", ""))
    canary.add_argument("--master-key-env", default="SOVARA_GATEWAY_MASTER_KEY")
    canary.add_argument("--timeout", type=float, default=90.0)
    canary.add_argument("--receipt", type=Path)
    canary.add_argument("--execute", action="store_true")

    args = parser.parse_args()
    try:
        if args.command == "validate":
            result = validate_config(
                args.config,
                predecessor_path=args.predecessor,
                expected_alias_count=args.expected_alias_count,
            )
        elif args.command == "self-test":
            result = self_test()
        elif not args.execute:
            result = {
                "state": "PREPARED_NOT_EXECUTED",
                "network_calls": 0,
                "truth_boundary": {
                    "provider_call_made": False,
                    "semantic_canary_verified": False,
                },
            }
        else:
            master_key = os.getenv(args.master_key_env, "")
            if not master_key:
                raise ControlError(
                    f"required environment variable {args.master_key_env} is absent"
                )
            if len(master_key) < 16:
                raise ControlError("gateway master key is unexpectedly short")
            result = run_canaries(
                config_path=args.config,
                matrix_path=args.matrix,
                gateway_url=args.gateway_url,
                master_key=master_key,
                timeout=args.timeout,
            )
            if args.receipt:
                args.receipt.write_text(
                    json.dumps(result, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0 if result.get("state", result.get("overall_state")) in {
            "PASS",
            "SELF_TEST_PASS",
            "PREPARED_NOT_EXECUTED",
        } else 2
    except Exception as error:
        print(
            json.dumps(
                {
                    "state": "FAIL",
                    "error": f"{type(error).__name__}: {error}",
                },
                indent=2,
                sort_keys=True,
            )
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
