#!/usr/bin/env bash
set -Eeuo pipefail
set +x

PROJECT_ID="sov-hybrid-suite"
PROJECT_NUMBER="257649435135"
REGION="africa-south1"
SERVICE_ACCOUNT="sovara-model-gateway@sov-hybrid-suite.iam.gserviceaccount.com"
CANARY_SERVICE="sovara-model-gateway-v230-canary"
PROD_SERVICE="sovara-model-gateway"
CONFIG_FILE="${1:-litellm_config.v2.3.0-converged-proof-ready.yaml}"
CONTROL_FILE="${2:-sovara_gateway_control_v2_3.py}"
MATRIX_FILE="${3:-SOVARA_PROVIDER_CANARY_MATRIX_V2.3.0.json}"
RECEIPT_DIR="${SOVARA_RECEIPT_DIR:-./receipts-v2.3.0}"
IMAGE_URI="${SOVARA_LITELLM_IMAGE_DIGEST_URI:-}"
CONFIG_SECRET="sovara-litellm-config-v2-3-0"
REQUIRED_SECRETS=(
  sovara-gateway-master-key
  gemini-api-key
  openai-api-key
  anthropic-api-key
  deepseek-api-key
  openrouter-api-key
  ollama-api-base
)

mkdir -p "${RECEIPT_DIR}"

fail() {
  printf 'SOVARA_V2_3_DEPLOY_FAILED: %s\n' "$*" >&2
  exit 2
}

[[ -f "${CONFIG_FILE}" ]] || fail "missing config: ${CONFIG_FILE}"
[[ -f "${CONTROL_FILE}" ]] || fail "missing control module: ${CONTROL_FILE}"
[[ -f "${MATRIX_FILE}" ]] || fail "missing canary matrix: ${MATRIX_FILE}"
[[ "${IMAGE_URI}" =~ @sha256:[a-f0-9]{64}$ ]] || \
  fail "SOVARA_LITELLM_IMAGE_DIGEST_URI must be digest-pinned"

command -v gcloud >/dev/null || fail "gcloud is unavailable"
command -v python3 >/dev/null || fail "python3 is unavailable"

ACTIVE_PROJECT="$(gcloud config get-value project 2>/dev/null)"
[[ "${ACTIVE_PROJECT}" == "${PROJECT_ID}" ]] || \
  fail "active project ${ACTIVE_PROJECT} does not match ${PROJECT_ID}"

READ_PROJECT_NUMBER="$(
  gcloud projects describe "${PROJECT_ID}" \
    --format='value(projectNumber)'
)"
[[ "${READ_PROJECT_NUMBER}" == "${PROJECT_NUMBER}" ]] || \
  fail "project number mismatch: ${READ_PROJECT_NUMBER}"

ACTIVE_ACCOUNT="$(
  gcloud auth list --filter=status:ACTIVE --format='value(account)' | head -n1
)"
[[ -n "${ACTIVE_ACCOUNT}" ]] || fail "no active Google principal"

python3 "${CONTROL_FILE}" validate "${CONFIG_FILE}" \
  --predecessor litellm_config.v2.2.0-proof-ready.rollback.yaml \
  --expected-alias-count 33 \
  > "${RECEIPT_DIR}/structural-validation.json"

for secret in "${REQUIRED_SECRETS[@]}"; do
  state="$(
    gcloud secrets versions describe latest \
      --secret="${secret}" \
      --project="${PROJECT_ID}" \
      --format='value(state)' 2>/dev/null || true
  )"
  [[ "${state}" == "ENABLED" ]] || fail "secret ${secret} latest is not ENABLED"
done

if ! gcloud secrets describe "${CONFIG_SECRET}" \
    --project="${PROJECT_ID}" >/dev/null 2>&1; then
  gcloud secrets create "${CONFIG_SECRET}" \
    --project="${PROJECT_ID}" \
    --replication-policy=automatic \
    --quiet
fi

gcloud secrets versions add "${CONFIG_SECRET}" \
  --project="${PROJECT_ID}" \
  --data-file="${CONFIG_FILE}" \
  --quiet >/dev/null

CONFIG_SHA="$(sha256sum "${CONFIG_FILE}" | awk '{print $1}')"
PREVIOUS_REVISION="$(
  gcloud run services describe "${PROD_SERVICE}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --format='value(status.latestReadyRevisionName)' 2>/dev/null || true
)"

deploy_service() {
  local name="$1"
  gcloud run deploy "${name}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --platform=managed \
    --image="${IMAGE_URI}" \
    --service-account="${SERVICE_ACCOUNT}" \
    --command=litellm \
    --args=--config,/app/config/config.yaml,--port,4000 \
    --port=4000 \
    --cpu=1 \
    --memory=1Gi \
    --concurrency=80 \
    --timeout=300 \
    --min=0 \
    --max=5 \
    --ingress=all \
    --no-allow-unauthenticated \
    --set-env-vars="LITELLM_MODE=PRODUCTION,SOVARA_GATEWAY_CONFIG_VERSION=2.3.0-converged-proof-ready,OR_APP_NAME=SOVARA Omega,OPENROUTER_API_BASE=https://openrouter.ai/api/v1" \
    --set-secrets="SOVARA_GATEWAY_MASTER_KEY=sovara-gateway-master-key:latest,GEMINI_API_KEY=gemini-api-key:latest,OPENAI_API_KEY=openai-api-key:latest,ANTHROPIC_API_KEY=anthropic-api-key:latest,DEEPSEEK_API_KEY=deepseek-api-key:latest,OPENROUTER_API_KEY=openrouter-api-key:latest,OLLAMA_API_BASE=ollama-api-base:latest,/app/config/config.yaml=${CONFIG_SECRET}:latest" \
    --quiet
}

run_proxy_canary() {
  local service="$1"
  local port="$2"
  local receipt="$3"
  local proxy_log="${RECEIPT_DIR}/${service}-proxy.log"

  gcloud run services proxy "${service}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --port="${port}" \
    >"${proxy_log}" 2>&1 &
  local proxy_pid=$!
  trap 'kill "${proxy_pid}" >/dev/null 2>&1 || true' RETURN
  sleep 5

  export SOVARA_GATEWAY_URL="http://127.0.0.1:${port}"
  export SOVARA_GATEWAY_MASTER_KEY="$(
    gcloud secrets versions access latest \
      --secret=sovara-gateway-master-key \
      --project="${PROJECT_ID}"
  )"
  python3 "${CONTROL_FILE}" canary "${CONFIG_FILE}" "${MATRIX_FILE}" \
    --execute \
    --gateway-url="${SOVARA_GATEWAY_URL}" \
    --receipt="${receipt}"
  unset SOVARA_GATEWAY_MASTER_KEY SOVARA_GATEWAY_URL
  kill "${proxy_pid}" >/dev/null 2>&1 || true
  wait "${proxy_pid}" 2>/dev/null || true
  trap - RETURN
}

cleanup_canary() {
  gcloud run services delete "${CANARY_SERVICE}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --quiet >/dev/null 2>&1 || true
}
trap cleanup_canary EXIT

deploy_service "${CANARY_SERVICE}"
gcloud run services describe "${CANARY_SERVICE}" \
  --project="${PROJECT_ID}" \
  --region="${REGION}" \
  --format=json > "${RECEIPT_DIR}/canary-service-readback.json"

run_proxy_canary "${CANARY_SERVICE}" 18080 \
  "${RECEIPT_DIR}/canary-provider-receipt.json"

deploy_service "${PROD_SERVICE}"
gcloud run services describe "${PROD_SERVICE}" \
  --project="${PROJECT_ID}" \
  --region="${REGION}" \
  --format=json > "${RECEIPT_DIR}/production-service-readback.json"

if ! run_proxy_canary "${PROD_SERVICE}" 18081 \
    "${RECEIPT_DIR}/production-provider-receipt.json"; then
  if [[ -n "${PREVIOUS_REVISION}" ]]; then
    gcloud run services update-traffic "${PROD_SERVICE}" \
      --project="${PROJECT_ID}" \
      --region="${REGION}" \
      --to-revisions="${PREVIOUS_REVISION}=100" \
      --quiet
  fi
  fail "production semantic canary failed; prior revision restored when available"
fi

CURRENT_REVISION="$(
  gcloud run services describe "${PROD_SERVICE}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --format='value(status.latestReadyRevisionName)'
)"
READ_IMAGE="$(
  gcloud run revisions describe "${CURRENT_REVISION}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --format='value(spec.containers[0].image)'
)"
READ_IDENTITY="$(
  gcloud run revisions describe "${CURRENT_REVISION}" \
    --project="${PROJECT_ID}" \
    --region="${REGION}" \
    --format='value(spec.serviceAccountName)'
)"

python3 - "${RECEIPT_DIR}/deployment-receipt.json" <<PY
import hashlib, json, sys
receipt = {
  "schema": "SOVARA-LITELLM-V2.3-PROVIDER-DEPLOYMENT-1",
  "project_id": "${PROJECT_ID}",
  "project_number": "${PROJECT_NUMBER}",
  "active_principal_sha256": hashlib.sha256("${ACTIVE_ACCOUNT}".encode()).hexdigest(),
  "configuration_sha256": "${CONFIG_SHA}",
  "image": "${READ_IMAGE}",
  "revision": "${CURRENT_REVISION}",
  "runtime_identity": "${READ_IDENTITY}",
  "previous_revision": "${PREVIOUS_REVISION}",
  "state": "PROVIDER_SEMANTIC_CANARY_VERIFIED",
  "raw_secret_recorded": False,
}
receipt["receipt_sha256"] = hashlib.sha256(
    json.dumps(receipt, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()
open(sys.argv[1], "w", encoding="utf-8").write(
    json.dumps(receipt, indent=2, sort_keys=True) + "\n"
)
PY

cleanup_canary
trap - EXIT
printf 'SOVARA LiteLLM v2.3 deployment and semantic canaries completed.\n'
