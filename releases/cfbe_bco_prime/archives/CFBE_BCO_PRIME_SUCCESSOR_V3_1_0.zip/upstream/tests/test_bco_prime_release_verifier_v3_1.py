import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts import verify_bco_prime_successor_v3_1 as verifier


class ReleaseVerifierV31Tests(unittest.TestCase):
    def test_exhaustive_inherited_and_v31_routes(self):
        with tempfile.TemporaryDirectory() as directory:
            result = verifier.verify(Path(directory))
        self.assertEqual(result["state"], "PASS")
        self.assertEqual(result["canonical_core_routes"], 100)
        self.assertEqual(result["legacy_routes"], 24)
        self.assertEqual(result["v2_meta_routes"], 2)
        self.assertEqual(result["expected_blocked_engine_routes"], 8)
        self.assertEqual(result["v3_routes"], 14)
        self.assertEqual(result["v3_1_routes"], 9)
        self.assertTrue(result["baselineTrustRootRequired"])
        self.assertFalse(result["providerEffectAuthorized"])
        self.assertFalse(result["stablePromotionAuthorized"])
        self.assertFalse(result["ownerActionRequired"])


if __name__ == "__main__":
    unittest.main()
