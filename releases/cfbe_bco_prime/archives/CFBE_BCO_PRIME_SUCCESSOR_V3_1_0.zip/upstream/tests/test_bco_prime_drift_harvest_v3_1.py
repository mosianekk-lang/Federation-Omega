import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_baseline_registry_v3_1 as baseline
from benchmarking.cfbe_omega import bco_prime_drift_harvest_v3_1 as drift


SAFE = "# SPDX-License-Identifier: MIT\nimport hashlib\ndef verify(value: str) -> str:\n    return hashlib.sha256(value.encode()).hexdigest()\n"


def make_baseline(directory: str):
    root = Path(directory) / "monitored"
    root.mkdir()
    (root / "safe.py").write_text(SAFE, encoding="utf-8")
    archive = Path(directory) / "v3.zip"
    with zipfile.ZipFile(archive, "w") as handle:
        handle.writestr("upstream/safe.py", SAFE)
    envelope = baseline.create_signed_baseline(
        root=root,
        relative_paths=["safe.py"],
        predecessor_archive=archive,
        policies={"mode": "strict"},
        capabilities=[{"id": "cap"}],
        expected_tests={"suite": "PASS"},
        expected_results={"routes": 100},
        generation=1,
        parent_baseline_sha256="v3",
        signing_seed=b"k" * 32,
        key_id="test",
    )
    return root, envelope


class DriftHarvestV31Tests(unittest.TestCase):
    def test_secret_files_are_held_before_dna_and_metadata_is_hashed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "safe.py").write_text(SAFE, encoding="utf-8")
            (root / "secret.json").write_text('{"api_key":"super-secret-value"}', encoding="utf-8")
            (root / "jwt.md").write_text("# eyJabcdefgh.abcdefgh.abcdefgh", encoding="utf-8")
            result = drift.IncrementalCapabilityScanner(
                root,
                source_id="source",
                tenant_id="tenant",
                matter_id="matter",
                baseline_sha256="b" * 64,
            ).scan()
            self.assertEqual(result["state"], "COMPLETE")
            self.assertTrue(result["coverage_complete"])
            self.assertTrue(any(item["state"] == "SECRET_HOLD" for item in result["rejects"]))
            serialized = json.dumps(result)
            self.assertNotIn("super-secret-value", serialized)
            self.assertNotIn("secret.json", serialized)
            self.assertNotIn("jwt.md", serialized)
            self.assertTrue(result["records"])

    def test_semantic_dna_survives_move_and_partial_never_proves_deletion(self):
        with tempfile.TemporaryDirectory() as first_dir, tempfile.TemporaryDirectory() as second_dir:
            first = Path(first_dir)
            second = Path(second_dir)
            (first / "a.py").write_text(SAFE, encoding="utf-8")
            (second / "moved.py").write_text(SAFE, encoding="utf-8")
            kwargs = dict(source_id="source", tenant_id="tenant", matter_id="matter", baseline_sha256="b" * 64)
            old = drift.IncrementalCapabilityScanner(first, **kwargs).scan()
            new = drift.IncrementalCapabilityScanner(second, **kwargs).scan()
            difference = drift.diff_capability_scans(old, new)
            self.assertEqual(difference["added_dna_ids"], [])
            self.assertEqual(difference["removed_dna_ids"], [])
            self.assertTrue(difference["moved_occurrences"])
            partial = dict(new, coverage_complete=False, deletions_authoritative=False, records=[])
            partial_diff = drift.diff_capability_scans(old, partial)
            self.assertEqual(partial_diff["state"], "PARTIAL")
            self.assertEqual(partial_diff["removed_dna_ids"], [])

    def test_compound_and_transitive_licences_hold(self):
        text = "# SPDX-License-Identifier: MIT OR GPL-3.0\nimport third_party\ndef x(): return True\n"
        state = drift.license_state(text, ["third_party"], {})
        self.assertFalse(state["compatible"])
        self.assertIn("COMPOUND_SPDX_REQUIRES_REVIEW", state["reasons"])
        self.assertIn("TRANSITIVE_LICENSE_UNVERIFIED", state["reasons"])

    def test_drift_classes_scoreboard_and_shadow_repairs(self):
        with tempfile.TemporaryDirectory() as directory:
            root, envelope = make_baseline(directory)
            fingerprint = envelope["signature"]["public_key_fingerprint"]
            clean = drift.detect_drift(
                envelope,
                root=root,
                expected_public_key_fingerprint=fingerprint,
                minimum_generation=1,
                policies={"mode": "strict"},
                capabilities=[{"id": "cap"}],
                test_results={"suite": "PASS"},
                result_assertions={"routes": 100},
                coverage_complete=True,
            )
            self.assertEqual(clean["state"], "NO_DRIFT")
            (root / "safe.py").write_text(SAFE + "\n# changed\n", encoding="utf-8")
            report = drift.detect_drift(
                envelope,
                root=root,
                expected_public_key_fingerprint=fingerprint,
                minimum_generation=1,
                policies={"mode": "weak"},
                capabilities=[],
                test_results={"suite": "FAIL"},
                result_assertions={"routes": 99},
                coverage_complete=False,
            )
            classes = {item["class"] for item in report["events"]}
            self.assertTrue({"SOURCE_MODIFY", "POLICY_DRIFT", "CAPABILITY_DNA_CHANGE", "TEST_REGRESSION", "RESULT_DRIFT", "PARTIAL_OR_UNKNOWN"}.issubset(classes))
            scoreboard = drift.regression_scoreboard(report)
            self.assertEqual(scoreboard["state"], "QUARANTINED")
            self.assertEqual(drift.regression_scoreboard(clean, previous_state="QUARANTINED")["state"], "QUARANTINED")
            plan = drift.shadow_repair_plan(report, envelope["body_sha256"])
            self.assertTrue(plan["candidates"])
            self.assertTrue(all(item["executable"] is False for item in plan["candidates"]))
            self.assertFalse(plan["sourceMutationAuthorized"])

    def test_cursor_tamper_and_effect_key_evasions_fail(self):
        key = b"c" * 32
        cursor = drift.sign_cursor({"baseline_sha256": "b", "scope_sha256": "s", "next_index": 1}, key)
        self.assertEqual(drift.verify_cursor(cursor, key, baseline_sha256="b", scope_sha256="s"), 1)
        cursor["next_index"] = 2
        with self.assertRaises(drift.DriftHarvestError):
            drift.verify_cursor(cursor, key, baseline_sha256="b", scope_sha256="s")
        for payload in ({"providerEffectAuthorized": True}, {"provider-effect-authorized": True}, {"nested": {"subprocess": "run"}}):
            with self.assertRaises(drift.DriftHarvestError):
                drift.reject_effect_escape(payload)


if __name__ == "__main__":
    unittest.main()
