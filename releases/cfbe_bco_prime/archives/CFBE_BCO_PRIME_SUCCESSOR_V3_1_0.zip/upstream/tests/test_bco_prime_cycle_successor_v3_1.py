import fcntl
import json
import os
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_baseline_registry_v3_1 as baseline
from benchmarking.cfbe_omega import bco_prime_cycle_v3_1 as cycle
from benchmarking.cfbe_omega import bco_prime_successor_v3_1 as successor


SAFE = "# SPDX-License-Identifier: MIT\ndef ok(): return True\n"


def prepared(directory: str):
    root = Path(directory)
    monitored = root / "monitored"
    monitored.mkdir()
    (monitored / "module.py").write_text(SAFE, encoding="utf-8")
    archive = root / "v3.zip"
    with zipfile.ZipFile(archive, "w") as handle:
        handle.writestr("upstream/module.py", SAFE)
    envelope = baseline.create_signed_baseline(
        root=monitored,
        relative_paths=["module.py"],
        predecessor_archive=archive,
        policies={"mode": "strict"},
        capabilities=[{"id": "cap"}],
        expected_tests={"suite": "PASS"},
        expected_results={"routes": 100},
        generation=1,
        parent_baseline_sha256="v3",
        signing_seed=b"z" * 32,
        key_id="test",
    )
    return root, monitored, envelope


class CycleSuccessorV31Tests(unittest.TestCase):
    def test_cycle_commit_cancel_and_hash_chained_scoreboard(self):
        with tempfile.TemporaryDirectory() as directory:
            root, monitored, envelope = prepared(directory)
            runner = cycle.GovernedCycleRunner(root / "cycles")
            common = dict(
                cycle_id="cycle-1",
                mission_id="mission-1",
                mission_version=1,
                baseline_envelope=envelope,
                monitored_root=monitored,
                expected_public_key_fingerprint=envelope["signature"]["public_key_fingerprint"],
                minimum_generation=1,
                policies={"mode": "strict"},
                capabilities=[{"id": "cap"}],
                test_results={"suite": "PASS"},
                result_assertions={"routes": 100},
                coverage_complete=True,
            )
            cancelled = runner.run(cancel_token={"mission_version": 1, "cancelled": False, "cancel_at": ["PRE_COMMIT"]}, **common)
            self.assertEqual(cancelled["state"], "CANCELLED")
            self.assertFalse(cancelled["commitPerformed"])
            result = runner.run(cancel_token={"mission_version": 1, "cancelled": False, "cancel_at": []}, **common)
            self.assertEqual(result["state"], "PASS")
            self.assertTrue(result["commitPerformed"])
            ledger = root / "cycles" / "scoreboards" / "cycle_scoreboard_v3_1.jsonl"
            self.assertEqual(len(ledger.read_text(encoding="utf-8").splitlines()), 1)

    def test_concurrent_cycle_conflict(self):
        with tempfile.TemporaryDirectory() as directory:
            root, monitored, envelope = prepared(directory)
            runner = cycle.GovernedCycleRunner(root / "cycles")
            descriptor = os.open(runner.lock_path, os.O_CREAT | os.O_RDWR, 0o600)
            try:
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                with self.assertRaises(cycle.CycleContractError):
                    runner.run(
                        cycle_id="cycle",
                        mission_id="mission",
                        mission_version=1,
                        cancel_token={"mission_version": 1, "cancelled": False, "cancel_at": []},
                        baseline_envelope=envelope,
                        monitored_root=monitored,
                        expected_public_key_fingerprint=envelope["signature"]["public_key_fingerprint"],
                        minimum_generation=1,
                        policies={"mode": "strict"},
                        capabilities=[{"id": "cap"}],
                        test_results={"suite": "PASS"},
                        result_assertions={"routes": 100},
                        coverage_complete=True,
                    )
            finally:
                os.close(descriptor)

    def test_registry_is_additive_and_strict(self):
        with tempfile.TemporaryDirectory() as directory:
            registry = successor.SuccessorRegistryV31(Path(directory))
            health = registry.health()
            self.assertEqual(health["canonical_core_count"], 100)
            self.assertEqual(health["v3_operation_count"], 14)
            self.assertEqual(health["v3_1_operation_count"], 9)
            self.assertEqual(registry.execute("BCO-PRIME-CAP-001", {})["namespace"], "core")
            self.assertEqual(registry.execute("BCO-PRIME-V3-MANIFEST", {})["namespace"], "successor_v3")
            self.assertEqual(registry.execute("BCO-PRIME-V3-1-MANIFEST", {})["namespace"], "successor_v3_1")
            with self.assertRaises(successor.SuccessorV31ContractError):
                registry.execute("BCO-PRIME-V3-1-INCREMENTAL-SCAN", {"cancelled": "false"})
            with self.assertRaises(Exception):
                registry.execute(
                    "BCO-PRIME-V3-QUALIFY-SHADOW",
                    {"candidate": {"shadow_package": {"quarantined": True}}, "paired_cases": [], "rollback_available": "false", "independent_verifier_pass": True},
                )
            for payload in ({"providerEffectAuthorized": True}, {"provider-effect-authorized": True}, {"nested": {"stablePromotionAuthorized": True}}):
                with self.assertRaises(successor.SuccessorV31ContractError):
                    registry.execute("BCO-PRIME-V3-1-MANIFEST", payload)


if __name__ == "__main__":
    unittest.main()
