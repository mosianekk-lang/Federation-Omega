import json
import os
import sys
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_baseline_registry_v3_1 as registry


def fixture(directory: str):
    root = Path(directory) / "source"
    root.mkdir()
    (root / "module.py").write_text("# SPDX-License-Identifier: MIT\ndef ok():\n    return True\n", encoding="utf-8")
    archive = Path(directory) / "predecessor.zip"
    with zipfile.ZipFile(archive, "w") as handle:
        handle.writestr("upstream/module.py", (root / "module.py").read_bytes())
    envelope = registry.create_signed_baseline(
        root=root,
        relative_paths=["module.py"],
        predecessor_archive=archive,
        policies={"mode": "strict"},
        capabilities=[{"id": "cap-1"}],
        expected_tests={"suite": "PASS"},
        expected_results={"core": 100},
        generation=2,
        parent_baseline_sha256="sha256:v3.0",
        signing_seed=b"s" * 32,
        key_id="local-release-signer",
    )
    return root, archive, envelope


class BaselineRegistryV31Tests(unittest.TestCase):
    def test_trust_pinned_signature_and_replay_controls(self):
        with tempfile.TemporaryDirectory() as directory:
            _, _, envelope = fixture(directory)
            fingerprint = envelope["signature"]["public_key_fingerprint"]
            verified = registry.verify_signed_baseline(
                envelope,
                expected_public_key_fingerprint=fingerprint,
                minimum_generation=2,
                expected_parent_baseline_sha256="sha256:v3.0",
            )
            self.assertTrue(verified["valid"])
            self.assertEqual(verified["state"], "VERIFIED")
            self.assertFalse(verified["providerEffectAuthorized"])
            self.assertIn("SIGNING_TRUST_ROOT_REQUIRED", registry.verify_signed_baseline(envelope, expected_public_key_fingerprint=None)["failures"])
            self.assertIn("PUBLIC_KEY_FINGERPRINT_MISMATCH", registry.verify_signed_baseline(envelope, expected_public_key_fingerprint="0" * 64)["failures"])
            self.assertIn("BASELINE_REPLAY_OR_GENERATION_INVALID", registry.verify_signed_baseline(envelope, expected_public_key_fingerprint=fingerprint, minimum_generation=3)["failures"])

    def test_tamper_wrong_seed_and_key_material_non_echo(self):
        with tempfile.TemporaryDirectory() as directory:
            _, archive, envelope = fixture(directory)
            serialized = json.dumps(envelope)
            self.assertNotIn((b"s" * 32).hex(), serialized)
            tampered = json.loads(serialized)
            tampered["body"]["policies"]["mode"] = "weak"
            result = registry.verify_signed_baseline(
                tampered,
                expected_public_key_fingerprint=envelope["signature"]["public_key_fingerprint"],
            )
            self.assertFalse(result["valid"])
            self.assertIn("BODY_HASH_MISMATCH", result["failures"])
            self.assertEqual(registry.archive_manifest(archive)["coverage"], "COMPLETE")

    def test_archive_duplicates_traversal_symlinks_and_signer_absence_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            bad = Path(directory) / "bad.zip"
            with zipfile.ZipFile(bad, "w") as handle:
                handle.writestr("../escape.txt", b"no")
            with self.assertRaises(registry.BaselineContractError):
                registry.archive_manifest(bad)
            duplicate = Path(directory) / "duplicate.zip"
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                with zipfile.ZipFile(duplicate, "w") as handle:
                    handle.writestr("same.txt", b"one")
                    handle.writestr("same.txt", b"two")
            with self.assertRaises(registry.BaselineContractError):
                registry.archive_manifest(duplicate)
            root, archive, _ = fixture(directory)
            with self.assertRaises(registry.BaselineContractError):
                registry.create_signed_baseline(
                    root=root,
                    relative_paths=["module.py"],
                    predecessor_archive=archive,
                    policies={},
                    capabilities=[],
                    expected_tests={},
                    expected_results={},
                    generation=1,
                    parent_baseline_sha256="p",
                    signing_seed=b"short",
                    key_id="k",
                )

    def test_symlink_and_path_escape_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "root"
            root.mkdir()
            outside = Path(directory) / "outside.txt"
            outside.write_text("outside", encoding="utf-8")
            try:
                os.symlink(outside, root / "link.txt")
            except OSError:
                self.skipTest("symlink creation unavailable")
            with self.assertRaises((OSError, registry.BaselineContractError)):
                registry.secure_file_sha256(root, "link.txt")
            with self.assertRaises(registry.BaselineContractError):
                registry.secure_file_sha256(root, "../outside.txt")


if __name__ == "__main__":
    unittest.main()
