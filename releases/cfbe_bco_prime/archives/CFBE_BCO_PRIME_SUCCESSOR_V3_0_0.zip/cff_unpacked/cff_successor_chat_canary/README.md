# CFF independent successor-chat canary

State: `READY_NOT_EXECUTED`

This package is a two-party continuity proof for any CFF-generated ChatBridge adapter. It uses authenticated ChatGPT Library only; no separate browser or second login is required. The successor chat performs a source-independent restore and saves a hash-bound receipt to Library. The origin discovers that receipt through the universal registry and creates a separately hash-bound acknowledgement.

## Successor phase (must run in a genuinely new chat)

Resolve the exact capsule, contract, runner and manifest Library identities listed in `successor_canary_contract.json`, materialize them into one workspace directory, and run the command in `SUCCESSOR_CHAT_CANARY_PROMPT.md`.

Expected output: `successor_output/successor_chat_receipt.json` with proof state `SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING`. Save it and `successor_delta.json` to Library, then add only their pointers to the universal registry.

## Origin phase (run only after the successor returns its receipt)

```bash
python cff_successor_chat_canary/run_successor_canary.py acknowledge-origin \
  cff_successor_chat_canary/successor_output/successor_chat_receipt.json \
  --origin-chat-label "<origin chat label>"
```

Expected output: `cff_successor_chat_canary/origin_output/origin_readback_acknowledgement.json` with proof state `ACTIVE_CROSS_CHAT_VERIFIED`.

## Verification-only commands

```bash
python cff_successor_chat_canary/run_successor_canary.py verify-successor \
  cff_successor_chat_canary/successor_output/successor_chat_receipt.json

python cff_successor_chat_canary/run_successor_canary.py verify-origin \
  cff_successor_chat_canary/origin_output/origin_readback_acknowledgement.json \
  cff_successor_chat_canary/successor_output/successor_chat_receipt.json
```

The scripts cannot prove that two commands were run in different chats; that separation is an operational trust boundary and is recorded explicitly in the contract.
