#!/usr/bin/env python3
"""Two-party ChatBridge restore/write/readback canary.

The program is deterministic about validation and self-hash rules. Chat identity
is an external trust boundary, so the contract forbids running both phases in a
single chat and requires distinct declared labels.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parent
CONTRACT_PATH=ROOT/"successor_canary_contract.json"
ZERO="0"*64


def sha_bytes(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sha_text(text:str)->str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load(path:Path)->dict[str,Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical(data:dict[str,Any])->str:
    return json.dumps(data,indent=2,sort_keys=True,ensure_ascii=False)+"\n"


def self_digest(data:dict[str,Any],field:str)->str:
    copy=json.loads(json.dumps(data)); copy[field]=ZERO
    return sha_text(canonical(copy))


def capsule_content_digest(text:str)->str:
    normalized=re.sub(
        r'(?m)^(  content_sha256: )"[a-fA-F0-9]{64}"$',
        lambda m:m.group(1)+'"'+ZERO+'"',text,count=1)
    return sha_text(normalized)


def require(condition:bool,code:str)->None:
    if not condition: raise ValueError(code)


def validate_capsule(contract:dict[str,Any],capsule_path:Path|None=None)->Path:
    spec=contract["input"]
    path=capsule_path.resolve() if capsule_path else (ROOT/spec["capsule_path"]).resolve()
    require(path.is_file(),"CAPSULE_NOT_FOUND")
    require(sha_bytes(path)==spec["capsule_file_sha256"],"CAPSULE_FILE_HASH_MISMATCH")
    text=path.read_text(encoding="utf-8")
    stored=re.search(r'^  content_sha256: "([a-fA-F0-9]{64})"$',text,re.M)
    require(bool(stored),"CAPSULE_CONTENT_HASH_MISSING")
    require(stored.group(1)==spec["capsule_content_sha256"],"CONTRACT_CONTENT_HASH_MISMATCH")
    require(capsule_content_digest(text)==stored.group(1),"CAPSULE_CONTENT_HASH_MISMATCH")
    require(f'instance_key: "{spec["instance_key"]}"' in text,"CAPSULE_INSTANCE_MISMATCH")
    require(all(f"## {i}." in text for i in range(1,15)),"CAPSULE_SCHEMA_INCOMPLETE")
    return path


def verify_successor(path:Path,contract:dict[str,Any],capsule_path:Path|None=None)->dict[str,Any]:
    validate_capsule(contract,capsule_path); receipt=load(path)
    require(receipt.get("schema_version")=="1.0","RECEIPT_SCHEMA_MISMATCH")
    require(receipt.get("canary_id")==contract["canary_id"],"CANARY_ID_MISMATCH")
    require(receipt.get("proof_state")=="SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING","INVALID_SUCCESSOR_PROOF_STATE")
    require(receipt.get("receipt_self_sha256")==self_digest(receipt,"receipt_self_sha256"),"RECEIPT_SELF_HASH_MISMATCH")
    require(receipt.get("successor_chat_label") not in (None,"","UNAVAILABLE"),"SUCCESSOR_LABEL_MISSING")
    require(receipt.get("input")==contract["input"],"RECEIPT_INPUT_MISMATCH")
    require(receipt.get("restored_checkpoint")==contract["expected_restore"],"RESTORED_CHECKPOINT_MISMATCH")
    require(receipt.get("successor_assertions",{}).get("capsule_hash_valid") is True,"CAPSULE_ASSERTION_FALSE")
    require(receipt.get("successor_assertions",{}).get("checkpoint_matches") is True,"CHECKPOINT_ASSERTION_FALSE")
    require(receipt.get("successor_assertions",{}).get("origin_readback_requested") is True,"ORIGIN_READBACK_NOT_REQUESTED")
    delta=receipt.get("delta",{}); delta_path=(path.resolve().parent/delta.get("artifact_path","")).resolve()
    require(delta_path.is_file(),"DELTA_ARTIFACT_NOT_FOUND")
    require(sha_bytes(delta_path)==delta.get("artifact_sha256"),"DELTA_ARTIFACT_HASH_MISMATCH")
    delta_data=load(delta_path)
    require(delta_data.get("result")=="PASS","DELTA_RESULT_NOT_PASS")
    require(delta_data.get("capsule_content_sha256")==contract["input"]["capsule_content_sha256"],"DELTA_CAPSULE_BINDING_MISMATCH")
    return receipt


def run_successor(label:str,contract_path:Path=CONTRACT_PATH,capsule_path:Path|None=None,output_dir:Path|None=None)->Path:
    require(label.strip() not in ("","UNAVAILABLE"),"SUCCESSOR_LABEL_MISSING")
    contract=load(contract_path.resolve()); validate_capsule(contract,capsule_path)
    now=datetime.now(timezone.utc).isoformat(); stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out=(output_dir or ROOT/"successor_output").resolve(); out.mkdir(parents=True,exist_ok=True)
    delta_path=out/"successor_delta.json"
    delta={
        "schema_version":"1.0","canary_id":contract["canary_id"],
        "event_id":f"CB-{contract['input']['instance_key']}-{stamp}-successor-canary",
        "observed_at":now,"successor_chat_label":label.strip(),
        "action":"RESTORE_WRITE_READBACK","result":"PASS",
        "capsule_content_sha256":contract["input"]["capsule_content_sha256"],
        "restored_checkpoint":contract["expected_restore"],
    }
    delta_path.write_text(canonical(delta),encoding="utf-8")
    receipt={
        "schema_version":"1.0","canary_id":contract["canary_id"],
        "proof_state":"SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING",
        "observed_at":now,"successor_chat_label":label.strip(),
        "input":contract["input"],"restored_checkpoint":contract["expected_restore"],
        "delta":{"artifact_path":delta_path.name,"artifact_sha256":sha_bytes(delta_path)},
        "successor_assertions":{"capsule_hash_valid":True,"checkpoint_matches":True,"origin_readback_requested":True},
        "receipt_self_sha256":ZERO,
    }
    receipt["receipt_self_sha256"]=self_digest(receipt,"receipt_self_sha256")
    receipt_path=out/"successor_chat_receipt.json"; receipt_path.write_text(canonical(receipt),encoding="utf-8")
    verify_successor(receipt_path,contract,capsule_path)
    return receipt_path


def acknowledge_origin(receipt_path:Path,origin_label:str,contract_path:Path=CONTRACT_PATH,capsule_path:Path|None=None,output_dir:Path|None=None)->Path:
    require(origin_label.strip() not in ("","UNAVAILABLE"),"ORIGIN_LABEL_MISSING")
    contract=load(contract_path.resolve()); successor=verify_successor(receipt_path.resolve(),contract,capsule_path)
    require(origin_label.strip()!=successor["successor_chat_label"],"ORIGIN_AND_SUCCESSOR_LABELS_MUST_DIFFER")
    now=datetime.now(timezone.utc).isoformat(); out=(output_dir or ROOT/"origin_output").resolve(); out.mkdir(parents=True,exist_ok=True)
    ack={
        "schema_version":"1.0","canary_id":contract["canary_id"],
        "proof_state":"ACTIVE_CROSS_CHAT_VERIFIED","observed_at":now,
        "origin_chat_label":origin_label.strip(),"successor_chat_label":successor["successor_chat_label"],
        "successor_receipt_path":str(receipt_path.resolve()),
        "successor_receipt_file_sha256":sha_bytes(receipt_path.resolve()),
        "successor_receipt_self_sha256":successor["receipt_self_sha256"],
        "capsule_content_sha256":contract["input"]["capsule_content_sha256"],
        "origin_assertions":{"successor_receipt_readback":True,"delta_artifact_readback":True,"distinct_declared_chat_labels":True},
        "ack_self_sha256":ZERO,
    }
    ack["ack_self_sha256"]=self_digest(ack,"ack_self_sha256")
    path=out/"origin_readback_acknowledgement.json"; path.write_text(canonical(ack),encoding="utf-8")
    verify_origin(path,receipt_path.resolve(),contract,capsule_path)
    return path


def verify_origin(ack_path:Path,receipt_path:Path,contract:dict[str,Any],capsule_path:Path|None=None)->dict[str,Any]:
    successor=verify_successor(receipt_path.resolve(),contract,capsule_path); ack=load(ack_path.resolve())
    require(ack.get("canary_id")==contract["canary_id"],"ACK_CANARY_ID_MISMATCH")
    require(ack.get("proof_state")=="ACTIVE_CROSS_CHAT_VERIFIED","ACK_PROOF_STATE_INVALID")
    require(ack.get("ack_self_sha256")==self_digest(ack,"ack_self_sha256"),"ACK_SELF_HASH_MISMATCH")
    require(ack.get("successor_receipt_file_sha256")==sha_bytes(receipt_path.resolve()),"ACK_RECEIPT_FILE_HASH_MISMATCH")
    require(ack.get("successor_receipt_self_sha256")==successor["receipt_self_sha256"],"ACK_RECEIPT_SELF_HASH_MISMATCH")
    require(ack.get("origin_chat_label")!=ack.get("successor_chat_label"),"ACK_CHAT_LABELS_NOT_DISTINCT")
    require(all(ack.get("origin_assertions",{}).values()),"ACK_ASSERTION_FALSE")
    return ack


def main()->int:
    p=argparse.ArgumentParser(); sub=p.add_subparsers(dest="command",required=True)
    def sources(parser:argparse.ArgumentParser)->None:
        parser.add_argument("--contract",type=Path,default=CONTRACT_PATH)
        parser.add_argument("--capsule",type=Path)
    vp=sub.add_parser("validate-package"); sources(vp)
    run=sub.add_parser("run"); sources(run); run.add_argument("--successor-chat-label",required=True); run.add_argument("--output-dir",type=Path)
    vs=sub.add_parser("verify-successor"); sources(vs); vs.add_argument("receipt",type=Path)
    ao=sub.add_parser("acknowledge-origin"); sources(ao); ao.add_argument("receipt",type=Path); ao.add_argument("--origin-chat-label",required=True); ao.add_argument("--output-dir",type=Path)
    vo=sub.add_parser("verify-origin"); sources(vo); vo.add_argument("ack",type=Path); vo.add_argument("receipt",type=Path)
    args=p.parse_args()
    try:
        contract=load(args.contract.resolve())
        if args.command=="validate-package": path=validate_capsule(contract,args.capsule); result={"status":"PASS","proof_state":contract["proof_state"],"capsule":str(path),"capsule_file_sha256":sha_bytes(path)}
        elif args.command=="run": path=run_successor(args.successor_chat_label,args.contract,args.capsule,args.output_dir); result={"status":"PASS","proof_state":"SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING","receipt":str(path),"receipt_file_sha256":sha_bytes(path)}
        elif args.command=="verify-successor": verify_successor(args.receipt.resolve(),contract,args.capsule); result={"status":"PASS","receipt":str(args.receipt.resolve())}
        elif args.command=="acknowledge-origin": path=acknowledge_origin(args.receipt,args.origin_chat_label,args.contract,args.capsule,args.output_dir); result={"status":"PASS","proof_state":"ACTIVE_CROSS_CHAT_VERIFIED","acknowledgement":str(path),"ack_file_sha256":sha_bytes(path)}
        else: verify_origin(args.ack,args.receipt,contract,args.capsule); result={"status":"PASS","acknowledgement":str(args.ack.resolve())}
        print(json.dumps(result,sort_keys=True)); return 0
    except Exception as exc:
        print(json.dumps({"status":"FAIL","error":str(exc)},sort_keys=True),file=sys.stderr); return 2


if __name__=="__main__": raise SystemExit(main())
