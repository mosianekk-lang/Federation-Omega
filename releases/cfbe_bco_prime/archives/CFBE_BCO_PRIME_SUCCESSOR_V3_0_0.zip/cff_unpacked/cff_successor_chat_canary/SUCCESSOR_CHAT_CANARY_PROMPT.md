# Independent successor-chat canary instruction

You are the **successor** side of `CFF-CROSS-CHAT-20260818-001`. Use only authenticated ChatGPT Library and the local workspace supplied to this chat. Do not use a separate browser, anonymous ChatGPT session, prior-chat memory, summaries, or claims as authority.

Resolve and materialize these exact Library assets into one local directory:

- capsule: `libfile_7203c2f4a92c8191a0957ec6325242fe` v2;
- contract: `libfile_a724edc52f44819189d1187d40c00420` v1;
- runner: `libfile_6654e793e6088191bcb955a29bd667a7` v1;
- package manifest: `libfile_0d9869c2df948191957c003d18a05d51` v1.

Then execute with the materialized paths:

```bash
python run_successor_canary.py run \
  --contract successor_canary_contract.json \
  --capsule CHATBRIDGE-future-conversation-audit-canary-forensics-CURRENT.md \
  --output-dir successor_output \
  --successor-chat-label "<this exact authenticated chat label>"
```

The runner must:

1. verify the capsule file SHA-256 and its normalized internal `content_sha256`;
2. restore the expected checkpoint (`PARTIAL_CHECKPOINTED`) and the single next action (`ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN`);
3. write a new delta artifact and self-hashed successor receipt;
4. verify both by readback;
5. leave proof state `SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING`.

Save `successor_delta.json` and `successor_chat_receipt.json` as new authenticated Library files. Record their returned stable Library identities and versions in `CHATBRIDGE — UNIVERSAL — REGISTRY.md` with state `SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING`. This lets the origin discover and read them without a separate browser or manual copy/paste.

Do **not** claim `ACTIVE_CROSS_CHAT_VERIFIED`; only the origin chat may promote after independently retrieving and verifying both Library files and writing its origin acknowledgement.

Truth boundary: this canary proves continuity transport only. It does not prove native context telemetry and cannot change the audit from `PARTIAL_CHECKPOINTED` to `COMPLETE_VERIFIED`.
