# CFF Library-native successor canary trigger

Use this exact one-line instruction in a genuinely new authenticated ChatGPT chat:

> Execute CFF Library successor canary `CFF-CROSS-CHAT-20260818-001`; resolve the exact Library assets from the installed Conversation Failure Forensics skill, perform successor restore/write/readback only, save the delta and receipt to Library, update the universal registry with their pointers, and stop before origin acknowledgement.

The successor chat must load the installed `conversation-failure-forensics` skill and read its Library-native canary reference. It must not use a separate browser, anonymous session, memory, or a pasted summary as authority.

Expected terminal state: `SUCCESSOR_WRITE_VERIFIED_ORIGIN_READBACK_PENDING`.

Forbidden promotion: `ACTIVE_CROSS_CHAT_VERIFIED` remains unavailable until this origin chat independently retrieves the Library receipt and delta, verifies both, and writes the origin acknowledgement. The audit itself remains `PARTIAL_CHECKPOINTED` until native context telemetry is proven.
