#!/usr/bin/env python3
"""Universal launcher for Conversation Failure Forensics v2."""
from app_mentions_forensic_audit_v2 import *  # noqa: F401,F403
from app_mentions_forensic_audit_v2 import main

if __name__ == "__main__":
    raise SystemExit(main())
