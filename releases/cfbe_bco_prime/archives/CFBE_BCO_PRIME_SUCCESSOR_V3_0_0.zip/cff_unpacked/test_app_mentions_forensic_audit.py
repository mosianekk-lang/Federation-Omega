import json
import tempfile
import unittest
from pathlib import Path

import app_mentions_forensic_audit_v2 as cff


def node(node_id, parent, role, text, ts, children=None):
    return {
        "id": node_id, "parent": parent, "children": children or [],
        "message": {
            "id": f"m-{node_id}", "author": {"role": role}, "create_time": ts,
            "content": {"content_type": "text", "parts": [text]}, "metadata": {},
        },
    }


def fixture(extra_claim=False, alternate=False, explicit_limit=False, title="App mentions"):
    rows = [
        ("user", "Consolidate the two TUT Extract folders and preserve provenance."),
        ("assistant", "Completed the consolidation; source IDs and hashes were verified by readback."),
        ("user", "Process the corpus into the 21 August preparation bundle."),
        ("assistant", "The corpus processing is queued and I will now continue."),
        ("user", "n"),
        ("assistant", "I can permanently monitor all chats automatically with no length limit." if extra_claim else "I am continuing the corpus work."),
        ("user", "Continue processing the TUT Extract corpus."),
        ("assistant", "I cannot access or monitor other chats automatically." if extra_claim else "Checkpoint saved with SHA-256 readback."),
        ("user", "checkpoint and save the verified work"),
        ("assistant", "Checkpoint saved with source hashes and version readback."),
    ]
    if explicit_limit:
        rows += [("user", "The conversation reached its maximum context limit."), ("assistant", "Start a new chat using the handoff.")]
    mapping = {}; parent = None
    for idx, (role, text) in enumerate(rows, 1):
        nid=f"n{idx}"; mapping[nid]=node(nid,parent,role,text,float(idx))
        if parent: mapping[parent]["children"].append(nid)
        parent=nid
    if alternate:
        mapping["n2"]["children"].append("alt3")
        mapping["alt3"]=node("alt3","n2","user","Abandoned alternate request",2.5,["alt4"])
        mapping["alt4"]=node("alt4","alt3","assistant","Abandoned alternate answer",2.6)
    return [{"id":"conv-1","title":title,"mapping":mapping,"current_node":parent}]


class CFFv2Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
        self.source=self.root/"conversations.json"; self.config=Path("app_mentions_audit_config.json")

    def tearDown(self): self.tmp.cleanup()
    def write(self, payload): self.source.write_text(json.dumps(payload),encoding="utf-8")

    def test_full_run_writes_seven_outputs(self):
        self.write(fixture(alternate=True)); report, outputs=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertEqual(report["audit"]["version"],"2.0.0"); self.assertEqual(len(outputs),7)
        self.assertTrue(all(Path(p).exists() for p in outputs.values()))
        self.assertEqual(report["branch_forensics"]["branch_count"],2)

    def test_hash_chain_and_tamper_detection(self):
        self.write(fixture()); messages,meta=cff.core.load_source(self.source,"App mentions")
        ledger=cff.event_ledger(messages,meta); self.assertTrue(cff.validate_ledger(ledger))
        ledger[2]["role"]="tampered"; self.assertFalse(cff.validate_ledger(ledger))

    def test_capability_overclaim_is_detected(self):
        self.write(fixture(extra_claim=True)); report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertTrue(report["failure_signatures"]["capability_overclaim_exchanges"])

    def test_evidenced_completion_not_confidence_failure(self):
        self.write(fixture()); report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertNotIn(1,report["failure_signatures"]["confidence_without_evidence_exchanges"])

    def test_potential_claim_conflict(self):
        self.write(fixture(extra_claim=True)); report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertGreaterEqual(report["failure_signatures"]["potential_claim_conflicts"],1)

    def test_explicit_limit_allows_complete_state(self):
        self.write(fixture(explicit_limit=True)); cfg=json.loads(self.config.read_text()); cfg["v2"]["native_context_telemetry_verified"]=True
        proven=self.root/"proven.json"; proven.write_text(json.dumps(cfg))
        report,_=cff.run(self.source,"App mentions",proven,self.root/"out")
        self.assertEqual(report["audit"]["state"],"COMPLETE_VERIFIED")

    def test_explicit_limit_without_native_telemetry_stays_partial(self):
        self.write(fixture(explicit_limit=True)); report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertEqual(report["audit"]["state"],"PARTIAL_CHECKPOINTED")

    def test_absent_limit_stays_partial(self):
        self.write(fixture()); report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertEqual(report["audit"]["state"],"PARTIAL_CHECKPOINTED")

    def test_shield_state_boundaries(self):
        self.assertEqual(cff.shield(.49)[0],"HEALTHY")
        self.assertEqual(cff.shield(.50)[0],"CAPACITY_RISK")
        self.assertEqual(cff.shield(.70)[0],"HANDOFF_REQUIRED")
        self.assertEqual(cff.shield(.85)[0],"SCOPE_FREEZE")
        self.assertEqual(cff.shield(.95)[0],"TERMINAL_GUARD")

    def test_change_ensemble_schema(self):
        result=cff.ensemble([.1,.1,.1,.1,.1,.1,.8,.9,.9,.9])
        self.assertEqual(set(result["detectors"]),{"cusum","page_hinkley","ewma"})

    def test_duplicate_exact_titles_fail_closed(self):
        self.write(fixture()+fixture())
        with self.assertRaises(ValueError): cff.core.load_source(self.source,"App mentions")

    def test_transaction_manifest_is_semantically_committed(self):
        self.write(fixture()); _,outputs=cff.run(self.source,"App mentions",self.config,self.root/"out")
        tx=json.loads(Path(outputs["transaction"]).read_text())
        self.assertEqual(tx["commitState"],"COMMITTED"); self.assertEqual(tx["publishState"],"PUBLISHED")
        self.assertTrue(all(x["readback"] and x["expected"]==x["actual"] for x in tx["writes"]))

    def test_duplicate_native_message_ids_fail_closed(self):
        payload=fixture(); payload[0]["mapping"]["n2"]["message"]["id"]="m-n1"; self.write(payload)
        with self.assertRaisesRegex(ValueError,"Duplicate native message IDs"):
            cff.run(self.source,"App mentions",self.config,self.root/"out")

    def test_v1_rollback_parser_remains_available(self):
        self.assertEqual(cff.core.VERSION,"1.0.0")

    def test_replay_is_deterministic_except_transaction_timestamp(self):
        self.write(fixture()); _,a=cff.run(self.source,"App mentions",self.config,self.root/"a"); _,b=cff.run(self.source,"App mentions",self.config,self.root/"b")
        self.assertEqual(Path(a["ledger"]).read_bytes(),Path(b["ledger"]).read_bytes())

    def test_dashboard_is_evidence_bounded_and_interactive(self):
        self.write(fixture(explicit_limit=True)); report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        page=cff.dashboard(report)
        self.assertIn("Evidence boundary",page)
        self.assertIn("Risk trajectory",page)
        self.assertIn("Contributing factors",page)
        self.assertIn("aria-live=\"polite\"",page)
        self.assertIn("ResizeObserver",page)
        self.assertNotIn("background:#c0392b",page)

    def test_universal_title_derives_collision_safe_outputs(self):
        self.write(fixture(title="Future Work: Audit / 2026"))
        report,outputs=cff.run(self.source,"Future Work: Audit / 2026",Path("conversation_audit_config.json"),self.root/"out")
        self.assertEqual(report["audit"]["target_title"],"Future Work: Audit / 2026")
        self.assertEqual(Path(outputs["json"]).name,"future_work_audit_2026_forensic_audit_v2.json")
        self.assertEqual(Path(outputs["capsule"]).name,"CHATBRIDGE-future-work-audit-2026-forensics-CURRENT.md")
        self.assertIn("# CHATBRIDGE — future-work-audit-2026-forensics — CURRENT",Path(outputs["capsule"]).read_text())
        self.assertNotIn("app-mentions-forensics",Path(outputs["capsule"]).read_text())

    def test_capsule_implements_complete_chatbridge_schema(self):
        self.write(fixture(title="Future Work Audit"))
        report,outputs=cff.run(self.source,"Future Work Audit",Path("conversation_audit_config.json"),self.root/"out")
        text=Path(outputs["capsule"]).read_text()
        self.assertEqual(cff.validate_capsule(text),(True,"VALID"))
        self.assertTrue(all(f"## {i}." in text for i in range(1,15)))
        self.assertIn('schema_version: "1.1"',text)
        self.assertIn('status: "ACTIVE_LOCAL"',text)
        self.assertIn("cross-chat `NOT_EXECUTED`",text)
        self.assertEqual(report["audit"]["state"],"PARTIAL_CHECKPOINTED")

    def test_capsule_hash_detects_tampering(self):
        self.write(fixture())
        report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        text=cff.capsule(report)
        self.assertEqual(cff.validate_capsule(text),(True,"VALID"))
        self.assertEqual(cff.validate_capsule(text.replace("Audit state","Audit status",1)),(False,"CONTENT_HASH_MISMATCH"))

    def test_capsule_generation_is_deterministic_for_same_report(self):
        self.write(fixture())
        report,_=cff.run(self.source,"App mentions",self.config,self.root/"out")
        self.assertEqual(cff.capsule(report),cff.capsule(report))
        self.assertEqual(cff.capsule_digest(cff.capsule(report)),cff.capsule_digest(cff.capsule(report)))

    def test_output_prefix_controls_capsule_identity_and_filename(self):
        self.write(fixture(title="Future Work Audit"))
        _,outputs=cff.run(self.source,"Future Work Audit",Path("conversation_audit_config.json"),self.root/"out","bounded-canary")
        text=Path(outputs["capsule"]).read_text()
        self.assertEqual(Path(outputs["capsule"]).name,"CHATBRIDGE-bounded-canary-forensics-CURRENT.md")
        self.assertIn('# CHATBRIDGE — bounded-canary-forensics — CURRENT',text)
        self.assertIn('instance_key: "bounded-canary-forensics"',text)
        self.assertEqual(cff.validate_capsule(text),(True,"VALID"))


if __name__=="__main__": unittest.main()
