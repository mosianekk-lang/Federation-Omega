# CHATBRIDGE — app-mentions-forensics — CURRENT

```yaml
chatbridge:
  schema_version: "1.1"
  instance_name: "App mentions Conversation Forensics"
  instance_key: "app-mentions-forensics"
  instance_type: "workstream"
  parent_instance_key: "conversation-failure-forensics"
  related_instance_keys: []
  owner: "Kagiso Kim Mosiane"
  lifecycle: "ACTIVE"
  status: "ACTIVE_LOCAL"
  revision: 1
  updated_at: "2026-08-18T20:39:47.718446+00:00"
  current_version: "LOCAL_GENERATED_UNVERSIONED"
  previous_content_sha256: "UNAVAILABLE"
  content_sha256: "42c1bf8adfc76cedaf89eec18fda797283e6d83750c6b309c74f5c3c9e4cf727"
  sensitivity: "USER_WORK_PRODUCT"
```

## 1. Scope, purpose, and completion definition

- Bounded subject: forensic audit of the exact conversation titled `App mentions`.
- Included: recovered native messages, canonical/alternate branches, directives, response evidence, drift, risk proxies, checkpoints, claims, source lineage, and continuity state.
- Excluded unless separately proven: hidden prompts, server-side token counters, deleted/unexported messages, router state, and causal certainty from proxies alone.
- Objective: locate the earliest defensible trouble/drift point, explain contributing factors, preserve proof, and enable safe continuation.
- Non-goals: reconstruct unavailable platform internals or promote inference to native fact.
- Owner: Kagiso Kim Mosiane.
- Done when: the exact native source is complete, IDs/timestamps/branches reconcile, a terminal event and native telemetry are verified where relevant, outputs pass readback, and an independent successor chat returns a valid bidirectional receipt.

## 2. Authority and truth controls

- Source precedence: native transcript/export and native telemetry > authenticated source artifacts > hash-verified capsule/ledger > summaries or memory > inference.
- Governing controls: CFF v2.0.0; ChatBridge schema 1.1; SHIELD-95 thresholds 50/70/85/95%.
- Permissions: analyze and write bounded local audit artifacts only; no external communication is authorized by this adapter.
- Privacy: do not copy full transcript content into the capsule; preserve stable IDs, hashes, and compact findings.
- Release limit: `COMPLETE_VERIFIED` and `ACTIVE_CROSS_CHAT_VERIFIED` are prohibited until their independent evidence gates pass.

## 3. Current verified state

| Item | State | Truth label / source |
|---|---|---|
| Audit state | PARTIAL_CHECKPOINTED | audit report |
| Source | `cff_v2_validation_fixture.json` | native-source candidate |
| Source SHA-256 | `a1c639a1bb2aa1ce9165a81f5dd28ef2d5cf9fd625957244d1f90b867a8d051c` | computed from input bytes |
| Messages / exchanges | 6 / 3 | recovered source |
| Message-ID coverage | 6 of 6 | native fields |
| Branch count | 1 | native mapping analysis |
| Earliest sustained drift | 1 | transcript-derived |
| Explicit terminal signal exchanges | [3] | transcript evidence |
| Native context telemetry | UNAVAILABLE | native platform evidence gate |
| SHIELD-95 | HEALTHY — `CONTINUE_WITH_MATERIAL_EVENT_CHECKPOINTS` | estimated proxy |
| Leading factors | drift=49.2%, topic_shift=18.2%, lane_entropy=17.1%, capacity=8.1%, status_only=4.6% | derived linear attribution |
| Cross-chat proof | NOT_EXECUTED | independent successor receipt required |

## 4. Directive register

| ID | Instruction | Date | Status | Scope | Source | Supersession |
|---|---|---|---|---|---|---|
| DIR-00001 | Directive at native message `m1` | UNAVAILABLE | CLAIMED_COMPLETE_EVIDENCED | audit target | native transcript message ID | NONE |
| DIR-00002 | Directive at native message `m3` | UNAVAILABLE | RESPONDED_UNVERIFIED | audit target | native transcript message ID | NONE |

## 5. Workstream registry

| ID | Objective | Status | Latest checkpoint | Dependencies | Next action | Proof required |
|---|---|---|---|---|---|---|
| WS-CFF-AUDIT | Audit the recovered conversation from start to terminal state | PARTIAL_CHECKPOINTED | 2026-08-18T20:39:47.718446+00:00 | exact source; native telemetry for completion | `ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN` | native evidence plus output readback |
| WS-CFF-CONTINUITY | Preserve and independently restore audit state | READY_NOT_EXECUTED | complete local capsule generated | independent successor chat | execute restore/write/readback canary | signed/hash-bound bidirectional receipt |

## 6. Decision register

| ID | Decision | Rationale | Source | Date | Reversal / supersession |
|---|---|---|---|---|---|
| DEC-CFF-001 | Native evidence controls all completion claims | Prevent inferred context/cause from becoming fact | CFF truth boundary | 2026-08-18T20:39:47.718446+00:00 | NONE |
| DEC-CFF-002 | Missing native telemetry keeps the audit partial | Context proxies cannot prove a platform limit | CFF completion gate | 2026-08-18T20:39:47.718446+00:00 | Reverse only with native evidence |
| DEC-CFF-003 | Local capsule generation is not cross-chat verification | A separate chat must independently restore and return a delta receipt | ChatBridge proof model | 2026-08-18T20:39:47.718446+00:00 | Reverse only after valid canary readback |

## 7. Fact and issue register

| ID | Item | Truth label | Exact source pointer | Dispute / qualification |
|---|---|---|---|---|
| FACT-CFF-001 | 6 messages and 3 exchanges were analyzed | NATIVE_SOURCE_DERIVED | `cff_v2_validation_fixture.json` / `a1c639a1bb2aa1ce9165a81f5dd28ef2d5cf9fd625957244d1f90b867a8d051c` | Only the recovered source boundary is claimed |
| FACT-CFF-002 | Terminal signal exchanges: [3] | TRANSCRIPT_EVIDENCE | `change_points.explicit_limit_signal_exchanges` | Absence does not prove no platform limit occurred |
| ISSUE-CFF-001 | Native context telemetry: unavailable | UNVERIFIED | `source_completeness.native_token_telemetry_present` | Required for native capacity certainty |
| ISSUE-CFF-002 | Factor shares: drift=49.2%, topic_shift=18.2%, lane_entropy=17.1%, capacity=8.1%, status_only=4.6% | DERIVED_LINEAR_COUNTERFACTUAL_ATTRIBUTION | `ranked_contributing_factors_v2` | Association/proxy, not causal proof |

## 8. Artifact and source index

| ID | Title | Role | Location / connector | Modified | Hash | Status |
|---|---|---|---|---|---|---|
| SRC-CFF-001 | cff_v2_validation_fixture.json | bounded audit source | `cff_v2_validation_fixture.json` | UNAVAILABLE | `a1c639a1bb2aa1ce9165a81f5dd28ef2d5cf9fd625957244d1f90b867a8d051c` | recovered |
| ART-CFF-001 | app_mentions_forensic_audit_v2.json | audit JSON | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |
| ART-CFF-002 | app_mentions_forensic_audit_v2.md | forensic report | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |
| ART-CFF-003 | app_mentions_exchange_metrics_v2.csv | exchange metrics | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |
| ART-CFF-004 | app_mentions_forensic_dashboard_v2.html | interactive dashboard | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |
| ART-CFF-005 | app_mentions_event_ledger_v2.jsonl | hash-chained event ledger | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |
| ART-CFF-006 | app_mentions_transaction_manifest_v2.json | write/readback manifest | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |
| ART-CFF-007 | CHATBRIDGE-app-mentions-forensics-CURRENT.md | continuity adapter | local output directory | 2026-08-18T20:39:47.718446+00:00 | recorded in transaction manifest | current |

## 9. Open gates and discrepancy log

| Gap ID | Exact gap | Impact | Attempted routes | Next route | Reactivation condition |
|---|---|---|---|---|---|
| GAP-CFF-001 | Exact server-side context usage and hidden prompt overhead are not exposed in the transcript | Blocks causal or completion certainty | Transcript analysis | Obtain native platform evidence | Native evidence becomes available |
| GAP-CFF-002 | Independent successor-chat restore/write/readback has not been executed | Adapter remains local-only | Local capsule generation and hash validation | Run independent successor canary and return bidirectional receipt | Valid successor receipt passes origin readback |

## 10. Next-action queue

1. `ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN`; complete only on native source/telemetry readback.
2. Execute the independent successor-chat restore/write/readback canary; require a bidirectional delta receipt bound to this capsule hash.
3. Re-run CFF and promote state only if every higher-precedence evidence gate passes.

## 11. Recent event window

```yaml
- event_id: "CB-app-mentions-forensics-20260818203947Z-dir-00001"
  observed_at: "2026-08-18T20:39:47.718446+00:00"
  chat_label: "App mentions"
  workstream_id: "WS-CFF-AUDIT"
  instruction: "Recover directive DIR-00001 from native message m1"
  actions: ["classified directive/result state"]
  result: "CLAIMED_COMPLETE_EVIDENCED"
  sources: ["native-message:m1"]
  artifacts: ["ART-CFF-001"]
  truth_labels: ["DERIVED_FROM_TRANSCRIPT"]
  open_gates: ["GAP-CFF-001"]
  next_action: "ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN"
- event_id: "CB-app-mentions-forensics-20260818203947Z-dir-00002"
  observed_at: "2026-08-18T20:39:47.718446+00:00"
  chat_label: "App mentions"
  workstream_id: "WS-CFF-AUDIT"
  instruction: "Recover directive DIR-00002 from native message m3"
  actions: ["classified directive/result state"]
  result: "RESPONDED_UNVERIFIED"
  sources: ["native-message:m3"]
  artifacts: ["ART-CFF-001"]
  truth_labels: ["DERIVED_FROM_TRANSCRIPT"]
  open_gates: ["GAP-CFF-001"]
  next_action: "ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN"
- event_id: "CB-app-mentions-forensics-20260818203947Z-audit"
  observed_at: "2026-08-18T20:39:47.718446+00:00"
  chat_label: "App mentions"
  workstream_id: "WS-CFF-AUDIT"
  instruction: "Generate evidence-bounded conversation audit and continuity adapter"
  actions: ["audited transcript", "generated complete ChatBridge adapter", "validated content hash"]
  result: "PARTIAL_CHECKPOINTED"
  sources: ["cff_v2_validation_fixture.json", "sha256:a1c639a1bb2aa1ce9165a81f5dd28ef2d5cf9fd625957244d1f90b867a8d051c"]
  artifacts: ["ART-CFF-001", "ART-CFF-002", "ART-CFF-003", "ART-CFF-004", "ART-CFF-005", "ART-CFF-006"]
  truth_labels: ["PARTIAL_CHECKPOINTED", "PROOF_BOUNDED"]
  open_gates: ["GAP-CFF-001", "GAP-CFF-002"]
  next_action: "ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN"
```

## 12. Predecessors and archives

- Previous capsule hash: `UNAVAILABLE` (first generated revision for this bounded audit).
- Event archive: `ART-CFF-005`; it is append-only and hash-chained for the recovered source window.
- Transaction/readback archive: `ART-CFF-006`.
- No predecessor is silently imported or treated as reconciled.

## 13. Relationships

- Parent: `conversation-failure-forensics` — universal algorithm, policy, and schema only.
- Child adapters: none registered.
- Related adapters: none registered.
- Boundary: this adapter contains state for `App mentions` only; it must not absorb unrelated conversations or their proof claims.

## 14. Handoff receipt

- Latest recovered checkpoint: audit generated `2026-08-18T20:39:47.718446+00:00` from source SHA-256 `a1c639a1bb2aa1ce9165a81f5dd28ef2d5cf9fd625957244d1f90b867a8d051c`.
- Single next action: `ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN`.
- Adapter proof level: `ACTIVE_LOCAL` / cross-chat `NOT_EXECUTED`.
- Handoff rule: successor must verify `content_sha256`, state the recovered checkpoint and single next action, write a new delta receipt, and expose that receipt for origin readback before promotion.
