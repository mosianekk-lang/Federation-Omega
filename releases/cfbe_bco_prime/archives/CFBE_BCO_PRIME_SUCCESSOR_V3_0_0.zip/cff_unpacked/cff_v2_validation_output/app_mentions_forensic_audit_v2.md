# CFF v2 Black Box Report — App mentions

Owner: **Kagiso Kim Mosiane**  
State: **PARTIAL_CHECKPOINTED**  
Generated: `2026-08-18T20:39:47.718446+00:00`

## Executive result

- Earliest sustained drift: **1**.
- Highest-risk exchange: **2**.
- Terminal limit event: **[3]**.
- SHIELD‑95: **HEALTHY** — `CONTINUE_WITH_MATERIAL_EVENT_CHECKPOINTS`.

> Context and causal metrics are derived proxies unless native platform evidence proves them.

## Ensemble change points

| Signal | Detectors | Consensus |
|---|---|---|
| drift | {'cusum': None, 'page_hinkley': None, 'ewma': None} | no consensus |
| topic_shift | {'cusum': None, 'page_hinkley': None, 'ewma': None} | no consensus |
| capacity | {'cusum': None, 'page_hinkley': None, 'ewma': None} | no consensus |
| trouble | {'cusum': None, 'page_hinkley': None, 'ewma': None} | no consensus |

## Ranked contributions

| Factor | Contribution | Share |
|---|---|---|
| drift | 0.4320 | 49.2% |
| topic_shift | 0.1600 | 18.2% |
| lane_entropy | 0.1500 | 17.1% |
| capacity | 0.0710 | 8.1% |
| status_only | 0.0400 | 4.6% |
| checkpoint_gap | 0.0225 | 2.6% |
| payload | 0.0019 | 0.2% |
| repetition | 0.0000 | 0.0% |
| capability_overclaim | 0.0000 | 0.0% |
| retry | 0.0000 | 0.0% |
| claim_conflict | 0.0000 | 0.0% |
| confidence_without_evidence | 0.0000 | 0.0% |

## Directive graph

| Directive | State | Similarity | Retry |
|---|---|---|---|
| DIR-00001 | CLAIMED_COMPLETE_EVIDENCED | 0.01 | False |
| DIR-00002 | RESPONDED_UNVERIFIED | 0.01 | False |

## Exchange matrix

| Ex | Directive | Tokens | Context | Semantic | Drift | Trouble | SHIELD |
|---|---|---|---|---|---|---|---|
| 1 | DIR-00001 | 28 | 10.7% | 0.01 | 0.80 | 0.22 | HEALTHY |
| 2 | DIR-00002 | 22 | 10.8% | 0.01 | 0.80 | 0.36 | HEALTHY |
| 3 | — | 24 | 10.8% | 0.01 | 0.80 | 0.30 | HEALTHY |
