#!/usr/bin/env python3
"""Conversation Failure Forensics (CFF) v1.0.

Audits a ChatGPT export, JSONL transcript, Markdown, or plain-text transcript.
The program never treats token estimates, memory summaries, or inferred causes as
native platform telemetry. Every finding carries an evidence label.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import statistics
import sys
import zipfile
from collections import Counter, deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional


VERSION = "1.0.0"
STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "can",
    "do", "for", "from", "had", "has", "have", "he", "her", "here", "him",
    "his", "how", "i", "if", "in", "into", "is", "it", "its", "me", "more",
    "my", "no", "not", "of", "on", "or", "our", "so", "that", "the", "their",
    "them", "then", "there", "they", "this", "to", "us", "was", "we", "were",
    "what", "when", "where", "which", "who", "why", "will", "with", "you", "your",
}
DIRECTIVE_RE = re.compile(
    r"^(?:please\s+)?(?:n|proceed|continue|stop|start|create|build|audit|find|search|"
    r"load|restore|capture|process|consolidate|update|improve|do|give|make|ensure|"
    r"check|verify|red-team|assemble)\b",
    re.I,
)
CHECKPOINT_RE = re.compile(
    r"\b(checkpoint|backup|saved|persisted|capsule|chatbridge|bible|handoff|"
    r"continuation|receipt|readback|hash|archive)\b",
    re.I,
)
STATUS_ONLY_RE = re.compile(
    r"\b(i(?:'m| am) (?:working|proceeding|continuing)|next step|still processing|"
    r"will now|status update|queued|pending)\b",
    re.I,
)
LIMIT_RE = re.compile(
    r"\b(maximum (?:conversation|context)|conversation limit|context limit|"
    r"maximum length|too long|start a new chat|message stream error)\b",
    re.I,
)


DEFAULT_CONFIG: dict[str, Any] = {
    "context_window_tokens": 128000,
    "context_window_source": "CONSERVATIVE_FALLBACK_NOT_NATIVE_TELEMETRY",
    "reserved_output_tokens": 16000,
    "hidden_overhead_tokens": 12000,
    "warning_thresholds": [0.50, 0.70, 0.85, 0.95],
    "checkpoint_interval_exchanges": 4,
    "large_message_tokens": 4000,
    "drift_threshold": 0.62,
    "trouble_threshold": 0.58,
    "rolling_anchor_messages": 6,
    "command_aliases": {"n": "continue improve exploit opportunities proceed"},
}


@dataclass
class Message:
    seq: int
    role: str
    text: str
    timestamp: Optional[float] = None
    message_id: Optional[str] = None
    parent_id: Optional[str] = None
    branch: str = "canonical"
    content_type: Optional[str] = None
    model: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def token_estimate(self) -> int:
        return estimate_tokens(self.text)


@dataclass
class ExchangeMetric:
    exchange: int
    user_seq: int
    assistant_seq: Optional[int]
    timestamp: Optional[float]
    user_tokens: int
    assistant_tokens: int
    cumulative_visible_tokens: int
    context_proxy_tokens: int
    context_proxy_ratio: float
    response_similarity: float
    anchor_similarity: float
    repetition: float
    drift_score: float
    trouble_score: float
    directive: bool
    checkpoint: bool
    checkpoint_gap: int
    status_only: bool
    explicit_limit_signal: bool
    evidence_label: str = "DERIVED_FROM_TRANSCRIPT"


def estimate_tokens(text: str) -> int:
    """Conservative tokenizer-free estimate; never presented as native usage."""
    if not text:
        return 0
    byte_est = math.ceil(len(text.encode("utf-8")) / 4)
    word_est = math.ceil(len(re.findall(r"\w+|[^\w\s]", text, re.UNICODE)) * 1.18)
    return max(1, byte_est, word_est)


def terms(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9][a-z0-9_-]{2,}", text.casefold())
    return {w for w in words if w not in STOPWORDS}


def jaccard(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def shingles(text: str, size: int = 5) -> set[tuple[str, ...]]:
    ws = re.findall(r"[a-z0-9]+", text.casefold())
    if len(ws) < size:
        return {tuple(ws)} if ws else set()
    return {tuple(ws[i : i + size]) for i in range(len(ws) - size + 1)}


def text_from_content(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(text_from_content(x) for x in content if x is not None)
    if not isinstance(content, dict):
        return str(content)
    parts = content.get("parts")
    if isinstance(parts, list):
        rendered: list[str] = []
        for part in parts:
            if isinstance(part, str):
                rendered.append(part)
            elif isinstance(part, dict):
                rendered.append(
                    str(part.get("text") or part.get("content") or part.get("name") or "")
                )
        return "\n".join(x for x in rendered if x)
    return str(content.get("text") or content.get("result") or "")


def canonical_nodes(conversation: dict[str, Any]) -> tuple[list[dict[str, Any]], int]:
    mapping = conversation.get("mapping") or {}
    if not isinstance(mapping, dict):
        return [], 0
    current = conversation.get("current_node")
    canonical_ids: list[str] = []
    seen: set[str] = set()
    while current and current in mapping and current not in seen:
        seen.add(current)
        canonical_ids.append(current)
        current = mapping[current].get("parent")
    canonical_ids.reverse()
    nodes = [mapping[x] for x in canonical_ids]
    alternates = max(0, len(mapping) - len(canonical_ids))
    return nodes, alternates


def parse_chatgpt_conversation(conversation: dict[str, Any]) -> tuple[list[Message], dict[str, Any]]:
    nodes, alternates = canonical_nodes(conversation)
    messages: list[Message] = []
    for node in nodes:
        raw = node.get("message")
        if not isinstance(raw, dict):
            continue
        author = raw.get("author") or {}
        role = str(author.get("role") or "unknown")
        content = raw.get("content") or {}
        text = text_from_content(content)
        if not text.strip() and role not in {"tool", "system"}:
            continue
        meta = raw.get("metadata") or {}
        messages.append(
            Message(
                seq=len(messages) + 1,
                role=role,
                text=text,
                timestamp=raw.get("create_time"),
                message_id=raw.get("id") or node.get("id"),
                parent_id=node.get("parent"),
                content_type=content.get("content_type") if isinstance(content, dict) else None,
                model=meta.get("model_slug") or meta.get("default_model_slug"),
                metadata={
                    "recipient": raw.get("recipient"),
                    "status": raw.get("status"),
                    "end_turn": raw.get("end_turn"),
                },
            )
        )
    return messages, {
        "title": conversation.get("title"),
        "conversation_id": conversation.get("id") or conversation.get("conversation_id"),
        "create_time": conversation.get("create_time"),
        "update_time": conversation.get("update_time"),
        "alternate_or_orphan_nodes": alternates,
        "mapping_nodes": len(conversation.get("mapping") or {}),
    }


def find_conversations_json(payload: Any, title: str) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    if isinstance(payload, list):
        candidates = [x for x in payload if isinstance(x, dict)]
    elif isinstance(payload, dict):
        if "mapping" in payload:
            candidates = [payload]
        else:
            for key in ("conversations", "items", "data"):
                if isinstance(payload.get(key), list):
                    candidates.extend(x for x in payload[key] if isinstance(x, dict))
    exact = [c for c in candidates if str(c.get("title", "")).casefold() == title.casefold()]
    return exact


def parse_jsonl(text: str, title: str) -> tuple[list[Message], dict[str, Any]]:
    messages: list[Message] = []
    seen_titles: set[str] = set()
    for line in text.splitlines():
        if not line.strip():
            continue
        obj = json.loads(line)
        obj_title = str(obj.get("title") or obj.get("conversation_title") or title)
        seen_titles.add(obj_title)
        if obj_title.casefold() != title.casefold():
            continue
        raw_ts = obj.get("timestamp") or obj.get("create_time")
        messages.append(
            Message(
                seq=len(messages) + 1,
                role=str(obj.get("role") or obj.get("author") or "unknown"),
                text=text_from_content(obj.get("text") or obj.get("content")),
                timestamp=float(raw_ts) if isinstance(raw_ts, (int, float)) else None,
                message_id=obj.get("id") or obj.get("message_id"),
                model=obj.get("model"),
                metadata={"source": "jsonl"},
            )
        )
    return messages, {"title": title, "seen_titles": sorted(seen_titles), "source_format": "jsonl"}


ROLE_MARKER_RE = re.compile(
    r"(?im)^(?:#{1,6}\s*)?(user|assistant|system|tool)(?:\s+messages?)?\s*[:\-]\s*"
)


def parse_text_transcript(text: str, title: str) -> tuple[list[Message], dict[str, Any]]:
    matches = list(ROLE_MARKER_RE.finditer(text))
    messages: list[Message] = []
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[match.end() : end].strip()
        messages.append(Message(seq=len(messages) + 1, role=match.group(1).lower(), text=body))
    if not messages and text.strip():
        messages = [Message(seq=1, role="unknown", text=text.strip())]
    return messages, {
        "title": title,
        "source_format": "markdown_or_text",
        "structured_role_markers": len(matches),
    }


def load_source(path: Path, title: str) -> tuple[list[Message], dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(path)
    source_sha = hashlib.sha256(path.read_bytes()).hexdigest()
    metadata: dict[str, Any] = {"source_path": str(path), "source_sha256": source_sha}
    if path.suffix.casefold() == ".zip":
        matches: list[tuple[list[Message], dict[str, Any], str]] = []
        with zipfile.ZipFile(path) as zf:
            json_names = [n for n in zf.namelist() if re.search(r"conversations(?:-\d+)?\.json$", n)]
            for name in json_names:
                payload = json.loads(zf.read(name).decode("utf-8"))
                for conv in find_conversations_json(payload, title):
                    msgs, meta = parse_chatgpt_conversation(conv)
                    matches.append((msgs, meta, name))
        if len(matches) != 1:
            raise ValueError(f"Expected one exact chat titled {title!r}; found {len(matches)} in ZIP")
        messages, parsed, member = matches[0]
        metadata.update(parsed)
        metadata["zip_member"] = member
        metadata["source_format"] = "chatgpt_export_zip"
        return messages, metadata
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    if path.suffix.casefold() == ".jsonl":
        messages, parsed = parse_jsonl(text, title)
    elif path.suffix.casefold() == ".json":
        payload = json.loads(text)
        conversations = find_conversations_json(payload, title)
        if len(conversations) != 1:
            raise ValueError(f"Expected one exact chat titled {title!r}; found {len(conversations)}")
        messages, parsed = parse_chatgpt_conversation(conversations[0])
        parsed["source_format"] = "chatgpt_export_json"
    else:
        messages, parsed = parse_text_transcript(text, title)
    metadata.update(parsed)
    return messages, metadata


def merge_config(path: Optional[Path]) -> dict[str, Any]:
    config = json.loads(json.dumps(DEFAULT_CONFIG))
    if path:
        supplied = json.loads(path.read_text(encoding="utf-8"))
        config.update(supplied)
    return config


def pair_exchanges(messages: list[Message]) -> list[tuple[Message, Optional[Message], list[Message]]]:
    result: list[tuple[Message, Optional[Message], list[Message]]] = []
    i = 0
    while i < len(messages):
        if messages[i].role != "user":
            i += 1
            continue
        user = messages[i]
        between: list[Message] = []
        assistant: Optional[Message] = None
        j = i + 1
        while j < len(messages) and messages[j].role != "user":
            if messages[j].role == "assistant" and assistant is None:
                assistant = messages[j]
            else:
                between.append(messages[j])
            j += 1
        result.append((user, assistant, between))
        i = j
    return result


def robust_change_point(values: list[float]) -> Optional[int]:
    """One-sided robust CUSUM; returns a 1-based exchange index."""
    if len(values) < 8:
        return None
    baseline_n = max(4, len(values) // 5)
    baseline = values[:baseline_n]
    median = statistics.median(baseline)
    deviations = [abs(v - median) for v in baseline]
    mad = statistics.median(deviations) or 0.05
    allowance = 0.5 * mad
    threshold = 5.0 * mad
    cumulative = 0.0
    for idx, value in enumerate(values[baseline_n:], start=baseline_n + 1):
        cumulative = max(0.0, cumulative + value - median - allowance)
        if cumulative > threshold:
            return idx
    return None


def analyze(messages: list[Message], metadata: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    exchanges = pair_exchanges(messages)
    if not exchanges:
        raise ValueError("No user messages were found; the transcript structure is insufficient")
    total_visible = 0
    last_checkpoint_exchange = 0
    prior_assistant_shingles: deque[set[tuple[str, ...]]] = deque(maxlen=12)
    anchor_terms: deque[set[str]] = deque(maxlen=int(config["rolling_anchor_messages"]))
    metrics: list[ExchangeMetric] = []
    context_limit = int(config["context_window_tokens"])
    usable_context = max(1, context_limit - int(config["reserved_output_tokens"]))
    aliases = {str(k).casefold(): str(v) for k, v in config.get("command_aliases", {}).items()}

    for ex_idx, (user, assistant, between) in enumerate(exchanges, start=1):
        expanded_user = aliases.get(user.text.strip().casefold(), user.text)
        user_terms = terms(expanded_user)
        directive = bool(DIRECTIVE_RE.search(user.text.strip()))
        if directive or len(user_terms) >= 4:
            anchor_terms.append(user_terms)
        active_anchor = set().union(*anchor_terms) if anchor_terms else user_terms
        assistant_text = assistant.text if assistant else ""
        assistant_terms = terms(assistant_text)
        response_similarity = jaccard(user_terms, assistant_terms)
        anchor_similarity = jaccard(active_anchor, assistant_terms)
        assistant_sh = shingles(assistant_text)
        repetition = max((jaccard(assistant_sh, old) for old in prior_assistant_shingles), default=0.0)
        if assistant_sh:
            prior_assistant_shingles.append(assistant_sh)
        exchange_messages = [user] + ([assistant] if assistant else []) + between
        exchange_tokens = sum(m.token_estimate for m in exchange_messages if m)
        total_visible += exchange_tokens
        checkpoint = any(CHECKPOINT_RE.search(m.text) for m in exchange_messages if m)
        if checkpoint:
            last_checkpoint_exchange = ex_idx
        checkpoint_gap = ex_idx - last_checkpoint_exchange
        status_only = bool(assistant and STATUS_ONLY_RE.search(assistant_text) and len(assistant_terms) < 45)
        explicit_limit = any(LIMIT_RE.search(m.text) for m in exchange_messages if m)
        response_gap = 1.0 - min(1.0, response_similarity * 4.0)
        anchor_gap = 1.0 - min(1.0, anchor_similarity * 3.0)
        missing_response = 1.0 if assistant is None else 0.0
        drift_score = min(1.0, 0.46 * response_gap + 0.34 * anchor_gap + 0.12 * repetition + 0.08 * missing_response)
        context_proxy = total_visible + int(config["hidden_overhead_tokens"])
        context_ratio = context_proxy / usable_context
        payload_pressure = min(1.0, exchange_tokens / max(1, int(config["large_message_tokens"])))
        checkpoint_pressure = min(1.0, checkpoint_gap / max(1, int(config["checkpoint_interval_exchanges"])))
        trouble = min(
            1.0,
            0.27 * min(1.0, context_ratio)
            + 0.22 * drift_score
            + 0.18 * repetition
            + 0.14 * payload_pressure
            + 0.11 * checkpoint_pressure
            + 0.08 * (1.0 if status_only else 0.0),
        )
        metrics.append(
            ExchangeMetric(
                exchange=ex_idx,
                user_seq=user.seq,
                assistant_seq=assistant.seq if assistant else None,
                timestamp=user.timestamp,
                user_tokens=user.token_estimate,
                assistant_tokens=assistant.token_estimate if assistant else 0,
                cumulative_visible_tokens=total_visible,
                context_proxy_tokens=context_proxy,
                context_proxy_ratio=round(context_ratio, 5),
                response_similarity=round(response_similarity, 5),
                anchor_similarity=round(anchor_similarity, 5),
                repetition=round(repetition, 5),
                drift_score=round(drift_score, 5),
                trouble_score=round(trouble, 5),
                directive=directive,
                checkpoint=checkpoint,
                checkpoint_gap=checkpoint_gap,
                status_only=status_only,
                explicit_limit_signal=explicit_limit,
            )
        )

    earliest_drift: Optional[int] = None
    threshold = float(config["drift_threshold"])
    for i in range(len(metrics) - 1):
        if metrics[i].drift_score >= threshold and metrics[i + 1].drift_score >= threshold:
            earliest_drift = metrics[i].exchange
            break
    trouble_idx = next(
        (m.exchange for m in metrics if m.trouble_score >= float(config["trouble_threshold"])),
        None,
    )
    context_change = robust_change_point([m.context_proxy_ratio for m in metrics])
    drift_change = robust_change_point([m.drift_score for m in metrics])
    max_context = max(metrics, key=lambda x: x.context_proxy_ratio)
    max_trouble = max(metrics, key=lambda x: x.trouble_score)
    warnings = []
    for t in config["warning_thresholds"]:
        reached = next((m for m in metrics if m.context_proxy_ratio >= float(t)), None)
        warnings.append({
            "threshold": t,
            "first_exchange": reached.exchange if reached else None,
            "label": "ESTIMATED_PROXY_NOT_NATIVE_TELEMETRY",
        })
    token_growth = [m.user_tokens + m.assistant_tokens for m in metrics[-min(10, len(metrics)):]]
    median_growth = int(statistics.median(token_growth)) if token_growth else 0
    remaining = max(0, usable_context - max_context.context_proxy_tokens)
    forecast_turns = (remaining // median_growth) if median_growth else None

    roles = Counter(m.role for m in messages)
    explicit_limit_events = [m.exchange for m in metrics if m.explicit_limit_signal]
    source_completeness = {
        "message_count": len(messages),
        "exchange_count": len(exchanges),
        "roles": dict(roles),
        "messages_with_ids": sum(bool(m.message_id) for m in messages),
        "messages_with_timestamps": sum(m.timestamp is not None for m in messages),
        "alternate_or_orphan_nodes": metadata.get("alternate_or_orphan_nodes", 0),
        "native_token_telemetry_present": False,
        "terminal_limit_event_present": bool(explicit_limit_events),
    }
    gaps: list[dict[str, str]] = []
    if source_completeness["messages_with_ids"] < len(messages):
        gaps.append({"gap": "Some or all native message IDs are absent", "label": "UNVERIFIED"})
    if source_completeness["messages_with_timestamps"] < len(messages):
        gaps.append({"gap": "Some or all native timestamps are absent", "label": "UNVERIFIED"})
    gaps.append({"gap": "Exact server-side context usage and hidden prompt overhead are not exposed in the transcript", "label": "UNVERIFIED"})
    if not explicit_limit_events:
        gaps.append({"gap": "The terminal conversation-limit event is not present in the supplied source", "label": "UNVERIFIED"})

    factors = [
        ("visible transcript growth", max_context.context_proxy_ratio),
        ("response/task drift", statistics.mean(m.drift_score for m in metrics)),
        ("repeated assistant material", statistics.mean(m.repetition for m in metrics)),
        ("large turn payloads", sum((m.user_tokens + m.assistant_tokens) >= int(config["large_message_tokens"]) for m in metrics) / len(metrics)),
        ("checkpoint latency", statistics.mean(min(1.0, m.checkpoint_gap / max(1, int(config["checkpoint_interval_exchanges"]))) for m in metrics)),
        ("status-without-progress turns", sum(m.status_only for m in metrics) / len(metrics)),
    ]
    ranked_factors = [
        {"factor": name, "score": round(float(score), 5), "label": "DERIVED_FROM_TRANSCRIPT"}
        for name, score in sorted(factors, key=lambda x: x[1], reverse=True)
    ]

    return {
        "audit": {
            "algorithm": "Conversation Failure Forensics",
            "version": VERSION,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "target_title": metadata.get("title"),
            "source": metadata,
            "configuration": config,
            "truth_boundary": "Token use, limit proximity, and causes are estimates unless native telemetry or an explicit limit event is present.",
        },
        "source_completeness": source_completeness,
        "evidence_gaps": gaps,
        "change_points": {
            "earliest_sustained_drift_exchange": earliest_drift,
            "first_trouble_threshold_exchange": trouble_idx,
            "robust_context_growth_change_exchange": context_change,
            "robust_drift_change_exchange": drift_change,
            "highest_trouble_exchange": max_trouble.exchange,
            "explicit_limit_signal_exchanges": explicit_limit_events,
        },
        "capacity_proxy": {
            "usable_context_proxy_tokens": usable_context,
            "final_context_proxy_tokens": max_context.context_proxy_tokens,
            "final_context_proxy_ratio": round(max_context.context_proxy_ratio, 5),
            "median_recent_tokens_per_exchange": median_growth,
            "forecast_exchanges_remaining_at_recent_growth": forecast_turns,
            "threshold_crossings": warnings,
            "label": "ESTIMATED_PROXY_NOT_NATIVE_TELEMETRY",
        },
        "ranked_contributing_factors": ranked_factors,
        "metrics": [asdict(m) for m in metrics],
    }


def md_table(rows: Iterable[list[Any]], headers: list[str]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        out.append("| " + " | ".join(str(x) for x in row) + " |")
    return "\n".join(out)


def render_markdown(report: dict[str, Any]) -> str:
    audit = report["audit"]
    cp = report["change_points"]
    cap = report["capacity_proxy"]
    lines = [
        f"# Conversation Failure Forensics — {audit['target_title']}",
        "",
        f"Generated: `{audit['generated_at']}`  ",
        f"Algorithm: `{audit['algorithm']} v{audit['version']}`",
        "",
        "## Executive result",
        "",
        f"- Earliest sustained drift: **{cp['earliest_sustained_drift_exchange'] or 'NOT ESTABLISHED'}**.",
        f"- First composite trouble threshold: **{cp['first_trouble_threshold_exchange'] or 'NOT ESTABLISHED'}**.",
        f"- Highest-risk exchange: **{cp['highest_trouble_exchange']}**.",
        f"- Explicit terminal limit signal: **{cp['explicit_limit_signal_exchanges'] or 'NOT PRESENT IN SOURCE'}**.",
        f"- Final context proxy: **{cap['final_context_proxy_tokens']:,} / {cap['usable_context_proxy_tokens']:,} ({cap['final_context_proxy_ratio']:.1%})**.",
        "",
        "> Context use is a conservative proxy, not native ChatGPT telemetry. Missing source evidence remains UNVERIFIED.",
        "",
        "## Threshold timeline",
        "",
        md_table(
            [[f"{x['threshold']:.0%}", x['first_exchange'] or "not reached", x['label']] for x in cap["threshold_crossings"]],
            ["Proxy threshold", "First exchange", "Evidence label"],
        ),
        "",
        "## Ranked contributing factors",
        "",
        md_table(
            [[x["factor"], f"{x['score']:.3f}", x["label"]] for x in report["ranked_contributing_factors"]],
            ["Factor", "Score", "Evidence label"],
        ),
        "",
        "## Evidence gaps",
        "",
    ]
    for gap in report["evidence_gaps"]:
        lines.append(f"- **{gap['label']}** — {gap['gap']}.")
    lines += [
        "",
        "## Why ChatBridge could miss the failure",
        "",
        "The audit tests whether continuity was checkpointed as a transaction or merely summarized. A ChatBridge capsule cannot observe hidden server context usage, cannot guarantee access to another chat's complete native transcript, and cannot warn reliably without a per-turn risk meter plus a pre-limit checkpoint trigger. Memory and recovered summaries are retrieval aids, not a verbatim event log.",
        "",
        "## Exchange metrics",
        "",
        md_table(
            [[m["exchange"], m["user_tokens"] + m["assistant_tokens"], f"{m['context_proxy_ratio']:.1%}", f"{m['drift_score']:.2f}", f"{m['repetition']:.2f}", f"{m['trouble_score']:.2f}", "yes" if m["checkpoint"] else "no"] for m in report["metrics"]],
            ["Ex", "Tokens", "Context proxy", "Drift", "Repeat", "Trouble", "Checkpoint"],
        ),
        "",
        "## Required control changes",
        "",
        "1. Capture immutable per-message events with message ID, timestamp, role, content hash, attachment pointers, and branch identity.",
        "2. Compute the risk meter after every exchange; checkpoint at 50%, split work at 70%, freeze new scope at 85%, and hand off at 95% of the configured usable-context proxy.",
        "3. Checkpoint every material correction, decision, artifact, blocker, and status transition—not only every seventh output.",
        "4. Keep bulky evidence and tool payloads outside the chat; retain hashes, counts, ranges, and source pointers in the capsule.",
        "5. Require readback of the continuation capsule and a fresh-chat canary before claiming cross-chat continuity.",
        "6. Emit a discrepancy when the native transcript, terminal error, exact model, or context limit is absent; never infer completeness from memory.",
        "",
    ]
    return "\n".join(lines)


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Audit a ChatGPT conversation for drift and context-limit risk")
    parser.add_argument("source", type=Path, help="ChatGPT export ZIP/JSON, JSONL, Markdown, or text")
    parser.add_argument("--title", default="App mentions", help="Exact conversation title")
    parser.add_argument("--config", type=Path, help="Optional JSON configuration")
    parser.add_argument("--output-dir", type=Path, default=Path("audit-output"))
    args = parser.parse_args(argv)
    try:
        config = merge_config(args.config)
        messages, metadata = load_source(args.source, args.title)
        report = analyze(messages, metadata, config)
        args.output_dir.mkdir(parents=True, exist_ok=True)
        json_path = args.output_dir / "app_mentions_forensic_audit.json"
        md_path = args.output_dir / "app_mentions_forensic_audit.md"
        json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        md_path.write_text(render_markdown(report), encoding="utf-8")
        print(json.dumps({"status": "AUDIT_COMPLETE", "json": str(json_path), "markdown": str(md_path)}))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "AUDIT_BLOCKED", "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
