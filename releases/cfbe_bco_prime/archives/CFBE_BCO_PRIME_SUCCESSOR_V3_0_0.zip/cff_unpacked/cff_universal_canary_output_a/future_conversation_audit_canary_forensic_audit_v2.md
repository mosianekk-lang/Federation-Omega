# CFF v2 Black Box Report — Future Conversation Audit Canary

Owner: **Kagiso Kim Mosiane**  
State: **PARTIAL_CHECKPOINTED**  
Generated: `2026-08-18T20:33:55.019069+00:00`

## Executive result

- Earliest sustained drift: **NOT ESTABLISHED**.
- Highest-risk exchange: **3**.
- Terminal limit event: **[8]**.
- SHIELD‑95: **HEALTHY** — `CONTINUE_WITH_MATERIAL_EVENT_CHECKPOINTS`.

> Context and causal metrics are derived proxies unless native platform evidence proves them.

## Ensemble change points

| Signal | Detectors | Consensus |
|---|---|---|
| drift | {'cusum': None, 'page_hinkley': 6, 'ewma': None} | no consensus |
| topic_shift | {'cusum': None, 'page_hinkley': 6, 'ewma': None} | no consensus |
| capacity | {'cusum': 6, 'page_hinkley': None, 'ewma': 8} | 6 |
| trouble | {'cusum': None, 'page_hinkley': None, 'ewma': None} | no consensus |

## Ranked contributions

| Factor | Contribution | Share |
|---|---|---|
| drift | 0.6258 | 31.8% |
| topic_shift | 0.5326 | 27.0% |
| lane_entropy | 0.3985 | 20.2% |
| capacity | 0.1908 | 9.7% |
| checkpoint_gap | 0.1350 | 6.9% |
| status_only | 0.0800 | 4.1% |
| payload | 0.0062 | 0.3% |
| repetition | 0.0000 | 0.0% |
| capability_overclaim | 0.0000 | 0.0% |
| retry | 0.0000 | 0.0% |
| claim_conflict | 0.0000 | 0.0% |
| confidence_without_evidence | 0.0000 | 0.0% |

## Directive graph

| Directive | State | Similarity | Retry |
|---|---|---|---|
| DIR-00001 | CLAIMED_COMPLETE_EVIDENCED | 0.27 | False |
| DIR-00002 | RESPONDED_UNVERIFIED | 0.20 | False |
| DIR-00003 | RESPONDED_UNVERIFIED | 0.16 | False |
| DIR-00004 | CLAIMED_COMPLETE_EVIDENCED | 0.10 | False |
| DIR-00005 | RESPONDED_UNVERIFIED | 0.18 | False |

## Exchange matrix

| Ex | Directive | Tokens | Context | Semantic | Drift | Trouble | SHIELD |
|---|---|---|---|---|---|---|---|
| 1 | DIR-00001 | 35 | 10.7% | 0.27 | 0.06 | 0.09 | HEALTHY |
| 2 | DIR-00002 | 33 | 10.8% | 0.20 | 0.35 | 0.27 | HEALTHY |
| 3 | DIR-00003 | 23 | 10.8% | 0.16 | 0.49 | 0.33 | HEALTHY |
| 4 | DIR-00004 | 29 | 10.8% | 0.10 | 0.61 | 0.26 | HEALTHY |
| 5 | — | 33 | 10.9% | 0.09 | 0.62 | 0.29 | HEALTHY |
| 6 | DIR-00005 | 34 | 10.9% | 0.18 | 0.42 | 0.27 | HEALTHY |
| 7 | — | 31 | 10.9% | 0.20 | 0.36 | 0.21 | HEALTHY |
| 8 | — | 31 | 10.9% | 0.11 | 0.58 | 0.26 | HEALTHY |
