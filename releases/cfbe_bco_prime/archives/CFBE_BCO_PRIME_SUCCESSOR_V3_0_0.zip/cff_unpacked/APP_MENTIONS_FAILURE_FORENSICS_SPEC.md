# Conversation Failure Forensics (CFF) v2.0 — Black Box / Flight Recorder

Owner: **Kagiso Kim Mosiane**  
Universal scope: **any current or future conversation requiring forensic audit**  
First bounded deployment: **“App mentions”**  
Purpose: reconstruct an audited conversation from its first native message to its terminal state; identify the first trouble point, sustained drift, context-growth contributors, missed warnings, ChatBridge blind spots, causal contributions, branch divergence, directive failures and the controls needed to prevent recurrence. “App mentions” is a deployment and validation target, not the definition or limit of CFF.

## v2 upgrade contract

CFF v2 preserves the v1 source hierarchy and adds:

- complete canonical and alternate-branch mapping with divergence indices and path hashes;
- local model-profile tokenization when available, with a conservative fallback;
- TF-IDF and character-ngram semantic similarity;
- rolling topic divergence and task-lane entropy;
- a three-detector change-point ensemble: robust CUSUM, Page–Hinkley and EWMA;
- directive-to-response-to-result graphs with retry and checkpoint state;
- capability-overclaim, confidence-without-evidence and conflicting-guidance signatures;
- linear counterfactual factor attribution with explicit evidence labels;
- SHIELD‑95 checkpoint, handoff, scope-freeze and terminal-guard actions;
- an immutable SHA-256 event chain;
- JSON, Markdown, CSV, HTML dashboard, event-ledger, transaction-manifest and continuation-capsule outputs;
- strict `COMPLETE_VERIFIED`, `PARTIAL_CHECKPOINTED` and `AUDIT_BLOCKED` completion states.

The advanced signatures are detectors, not verdicts. Potential contradictions and inferred causes require human review and native-source confirmation.

## 1. Non-negotiable truth boundary

The native transcript/export is the controlling source for message sequence and content. Memory, summaries, screenshots, ChatBridge capsules, and downstream artifacts are secondary recovery sources. They may fill an explicitly marked gap but may never be represented as the complete transcript.

The exact server-side context occupation, hidden system instructions, internal compaction, routing decisions, and conversation-limit trigger are not normally present in an exported transcript. The algorithm therefore labels token and limit proximity as `ESTIMATED_PROXY_NOT_NATIVE_TELEMETRY`. It labels a cause as `VERIFIED` only when the relevant native event, metadata, platform notice, or direct readback is present.

## 2. Inputs

The engine accepts:

- an official ChatGPT data-export ZIP;
- `conversations.json` or numbered conversation JSON exports;
- a JSONL message ledger;
- a copied Markdown or plain-text transcript.

The exact title defaults to `App mentions` for backward compatibility. Any exact chat title may be supplied. Output names are derived from a sanitized title or explicit collision-safe prefix. Duplicate exact-title matches fail closed until the target conversation identity is resolved.

## 3. Evidence ladder

1. Native conversation export with message IDs, timestamps, branch graph, attachments, and terminal error.
2. Complete copied transcript with stable message boundaries.
3. Source artifacts created during the chat, with hashes and timestamps.
4. Contemporaneous ChatBridge checkpoint or Bible event.
5. Screenshots and user-supplied records.
6. Personal-context or memory retrieval.
7. Analytical inference or hypothesis.

Every finding carries one of: `VERIFIED`, `SOURCE_SUPPORTED`, `DERIVED_FROM_TRANSCRIPT`, `INFERENCE`, or `UNVERIFIED`.

## 4. Pipeline

```mermaid
flowchart TD
    A["Native export or transcript"] --> B["Immutable message events"]
    B --> C["Branch and source validation"]
    C --> D["Model-aware token proxy"]
    C --> E["Directive and semantic drift graph"]
    C --> F["Branch, tool and artifact lineage"]
    D --> G["Ensemble change points"]
    E --> G
    F --> G
    G --> H["Failure timeline"]
    H --> I["Root-cause ranking"]
    I --> J["SHIELD-95 gates and verified handoff"]
```

## 5. Metrics

| Metric | Method | Meaning | Limitation |
|---|---|---|---|
| Visible-token estimate | UTF-8 length and lexical estimate | Approximate transcript growth | Not native tokenizer usage |
| Context proxy | Visible tokens + configured hidden-overhead reserve | Conservative risk denominator | Hidden context is not observable |
| Response similarity | Lexical set overlap | Whether an answer remains tied to the directive | Semantic paraphrases may score low |
| Anchor similarity | Answer overlap with rolling task anchors | Cross-turn mission fidelity | Requires correctly maintained anchors |
| Repetition | Five-word shingle overlap | Duplicated assistant content and restatement load | Legitimate repeated legal language may score high |
| Drift score | Response gap + anchor gap + repetition + missing response | Per-exchange drift risk | Analytical, not factual proof |
| Checkpoint gap | Exchanges since a checkpoint marker | Exposure to unrecoverable work | A marker alone does not prove durable write/readback |
| Payload pressure | Turn tokens relative to safe payload threshold | Large-context injection risk | Attachments may be handled outside text context |
| Trouble score | Weighted composite | Earliest sustained operational strain | Threshold must be calibrated on real transcripts |
| Change point | Robust CUSUM | Where normal behavior materially shifts | Needs enough early baseline exchanges |
| Time-to-limit forecast | Remaining proxy / recent median growth | Approximate exchanges remaining | Invalid if the platform compacts context differently |

Additional forensic analyses supported by the event model include task-lane entropy, unresolved-directive aging, assistant/user token ratio, artifact production per 1,000 tokens, no-progress streaks, retry storms, tool-payload concentration, branch divergence, checkpoint coverage, and time between directive and verified result.

## 6. Failure phases

- `HEALTHY`: low drift, bounded turns, fresh checkpoint.
- `EARLY_STRAIN`: first statistically material change in drift, repetition, payload size, or checkpoint delay.
- `SUSTAINED_DRIFT`: two or more consecutive exchanges above the drift threshold.
- `CAPACITY_RISK`: context proxy passes 50%.
- `HANDOFF_REQUIRED`: proxy passes 70% or unresolved work exceeds checkpoint capacity.
- `SCOPE_FREEZE`: proxy passes 85%; no new lane may be added to that chat.
- `TERMINAL_GUARD`: proxy passes 95%; current chat becomes read-only except for the final verified handoff.
- `TERMINAL_EVENT`: native limit/error event is observed.

## 7. Why the earlier ChatBridge approach could not see the failure

The available evidence presently establishes that there is no canonical `App mentions` ChatBridge capsule and no complete native transcript in the continuity register. It does **not** yet establish the exact first drift turn or the exact server-side cause of the terminal limit.

The structural failure modes the audit tests are:

1. **No native transcript hook.** ChatBridge recovered summaries and artifacts but did not receive every message event from the other chat.
2. **No native context telemetry.** A capsule cannot see hidden prompts, tool definitions, system overhead, compaction, or the actual server limit counter.
3. **Checkpoint cadence was output-count based.** A seventh-output backup can arrive too late after one very large turn, repeated corpus output, or a tool payload.
4. **Checkpoint did not equal verified handoff.** A mention of “saved,” “Bible,” or “ChatBridge” is not proof that a durable capsule was written, read back, and successfully resumed in another chat.
5. **The workstream expanded across lanes.** Folder consolidation became corpus processing and preparation-bundle work; repeated deep dives, consolidations, source retrieval, and status narration could increase both visible context and unresolved state.
6. **No hard pre-limit state machine.** Without 50/70/85/95% gates, scope freeze, and a forced handoff, the system remained reactive.
7. **Memory was treated too optimistically.** Official product memory is a continually updated synthesis, not a complete verbatim event ledger; a summary can omit details that later become crucial.

Items 1–7 are architecture-level explanations or current-source observations. The full transcript audit must determine which occurred, when, and with what measured contribution.

## 8. Prevention algorithm: SHIELD-95

After every exchange:

1. Append an immutable event envelope: conversation ID, message ID, parent ID, role, timestamp, model label, content hash, attachment pointers, token estimate, directive IDs, workstream IDs, and truth label.
2. Recompute drift, duplication, checkpoint gap, payload pressure, unresolved-directive age, and context proxy.
3. At 50%, create and read back a current capsule.
4. At 70%, split large evidence lanes into source-indexed artifacts and create a new continuation chat.
5. At 85%, reject new scope in the old chat; allow only completion of the current atomic unit and handoff preparation.
6. At 95%, freeze the old chat and publish a verified continuation package containing: mission, directives, completed work, artifacts, hashes, unresolved items, exact next action, and discrepancy log.
7. Require a fresh-chat resume canary that reads the capsule, states the correct next action, performs one bounded task, writes a delta, and is read back from the origin or control node.
8. If the terminal event arrives before handoff, reconstruct from the last verified immutable event, not from memory.

## 9. Execution

```bash
python3 conversation_forensic_audit.py conversations.json \
  --title "Exact conversation title" \
  --config conversation_audit_config.json \
  --output-dir conversation-audit-output
```

The legacy `app_mentions_forensic_audit.py` launcher and `app_mentions_*` filenames remain valid for the first deployment and rollback lineage.

Outputs:

- `app_mentions_forensic_audit_v2.json` — machine-readable metrics and evidence labels.
- `app_mentions_forensic_audit_v2.md` — human-readable forensic report.
- `app_mentions_exchange_metrics_v2.csv` — exchange-level analytical matrix.
- `app_mentions_forensic_dashboard_v2.html` — responsive executive forensic dashboard with evidence boundary, source-integrity posture, risk trajectory, explicit-limit markers, exchange inspection, and ranked causal contribution bars. It supports light/dark presentation and keyboard-operable exchange selection without changing analytical evidence.
- `app_mentions_event_ledger_v2.jsonl` — immutable hash-chained event envelopes.
- `app_mentions_transaction_manifest_v2.json` — proof-gated publication transaction.
- `CHATBRIDGE-app-mentions-forensics-CURRENT.md` — bounded continuation capsule.

## 10. Completion gate

Any conversation audit may be called complete only when:

- the exact native conversation is uniquely identified;
- all canonical-branch messages are captured and hashed;
- alternate branches and missing nodes are reported;
- the terminal limit/error event is either source-proven or explicitly `UNVERIFIED`;
- the earliest trouble/drift findings are reproducible from the event ledger;
- every cause is evidence-labeled;
- a continuation capsule is created and read back;
- a new-chat recovery canary succeeds.

Until those gates pass, the current status is **CFF v2 BUILT AND TESTED; APP-MENTIONS ROOT-CAUSE AUDIT PENDING NATIVE TRANSCRIPT**.
