#!/usr/bin/env python3
"""CFF v2 — Black Box / Flight Recorder.

Adds full branch forensics, semantic/topic analysis, three-detector change-point
ensembles, directive/result graphs, claim-conflict and capability-overclaim
signatures, linear counterfactual attribution, SHIELD-95 actions, an immutable
hash-chained event ledger, a transaction manifest, and a continuation capsule.

Native transcript evidence controls. Context occupation and causal contribution
remain derived proxies unless native platform telemetry proves them.
Copyright 2026 Kagiso Kim Mosiane.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import re
import statistics
import sys
import zipfile
from collections import Counter, defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Optional

from restored_v1 import app_mentions_forensic_audit as core

VERSION = "2.0.0"
OWNER = "Kagiso Kim Mosiane"
CAPABILITY_RE = re.compile(
    r"\b(permanent(?:ly)?|all chats|every chat|full access|no (?:length|context) limit|"
    r"automatically (?:capture|transcribe|integrate|install|monitor)|in real time|"
    r"weaponised evidence|100%|guaranteed|cannot fail|always active)\b", re.I)
EVIDENCE_RE = re.compile(
    r"\b(verified|readback|source|citation|receipt|hash|timestamp|test(?:ed|s)?|"
    r"evidence|proof|artifact|resultjson)\b", re.I)
COMPLETE_RE = re.compile(r"\b(done|complete(?:d)?|finished|created|saved|verified|delivered|published)\b", re.I)
FILE_RE = re.compile(r"\b[\w .()\[\]-]+\.(?:pdf|docx?|xlsx?|csv|jsonl?|md|txt|zip|eml|pptx?)\b", re.I)
URL_RE = re.compile(r"https?://[^\s)>\]]+", re.I)
HASH_RE = re.compile(r"\b[a-f0-9]{64}\b", re.I)

WEIGHTS = {
    "capacity": .22, "drift": .18, "repetition": .10, "payload": .10,
    "checkpoint_gap": .09, "topic_shift": .08, "lane_entropy": .05,
    "status_only": .04, "capability_overclaim": .05, "retry": .03,
    "claim_conflict": .04, "confidence_without_evidence": .02,
}


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def safe_prefix(value: str) -> str:
    """Return a collision-safe filesystem prefix without changing audit identity."""
    prefix=re.sub(r"[^a-z0-9]+","_",value.casefold()).strip("_")
    return prefix[:72] or "conversation"


def tokens(text: str, model: Optional[str] = None) -> tuple[int, str]:
    try:
        import tiktoken  # type: ignore
        try:
            enc = tiktoken.encoding_for_model(model) if model else tiktoken.get_encoding("o200k_base")
        except Exception:
            enc = tiktoken.get_encoding("o200k_base")
        return len(enc.encode(text)), "TIKTOKEN_LOCAL_PROFILE"
    except Exception:
        return core.estimate_tokens(text), "CONSERVATIVE_HEURISTIC"


def words(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9][a-z0-9_-]{2,}", text.casefold()) if w not in core.STOPWORDS]


def tfidf(docs: list[str]) -> list[dict[str, float]]:
    bags = [Counter(words(x)) for x in docs]
    df = Counter(w for bag in bags for w in bag)
    n = max(1, len(bags)); out = []
    for bag in bags:
        length = sum(bag.values()) or 1
        out.append({w: (c / length) * (math.log((1 + n) / (1 + df[w])) + 1) for w, c in bag.items()})
    return out


def cosine(a: dict[str, float], b: dict[str, float]) -> float:
    if not a or not b: return 0.0
    num = sum(v * b.get(k, 0.0) for k, v in a.items())
    den = math.sqrt(sum(v*v for v in a.values()) * sum(v*v for v in b.values()))
    return num / den if den else 0.0


def ngrams(text: str, n: int = 3) -> set[str]:
    s = re.sub(r"\s+", " ", text.casefold()).strip()
    return {s[i:i+n] for i in range(max(0, len(s)-n+1))}


def semantic(a: str, b: str) -> float:
    va, vb = tfidf([a, b])
    return min(1.0, .8*cosine(va, vb) + .2*core.jaccard(ngrams(a), ngrams(b)))


def dist(texts: Iterable[str]) -> dict[str, float]:
    counts = Counter(w for text in texts for w in words(text)); total = sum(counts.values()) or 1
    return {k: v/total for k, v in counts.items()}


def jsd(p: dict[str, float], q: dict[str, float]) -> float:
    if not p or not q: return 1.0 if p != q else 0.0
    keys = set(p)|set(q); mid = {k:(p.get(k,0)+q.get(k,0))/2 for k in keys}; eps=1e-12
    def kl(a: dict[str,float]) -> float:
        return sum(v*math.log((v+eps)/(mid.get(k,0)+eps),2) for k,v in a.items())
    return min(1.0, .5*kl(p)+.5*kl(q))


def entropy(texts: Iterable[str]) -> float:
    d = dist(texts)
    if len(d) <= 1: return 0.0
    return min(1.0, -sum(p*math.log(p,2) for p in d.values())/math.log(len(d),2))


def cusum(values: list[float]) -> Optional[int]:
    if len(values)<8: return None
    n=max(4,len(values)//5); base=values[:n]; med=statistics.median(base)
    mad=statistics.median(abs(x-med) for x in base) or .05; acc=0.0
    for i,x in enumerate(values[n:],n+1):
        acc=max(0,acc+x-med-.5*mad)
        if acc>5*mad: return i
    return None


def page_hinkley(values: list[float]) -> Optional[int]:
    if len(values)<6: return None
    mean=acc=minimum=0.0
    for i,x in enumerate(values,1):
        mean+=(x-mean)/i; acc+=x-mean-.01; minimum=min(minimum,acc)
        if i>=6 and acc-minimum>.35: return i
    return None


def ewma(values: list[float]) -> Optional[int]:
    if len(values)<8: return None
    n=max(4,len(values)//5); base=values[:n]; mean=statistics.mean(base); sd=statistics.pstdev(base) or .05; e=mean
    for i,x in enumerate(values,1):
        e=.25*x+.75*e
        if i>n and e>mean+2.5*sd: return i
    return None


def ensemble(values: list[float]) -> dict[str, Any]:
    methods={"cusum":cusum(values),"page_hinkley":page_hinkley(values),"ewma":ewma(values)}
    votes=[x for x in methods.values() if x is not None]; consensus=None
    for candidate in sorted(votes):
        if sum(abs(candidate-x)<=2 for x in votes)>=2: consensus=candidate; break
    return {"detectors":methods,"consensus_exchange":consensus,"label":"DERIVED_FROM_TRANSCRIPT"}


def shield(ratio: float) -> tuple[str,str]:
    if ratio>=.95:return "TERMINAL_GUARD","FREEZE_AND_PUBLISH_VERIFIED_HANDOFF"
    if ratio>=.85:return "SCOPE_FREEZE","REJECT_NEW_SCOPE_COMPLETE_ATOMIC_UNIT"
    if ratio>=.70:return "HANDOFF_REQUIRED","SPLIT_LANES_AND_CREATE_SUCCESSOR"
    if ratio>=.50:return "CAPACITY_RISK","CREATE_AND_READ_BACK_CHECKPOINT"
    return "HEALTHY","CONTINUE_WITH_MATERIAL_EVENT_CHECKPOINTS"


def conversation_payload(source: Path, title: str) -> Optional[dict[str,Any]]:
    def pick(payload: Any) -> list[dict[str,Any]]:
        return core.find_conversations_json(payload,title)
    found=[]
    if source.suffix.casefold()==".zip":
        with zipfile.ZipFile(source) as z:
            for name in z.namelist():
                if re.search(r"conversations(?:-\d+)?\.json$",name):
                    found.extend(pick(json.loads(z.read(name).decode("utf-8"))))
    elif source.suffix.casefold()==".json": found=pick(json.loads(source.read_text(encoding="utf-8-sig")))
    return found[0] if len(found)==1 else None


def branch_forensics(source: Path, title: str, max_branches: int=10000) -> dict[str,Any]:
    conv=conversation_payload(source,title)
    if not conv: return {"available":False,"reason":"NATIVE_MAPPING_NOT_AVAILABLE","branches":[]}
    mapping=conv.get("mapping") or {}; canonical=[]; current=conv.get("current_node"); seen=set()
    while current and current in mapping and current not in seen:
        seen.add(current); canonical.append(current); current=mapping[current].get("parent")
    canonical=list(reversed(canonical)); leaves=[k for k,v in mapping.items() if not(v.get("children") or [])]
    branches=[]
    for i,leaf in enumerate(leaves[:max_branches],1):
        path=[]; cur=leaf; visited=set()
        while cur and cur in mapping and cur not in visited:
            visited.add(cur); path.append(cur); cur=mapping[cur].get("parent")
        path=list(reversed(path)); divergence=next((j for j,(a,b) in enumerate(zip(path,canonical)) if a!=b),min(len(path),len(canonical)))
        branches.append({"branch_id":f"BR-{i:04d}","canonical":path==canonical,"nodes":len(path),"leaf":leaf,"divergence_index":divergence,"path_sha256":sha("\n".join(path))})
    return {"available":True,"mapping_nodes":len(mapping),"canonical_nodes":len(canonical),"branch_count":len(branches),"alternate_nodes":len(set(mapping)-set(canonical)),"branches":branches}


def conflicts(messages: list[core.Message]) -> list[dict[str,Any]]:
    positive=[]; negative=[]; out=[]
    for m in messages:
        if m.role!="assistant": continue
        for sentence in re.split(r"(?<=[.!?])\s+",m.text):
            key=set(words(sentence))
            if len(key)<3: continue
            neg=bool(re.search(r"\b(cannot|can't|not able|does not|is not|no access|unavailable)\b",sentence,re.I))
            pos=bool(re.search(r"\b(can|will|able|available|has access|supports)\b",sentence,re.I)) and not neg
            if not(neg or pos): continue
            opposite=positive if neg else negative; bucket=negative if neg else positive
            for old in opposite:
                overlap=core.jaccard(key,old["terms"])
                if overlap>=.30: out.append({"earlier_message_id":old["id"],"later_message_id":m.message_id,"topic_overlap":round(overlap,5),"label":"POTENTIAL_CONTRADICTION_REQUIRES_HUMAN_REVIEW"})
            bucket.append({"id":m.message_id,"terms":key})
    return out


def lineage(messages: list[core.Message]) -> dict[str,Any]:
    files=set(); urls=set(); hashes=set(); tools=[]
    for m in messages:
        files.update(x.strip() for x in FILE_RE.findall(m.text)); urls.update(URL_RE.findall(m.text)); hashes.update(HASH_RE.findall(m.text))
        if m.role=="tool" or m.metadata.get("recipient"):
            tools.append({"message_id":m.message_id,"role":m.role,"recipient":m.metadata.get("recipient"),"content_sha256":sha(m.text),"tokens":tokens(m.text,m.model)[0]})
    return {"files":sorted(files),"urls":sorted(urls),"hashes":sorted(hashes),"tool_events":tools}


def enhance(base: dict[str,Any], messages: list[core.Message], metadata: dict[str,Any], source: Path, config: dict[str,Any]) -> dict[str,Any]:
    pairs=core.pair_exchanges(messages); aliases={str(k).casefold():str(v) for k,v in config.get("command_aliases",{}).items()}
    history=deque(maxlen=int(config.get("rolling_topic_window",4))); anchors=deque(maxlen=int(config.get("rolling_anchor_messages",6)))
    directives=[]; previous=[]; enhanced=[]; conflict_rows=conflicts(messages); conflict_ids={x["later_message_id"] for x in conflict_rows}
    usable=max(1,int(config["context_window_tokens"])-int(config["reserved_output_tokens"])); cumulative=0; last_checkpoint=0
    for i,(user,assistant,between) in enumerate(pairs,1):
        u=aliases.get(user.text.strip().casefold(),user.text); a=assistant.text if assistant else ""; directive=bool(core.DIRECTIVE_RE.search(user.text.strip()))
        if directive or len(words(u))>=4: anchors.append(u)
        sim=semantic(u,a) if assistant else 0.0; anchor=semantic("\n".join(anchors),a) if anchors and assistant else 0.0
        topic=u+"\n"+a; shift=jsd(dist(history),dist([topic])) if history else 0.0; history.append(topic); lane=entropy(anchors)
        exchange=[user]+([assistant] if assistant else[])+between; counted=[tokens(m.text,m.model) for m in exchange]; visible=sum(x[0] for x in counted); cumulative+=visible
        checkpoint=any(core.CHECKPOINT_RE.search(m.text) for m in exchange)
        if checkpoint:last_checkpoint=i
        gap=i-last_checkpoint; over=bool(assistant and CAPABILITY_RE.search(a) and not EVIDENCE_RE.search(a)); confidence=bool(assistant and COMPLETE_RE.search(a) and not EVIDENCE_RE.search(a))
        retry=False
        if directive:
            retry=any(semantic(u,old["text"])>=.72 and old["state"]!="CLAIMED_COMPLETE_EVIDENCED" for old in previous[-8:])
        state="NOT_A_DIRECTIVE"; did=None
        if directive:
            did=f"DIR-{len(directives)+1:05d}"; state="MISSING_RESPONSE" if not assistant else "CLAIMED_COMPLETE_EVIDENCED" if COMPLETE_RE.search(a) and EVIDENCE_RE.search(a) else "CLAIMED_COMPLETE_UNEVIDENCED" if COMPLETE_RE.search(a) else "RESPONDED_UNVERIFIED"
            row={"directive_id":did,"user_message_id":user.message_id,"assistant_message_id":assistant.message_id if assistant else None,"semantic_similarity":round(sim,5),"anchor_similarity":round(anchor,5),"state":state,"retry":retry,"checkpoint":checkpoint,"label":"DERIVED_FROM_TRANSCRIPT"}; directives.append(row); previous.append({"text":u,"state":state})
        ratio=(cumulative+int(config["hidden_overhead_tokens"]))/usable; ss,sa=shield(ratio)
        base_m=base["metrics"][i-1]
        raw={"capacity":min(1,ratio),"drift":base_m["drift_score"],"repetition":base_m["repetition"],"payload":min(1,visible/max(1,int(config["large_message_tokens"]))),"checkpoint_gap":min(1,gap/max(1,int(config["checkpoint_interval_exchanges"]))),"topic_shift":shift,"lane_entropy":lane,"status_only":1.0 if base_m["status_only"] else 0.0,"capability_overclaim":1.0 if over else 0.0,"retry":1.0 if retry else 0.0,"claim_conflict":1.0 if assistant and assistant.message_id in conflict_ids else 0.0,"confidence_without_evidence":1.0 if confidence else 0.0}
        contributions={k:round(raw[k]*WEIGHTS[k],6) for k in WEIGHTS}; trouble=min(1,sum(contributions.values()))
        latency=None
        if assistant and user.timestamp is not None and assistant.timestamp is not None: latency=max(0,float(assistant.timestamp)-float(user.timestamp))
        enhanced.append({**base_m,"directive_id":did,"directive_state":state,"response_latency_seconds":latency,"semantic_similarity":round(sim,6),"anchor_semantic_similarity":round(anchor,6),"topic_shift":round(shift,6),"lane_entropy":round(lane,6),"model_aware_exchange_tokens":visible,"token_method":"TIKTOKEN_LOCAL_PROFILE" if counted and all(x[1].startswith("TIKTOKEN") for x in counted) else "MIXED_OR_HEURISTIC","context_proxy_ratio_v2":round(ratio,6),"checkpoint_gap_v2":gap,"capability_overclaim":over,"confidence_without_evidence":confidence,"retry":retry,"claim_conflict":raw["claim_conflict"]==1.0,"trouble_score_v2":round(trouble,6),"factor_contributions":contributions,"shield_state":ss,"shield_action":sa})
    telemetry_verified=bool(config.get("v2",{}).get("native_context_telemetry_verified",False))
    complete=bool(base["change_points"]["explicit_limit_signal_exchanges"] and base["source_completeness"]["messages_with_ids"]==len(messages) and telemetry_verified)
    base["audit"].update({"algorithm":"Conversation Failure Forensics — Black Box / Flight Recorder","version":VERSION,"owner":OWNER,"state":"COMPLETE_VERIFIED" if complete else "PARTIAL_CHECKPOINTED"})
    base["metrics"]=enhanced; base["directive_graph"]=directives; base["branch_forensics"]=branch_forensics(source,str(metadata.get("title")),int(config.get("max_branches",10000)))
    base["potential_claim_conflicts"]=conflict_rows; base["lineage"]=lineage(messages)
    base["change_points_v2"]={"drift":ensemble([x["drift_score"] for x in enhanced]),"topic_shift":ensemble([x["topic_shift"] for x in enhanced]),"capacity":ensemble([x["context_proxy_ratio_v2"] for x in enhanced]),"trouble":ensemble([x["trouble_score_v2"] for x in enhanced])}
    totals=Counter(); [totals.update(x["factor_contributions"]) for x in enhanced]; grand=sum(totals.values()) or 1
    base["ranked_contributing_factors_v2"]=[{"factor":k,"contribution":round(v,6),"share":round(v/grand,6),"label":"DERIVED_LINEAR_COUNTERFACTUAL_ATTRIBUTION"} for k,v in totals.most_common()]
    base["capacity_proxy"].update({"current_shield_state":enhanced[-1]["shield_state"],"current_shield_action":enhanced[-1]["shield_action"],"final_context_proxy_ratio_v2":enhanced[-1]["context_proxy_ratio_v2"]})
    base["failure_signatures"]={"capability_overclaim_exchanges":[x["exchange"] for x in enhanced if x["capability_overclaim"]],"confidence_without_evidence_exchanges":[x["exchange"] for x in enhanced if x["confidence_without_evidence"]],"retry_exchanges":[x["exchange"] for x in enhanced if x["retry"]],"potential_claim_conflicts":len(conflict_rows),"checkpoint_claims":sum(x["checkpoint"] for x in enhanced),"checkpoint_readback_language_present":any(re.search(r"readback|read back|sha-?256|version",(a.text if a else""),re.I) for _,a,_ in pairs)}
    return base


def event_ledger(messages: list[core.Message], metadata: dict[str,Any]) -> list[dict[str,Any]]:
    prev="0"*64; out=[]
    for m in messages:
        e={"event_id":f"EV-{m.seq:06d}","conversation_id":metadata.get("conversation_id"),"message_id":m.message_id,"parent_id":m.parent_id,"role":m.role,"timestamp":m.timestamp,"content_sha256":sha(m.text),"token_estimate":tokens(m.text,m.model)[0],"model":m.model,"previous_event_hash":prev}
        e["event_hash"]=sha(json.dumps(e,sort_keys=True,separators=(",",":"))); prev=e["event_hash"]; out.append(e)
    return out


def validate_ledger(events: list[dict[str,Any]]) -> bool:
    prev="0"*64
    for e in events:
        supplied=e["event_hash"]; body={k:v for k,v in e.items() if k!="event_hash"}
        if body["previous_event_hash"]!=prev or sha(json.dumps(body,sort_keys=True,separators=(",",":")))!=supplied:return False
        prev=supplied
    return True


def table(rows: Iterable[list[Any]],headers:list[str])->str:
    return "\n".join(["| "+" | ".join(headers)+" |","|"+"|".join(["---"]*len(headers))+"|"]+["| "+" | ".join(str(x).replace("|","\\|") for x in row)+" |" for row in rows])


def markdown(report:dict[str,Any])->str:
    cp=report["change_points_v2"]; cap=report["capacity_proxy"]
    lines=[f"# CFF v2 Black Box Report — {report['audit']['target_title']}","",f"Owner: **{OWNER}**  ",f"State: **{report['audit']['state']}**  ",f"Generated: `{report['audit']['generated_at']}`","","## Executive result","",f"- Earliest sustained drift: **{report['change_points']['earliest_sustained_drift_exchange'] or 'NOT ESTABLISHED'}**.",f"- Highest-risk exchange: **{report['change_points']['highest_trouble_exchange']}**.",f"- Terminal limit event: **{report['change_points']['explicit_limit_signal_exchanges'] or 'NOT PRESENT'}**.",f"- SHIELD‑95: **{cap['current_shield_state']}** — `{cap['current_shield_action']}`.","","> Context and causal metrics are derived proxies unless native platform evidence proves them.","","## Ensemble change points","",table([[k,v["detectors"],v["consensus_exchange"] or "no consensus"] for k,v in cp.items()],["Signal","Detectors","Consensus"]),"","## Ranked contributions","",table([[x["factor"],f"{x['contribution']:.4f}",f"{x['share']:.1%}"] for x in report["ranked_contributing_factors_v2"]],["Factor","Contribution","Share"]),"","## Directive graph","",table([[x["directive_id"],x["state"],f"{x['semantic_similarity']:.2f}",x["retry"]] for x in report["directive_graph"]],["Directive","State","Similarity","Retry"]),"","## Exchange matrix","",table([[x["exchange"],x["directive_id"] or "—",x["model_aware_exchange_tokens"],f"{x['context_proxy_ratio_v2']:.1%}",f"{x['semantic_similarity']:.2f}",f"{x['drift_score']:.2f}",f"{x['trouble_score_v2']:.2f}",x["shield_state"]] for x in report["metrics"]],["Ex","Directive","Tokens","Context","Semantic","Drift","Trouble","SHIELD"]),""]
    return "\n".join(lines)


def dashboard(report:dict[str,Any])->str:
    metrics=report["metrics"]
    source=report["audit"].get("source",{})
    completeness=report.get("source_completeness",{})
    capacity=report.get("capacity_proxy",{})
    peak=max(metrics,key=lambda x:x["trouble_score_v2"]) if metrics else {"exchange":0,"trouble_score_v2":0,"shield_state":"UNAVAILABLE"}
    message_count=int(completeness.get("message_count",0) or 0)
    id_count=int(completeness.get("messages_with_ids",0) or 0)
    coverage=(id_count/message_count) if message_count else 0
    telemetry=bool(completeness.get("native_token_telemetry_present",False))
    state=html.escape(str(report["audit"].get("state","UNAVAILABLE")))
    title=html.escape(str(report["audit"].get("target_title","Conversation")))
    source_name=html.escape(Path(str(source.get("source_path","UNAVAILABLE"))).name)
    generated=html.escape(str(report["audit"].get("generated_at","UNAVAILABLE")))
    state_class="verified" if state=="COMPLETE_VERIFIED" else "partial"
    factors=[x for x in report.get("ranked_contributing_factors_v2",[]) if x.get("share",0)>0][:7]
    factor_rows="".join(
        f"<li><span class='factor-head'><span>{html.escape(str(x['factor']).replace('_',' ').title())}</span>"
        f"<strong>{x['share']:.1%}</strong></span><span class='factor-track' aria-hidden='true'>"
        f"<span class='factor-fill' style='--factor-width:{min(100,100*float(x['share'])):.1f}%'></span></span></li>"
        for x in factors
    ) or "<li class='empty'>No non-zero contribution was measured.</li>"
    chart_data={
        "metrics":[{
            "exchange":x["exchange"],"directive":x.get("directive_id"),
            "context":x["context_proxy_ratio_v2"],"drift":x["drift_score"],
            "trouble":x["trouble_score_v2"],"shield":x["shield_state"],
            "limit":bool(x.get("explicit_limit_signal")),"checkpoint":bool(x.get("checkpoint")),
        } for x in metrics],
        "thresholds":[.5,.7,.85,.95],
    }
    payload=json.dumps(chart_data,separators=(",",":"),ensure_ascii=False).replace("</","<\\/")
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CFF v2 — {title}</title>
<style>
:root{{--bg:#f4f6f8;--surface:#ffffff;--surface-soft:#eef2f5;--ink:#16202a;--muted:#607080;--line:#d9e0e6;--primary:#184e77;--series-1:#d1495b;--series-2:#00798c;--series-3:#edae49;--warning-bg:#fff4d6;--warning-ink:#6d4c00;--good:#217a54;--partial:#9a5b00;--shadow:0 12px 34px rgba(25,43,58,.09)}}
@media(prefers-color-scheme:dark){{:root{{--bg:#10161c;--surface:#18212a;--surface-soft:#202b35;--ink:#edf3f7;--muted:#adbac5;--line:#34424f;--primary:#79b8e8;--series-1:#ff7b88;--series-2:#52c8d7;--series-3:#ffd071;--warning-bg:#392f16;--warning-ink:#ffe19a;--good:#63d49c;--partial:#ffc36b;--shadow:none}}}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 Inter,Segoe UI,Arial,sans-serif}} .shell{{max-width:1240px;margin:auto;padding:28px}}
.mast{{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:18px}} .eyebrow{{color:var(--muted);font-size:.78rem;letter-spacing:.13em;text-transform:uppercase;font-weight:600}} h1{{font-size:clamp(1.55rem,3vw,2.45rem);line-height:1.12;margin:.35rem 0 .45rem;letter-spacing:-.025em}} .subtitle{{margin:0;color:var(--muted)}}
.status{{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--line);border-radius:999px;padding:7px 11px;background:var(--surface);font-size:.78rem;font-weight:700;white-space:nowrap}} .status:before{{content:"";width:8px;height:8px;border-radius:50%;background:var(--partial)}} .status.verified:before{{background:var(--good)}}
.boundary{{display:flex;gap:11px;align-items:flex-start;background:var(--warning-bg);color:var(--warning-ink);border-left:4px solid var(--series-3);padding:12px 14px;margin-bottom:20px}} .boundary strong{{display:block}} .boundary p{{margin:1px 0 0}}
.stats{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:22px}} .stat{{background:var(--surface);border:1px solid var(--line);border-radius:14px;padding:17px 18px;box-shadow:var(--shadow)}} .stat-label{{color:var(--muted);font-size:.82rem}} .stat-value{{font-size:1.75rem;line-height:1.2;font-weight:700;margin:5px 0 2px}} .stat-note{{color:var(--muted);font-size:.8rem}}
.grid{{display:grid;grid-template-columns:minmax(0,1.8fr) minmax(260px,.8fr);gap:20px;align-items:start}} .panel{{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:18px;box-shadow:var(--shadow)}} .panel-head{{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:8px}} h2{{font-size:1rem;margin:0}} .panel-note{{color:var(--muted);font-size:.8rem;margin:.2rem 0 0}} .legend{{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:.77rem}} .legend span{{display:inline-flex;align-items:center;gap:6px}} .swatch{{width:18px;height:3px;border-radius:3px}} .trouble{{background:var(--series-1)}} .drift{{background:var(--series-2)}} .context{{background:var(--series-3)}}
.chart-wrap{{min-height:328px;position:relative}} #cff-chart{{width:100%;display:block}} .exchange-buttons{{display:flex;flex-wrap:wrap;gap:7px;margin-top:8px}} .exchange-buttons button{{appearance:none;border:1px solid var(--line);background:var(--surface-soft);color:var(--ink);border-radius:8px;padding:6px 9px;font:inherit;cursor:pointer}} .exchange-buttons button[aria-pressed=true]{{background:var(--primary);color:var(--surface);border-color:var(--primary)}} .selection{{min-height:24px;color:var(--muted);font-size:.84rem;margin-top:10px}}
.factors{{list-style:none;margin:12px 0 0;padding:0}} .factors li{{margin:0 0 13px}} .factor-head{{display:flex;justify-content:space-between;gap:12px;margin-bottom:5px;font-size:.85rem}} .factor-track{{display:block;height:8px;border-radius:99px;background:var(--surface-soft);overflow:hidden}} .factor-fill{{display:block;height:100%;width:var(--factor-width);background:var(--series-1);border-radius:inherit}} .empty{{color:var(--muted)}}
.integrity{{margin-top:18px;padding-top:14px;border-top:1px solid var(--line);display:grid;gap:7px}} .integrity-row{{display:flex;justify-content:space-between;gap:12px;font-size:.81rem}} .integrity-row span:first-child{{color:var(--muted)}} footer{{margin-top:18px;color:var(--muted);font-size:.76rem;display:flex;flex-wrap:wrap;justify-content:space-between;gap:8px}}
.gridline{{stroke:var(--line);stroke-width:1}} .axis-label,.annotation{{fill:var(--muted);font:12px Inter,Segoe UI,Arial,sans-serif}} .limit-line{{stroke:var(--series-1);stroke-width:1.5;stroke-dasharray:5 4}} .series-path{{fill:none;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}} .point{{stroke:var(--surface);stroke-width:2}} .selected-ring{{fill:none;stroke:var(--ink);stroke-width:2}}
@media(max-width:820px){{.grid{{grid-template-columns:1fr}}}} @media(max-width:620px){{.shell{{padding:16px}}.mast{{display:block}}.status{{margin-top:12px}}.stats{{grid-template-columns:1fr}}.panel-head{{display:block}}.legend{{margin-top:8px}}}}
@media(prefers-reduced-motion:reduce){{*{{scroll-behavior:auto!important;transition:none!important}}}}
</style></head>
<body><main class="shell" id="cff-dashboard">
<header class="mast"><div><div class="eyebrow">Conversation Failure Forensics · CFF v2</div><h1>Black Box Review — {title}</h1><p class="subtitle">Evidence-led reconstruction of drift, pressure and failure signals.</p></div><div class="status {state_class}">{state.replace('_',' ')}</div></header>
<section class="boundary" aria-label="Evidence boundary"><div aria-hidden="true">◆</div><div><strong>Evidence boundary</strong><p>Context occupation and causal contribution are derived proxies. Native transcript evidence controls; server-side context telemetry is {'present' if telemetry else 'not present'}.</p></div></section>
<section class="stats" aria-label="Audit overview">
<article class="stat"><div class="stat-label">Final context proxy</div><div class="stat-value">{float(capacity.get('final_context_proxy_ratio_v2',0)):.1%}</div><div class="stat-note">Estimated load · {html.escape(str(capacity.get('current_shield_state','UNAVAILABLE')).replace('_',' '))}</div></article>
<article class="stat"><div class="stat-label">Peak trouble score</div><div class="stat-value">{float(peak['trouble_score_v2']):.2f}</div><div class="stat-note">Exchange {peak['exchange']} · normalized 0–1</div></article>
<article class="stat"><div class="stat-label">Message-ID coverage</div><div class="stat-value">{coverage:.0%}</div><div class="stat-note">{id_count} of {message_count} messages carry native IDs</div></article>
</section>
<section class="grid">
<article class="panel"><div class="panel-head"><div><h2>Risk trajectory</h2><p class="panel-note">Normalized signals by exchange; the limit marker records transcript evidence, not inferred capacity.</p></div><div class="legend" aria-label="Chart legend"><span><i class="swatch trouble"></i>Trouble</span><span><i class="swatch drift"></i>Drift</span><span><i class="swatch context"></i>Context proxy</span></div></div><div class="chart-wrap"><svg id="cff-chart" role="img" aria-label="Trouble, drift and context proxy over conversation exchanges"></svg></div><div class="exchange-buttons" id="cff-exchanges" aria-label="Inspect exchange"></div><div class="selection" id="cff-selection" aria-live="polite"></div></article>
<aside class="panel"><div class="panel-head"><div><h2>Contributing factors</h2><p class="panel-note">Linear counterfactual attribution across the analyzed transcript.</p></div></div><ol class="factors">{factor_rows}</ol><div class="integrity" aria-label="Source integrity"><div class="integrity-row"><span>Source</span><strong>{source_name}</strong></div><div class="integrity-row"><span>Branches</span><strong>{int(report.get('branch_forensics',{}).get('branch_count',0) or 0)}</strong></div><div class="integrity-row"><span>Explicit limit event</span><strong>{'Present' if completeness.get('terminal_limit_event_present') else 'Not found'}</strong></div><div class="integrity-row"><span>Native token telemetry</span><strong>{'Present' if telemetry else 'Unavailable'}</strong></div></div></aside>
</section>
<footer><span>Owner: {html.escape(OWNER)}</span><span>Generated: {generated}</span><span>Source SHA-256: {html.escape(str(source.get('source_sha256','UNAVAILABLE')))[:16]}…</span></footer>
</main>
<script>
(()=>{{
  "use strict";
  const data={payload};
  const svg=document.getElementById("cff-chart");
  const wrap=svg.parentElement;
  const buttons=document.getElementById("cff-exchanges");
  const selection=document.getElementById("cff-selection");
  const ns="http://www.w3.org/2000/svg";
  let selected=data.metrics.length?data.metrics[data.metrics.length-1].exchange:null;
  const make=(name,attrs={{}})=>{{const node=document.createElementNS(ns,name);Object.entries(attrs).forEach(([k,v])=>node.setAttribute(k,String(v)));return node;}};
  const color=(name)=>getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  function show(exchange){{selected=exchange;const m=data.metrics.find(item=>item.exchange===exchange);if(!m)return;selection.textContent=`Exchange ${{m.exchange}} · Trouble ${{m.trouble.toFixed(2)}} · Drift ${{m.drift.toFixed(2)}} · Context ${{(m.context*100).toFixed(1)}}% · ${{m.shield.replaceAll("_"," ")}}${{m.limit?" · explicit limit signal":""}}`;buttons.querySelectorAll("button").forEach(b=>b.setAttribute("aria-pressed",String(Number(b.dataset.exchange)===exchange)));draw();}}
  function draw(){{
    const width=Math.max(300,Math.floor(wrap.clientWidth));const height=width<520?286:330;svg.replaceChildren();svg.setAttribute("width",String(width));svg.setAttribute("height",String(height));
    const margin={{left:42,right:38,top:28,bottom:38}},pw=width-margin.left-margin.right,ph=height-margin.top-margin.bottom;
    const xs=data.metrics.map(m=>m.exchange),lo=Math.min(...xs),hi=Math.max(...xs);const x=v=>margin.left+(hi===lo?pw/2:(v-lo)/(hi-lo)*pw);const y=v=>margin.top+(1-v)*ph;
    [0,.25,.5,.75,1].forEach(v=>{{const line=make("line",{{x1:margin.left,x2:width-margin.right,y1:y(v),y2:y(v),class:"gridline"}});svg.append(line);const label=make("text",{{x:margin.left-8,y:y(v)+4,"text-anchor":"end",class:"axis-label"}});label.textContent=v.toFixed(2);svg.append(label);}});
    const axis=make("text",{{x:margin.left,y:height-8,class:"axis-label"}});axis.textContent="Exchange";svg.append(axis);
    data.metrics.filter(m=>m.limit).forEach(m=>{{svg.append(make("line",{{x1:x(m.exchange),x2:x(m.exchange),y1:margin.top,y2:height-margin.bottom,class:"limit-line"}}));const t=make("text",{{x:Math.min(width-margin.right-4,x(m.exchange)+6),y:margin.top+12,"text-anchor":x(m.exchange)>width*.72?"end":"start",class:"annotation"}});t.textContent="Limit signal";svg.append(t);}});
    const series=[{{key:"trouble",css:"--series-1"}},{{key:"drift",css:"--series-2"}},{{key:"context",css:"--series-3"}}];
    series.forEach(s=>{{const pts=data.metrics.map(m=>`${{x(m.exchange)}},${{y(m[s.key])}}`).join(" ");svg.append(make("polyline",{{points:pts,class:"series-path",stroke:color(s.css)}}));data.metrics.forEach(m=>{{svg.append(make("circle",{{cx:x(m.exchange),cy:y(m[s.key]),r:4.5,fill:color(s.css),class:"point"}}));if(m.exchange===selected)svg.append(make("circle",{{cx:x(m.exchange),cy:y(m[s.key]),r:7.5,class:"selected-ring"}}));}});}});
    data.metrics.forEach(m=>{{const label=make("text",{{x:x(m.exchange),y:height-16,"text-anchor":"middle",class:"axis-label"}});label.textContent=String(m.exchange);svg.append(label);}});
  }}
  data.metrics.forEach(m=>{{const b=document.createElement("button");b.type="button";b.dataset.exchange=String(m.exchange);b.textContent=`Exchange ${{m.exchange}}${{m.limit?" · limit":""}}`;b.addEventListener("click",()=>show(m.exchange));buttons.append(b);}});
  if(data.metrics.length)show(selected);else selection.textContent="No exchange metrics available.";
  new ResizeObserver(draw).observe(wrap);
}})();
</script></body></html>"""


def capsule(report:dict[str,Any],instance_key:Optional[str]=None)->str:
    """Generate the complete universal ChatBridge 1.1 instance adapter."""
    audit=report["audit"]; source=audit.get("source",{}); complete=report.get("source_completeness",{})
    cp=report.get("change_points",{}); cap=report.get("capacity_proxy",{})
    title=str(audit.get("target_title") or "Conversation")
    prefix=safe_prefix(title); key=instance_key or f"{prefix.replace('_','-')}-forensics"
    generated=str(audit.get("generated_at") or datetime.now(timezone.utc).isoformat())
    stamp=re.sub(r"[^0-9]","",generated)[:14] or "UNAVAILABLE"
    state=str(audit.get("state","PARTIAL_CHECKPOINTED"))
    source_path=str(source.get("source_path","UNAVAILABLE")); source_hash=str(source.get("source_sha256","UNAVAILABLE"))
    branch_count=report.get("branch_forensics",{}).get("branch_count","UNAVAILABLE")
    drift=cp.get("earliest_sustained_drift_exchange") or "NOT_ESTABLISHED"
    terminal=cp.get("explicit_limit_signal_exchanges") or "NOT_PRESENT"
    telemetry=bool(complete.get("native_token_telemetry_present",False))
    next_action="ACQUIRE_NATIVE_CONTEXT_TELEMETRY_AND_RERUN" if state!="COMPLETE_VERIFIED" else str(cap.get("current_shield_action","CONTINUE_WITH_MATERIAL_EVENT_CHECKPOINTS"))
    bridge_status="ACTIVE_LOCAL"

    def cell(value:Any)->str:
        return str(value).replace("|","\\|").replace("\n"," ")

    directives=report.get("directive_graph",[])
    directive_rows="\n".join(
        f"| {cell(d.get('directive_id','UNAVAILABLE'))} | Directive at native message `{cell(d.get('user_message_id','UNAVAILABLE'))}` | UNAVAILABLE | {cell(d.get('state','UNVERIFIED'))} | audit target | native transcript message ID | NONE |"
        for d in directives
    ) or "| NONE | No directive nodes were recovered | UNAVAILABLE | UNVERIFIED | audit target | source audit | NONE |"
    gaps=list(report.get("evidence_gaps",[]))
    gap_rows=[]
    for i,gap in enumerate(gaps,1):
        gap_rows.append(f"| GAP-CFF-{i:03d} | {cell(gap.get('gap','UNAVAILABLE'))} | Blocks causal or completion certainty | Transcript analysis | Obtain native platform evidence | Native evidence becomes available |")
    cross_gap_id=f"GAP-CFF-{len(gap_rows)+1:03d}"
    gap_rows.append(f"| {cross_gap_id} | Independent successor-chat restore/write/readback has not been executed | Adapter remains local-only | Local capsule generation and hash validation | Run independent successor canary and return bidirectional receipt | Valid successor receipt passes origin readback |")
    factors=report.get("ranked_contributing_factors_v2",[])[:5]
    factor_summary=", ".join(f"{x.get('factor')}={float(x.get('share',0)):.1%}" for x in factors) or "NONE_MEASURED"
    event_rows=[]
    for d in directives[-20:]:
        did=cell(d.get("directive_id","UNAVAILABLE")); mid=cell(d.get("user_message_id","UNAVAILABLE"))
        event_rows.append(
            f"- event_id: \"CB-{key}-{stamp}Z-{did.lower()}\"\n"
            f"  observed_at: {json.dumps(generated)}\n"
            f"  chat_label: {json.dumps(title)}\n"
            f"  workstream_id: \"WS-CFF-AUDIT\"\n"
            f"  instruction: \"Recover directive {did} from native message {mid}\"\n"
            f"  actions: [\"classified directive/result state\"]\n"
            f"  result: {json.dumps(str(d.get('state','UNVERIFIED')))}\n"
            f"  sources: [{json.dumps('native-message:'+mid)}]\n"
            f"  artifacts: [\"ART-CFF-001\"]\n"
            f"  truth_labels: [\"DERIVED_FROM_TRANSCRIPT\"]\n"
            f"  open_gates: [{json.dumps('GAP-CFF-001' if gaps else cross_gap_id)}]\n"
            f"  next_action: {json.dumps(next_action)}"
        )
    event_rows.append(
        f"- event_id: \"CB-{key}-{stamp}Z-audit\"\n"
        f"  observed_at: {json.dumps(generated)}\n"
        f"  chat_label: {json.dumps(title)}\n"
        f"  workstream_id: \"WS-CFF-AUDIT\"\n"
        f"  instruction: \"Generate evidence-bounded conversation audit and continuity adapter\"\n"
        f"  actions: [\"audited transcript\", \"generated complete ChatBridge adapter\", \"validated content hash\"]\n"
        f"  result: {json.dumps(state)}\n"
        f"  sources: [{json.dumps(source_path)}, {json.dumps('sha256:'+source_hash)}]\n"
        f"  artifacts: [\"ART-CFF-001\", \"ART-CFF-002\", \"ART-CFF-003\", \"ART-CFF-004\", \"ART-CFF-005\", \"ART-CFF-006\"]\n"
        f"  truth_labels: [\"{cell(state)}\", \"PROOF_BOUNDED\"]\n"
        f"  open_gates: [{', '.join(json.dumps(f'GAP-CFF-{i:03d}') for i in range(1,len(gap_rows)+1))}]\n"
        f"  next_action: {json.dumps(next_action)}"
    )
    artifacts=[
        ("ART-CFF-001",f"{prefix}_forensic_audit_v2.json","audit JSON"),
        ("ART-CFF-002",f"{prefix}_forensic_audit_v2.md","forensic report"),
        ("ART-CFF-003",f"{prefix}_exchange_metrics_v2.csv","exchange metrics"),
        ("ART-CFF-004",f"{prefix}_forensic_dashboard_v2.html","interactive dashboard"),
        ("ART-CFF-005",f"{prefix}_event_ledger_v2.jsonl","hash-chained event ledger"),
        ("ART-CFF-006",f"{prefix}_transaction_manifest_v2.json","write/readback manifest"),
        ("ART-CFF-007",f"CHATBRIDGE-{key}-CURRENT.md","continuity adapter"),
    ]
    artifact_rows="\n".join(f"| {aid} | {name} | {role} | local output directory | {generated} | recorded in transaction manifest | current |" for aid,name,role in artifacts)
    text=f"""# CHATBRIDGE — {key} — CURRENT

```yaml
chatbridge:
  schema_version: "1.1"
  instance_name: {json.dumps(title+' Conversation Forensics')}
  instance_key: {json.dumps(key)}
  instance_type: "workstream"
  parent_instance_key: "conversation-failure-forensics"
  related_instance_keys: []
  owner: {json.dumps(OWNER)}
  lifecycle: "ACTIVE"
  status: "{bridge_status}"
  revision: 1
  updated_at: {json.dumps(generated)}
  current_version: "LOCAL_GENERATED_UNVERSIONED"
  previous_content_sha256: "UNAVAILABLE"
  content_sha256: "{'0'*64}"
  sensitivity: "USER_WORK_PRODUCT"
```

## 1. Scope, purpose, and completion definition

- Bounded subject: forensic audit of the exact conversation titled `{cell(title)}`.
- Included: recovered native messages, canonical/alternate branches, directives, response evidence, drift, risk proxies, checkpoints, claims, source lineage, and continuity state.
- Excluded unless separately proven: hidden prompts, server-side token counters, deleted/unexported messages, router state, and causal certainty from proxies alone.
- Objective: locate the earliest defensible trouble/drift point, explain contributing factors, preserve proof, and enable safe continuation.
- Non-goals: reconstruct unavailable platform internals or promote inference to native fact.
- Owner: {OWNER}.
- Done when: the exact native source is complete, IDs/timestamps/branches reconcile, a terminal event and native telemetry are verified where relevant, outputs pass readback, and an independent successor chat returns a valid bidirectional receipt.

## 2. Authority and truth controls

- Source precedence: native transcript/export and native telemetry > authenticated source artifacts > hash-verified capsule/ledger > summaries or memory > inference.
- Governing controls: CFF v{VERSION}; ChatBridge schema 1.1; SHIELD-95 thresholds 50/70/85/95%.
- Permissions: analyze and write bounded local audit artifacts only; no external communication is authorized by this adapter.
- Privacy: do not copy full transcript content into the capsule; preserve stable IDs, hashes, and compact findings.
- Release limit: `COMPLETE_VERIFIED` and `ACTIVE_CROSS_CHAT_VERIFIED` are prohibited until their independent evidence gates pass.

## 3. Current verified state

| Item | State | Truth label / source |
|---|---|---|
| Audit state | {cell(state)} | audit report |
| Source | `{cell(source_path)}` | native-source candidate |
| Source SHA-256 | `{cell(source_hash)}` | computed from input bytes |
| Messages / exchanges | {complete.get('message_count','UNAVAILABLE')} / {complete.get('exchange_count','UNAVAILABLE')} | recovered source |
| Message-ID coverage | {complete.get('messages_with_ids','UNAVAILABLE')} of {complete.get('message_count','UNAVAILABLE')} | native fields |
| Branch count | {cell(branch_count)} | native mapping analysis |
| Earliest sustained drift | {cell(drift)} | transcript-derived |
| Explicit terminal signal exchanges | {cell(terminal)} | transcript evidence |
| Native context telemetry | {'PRESENT' if telemetry else 'UNAVAILABLE'} | native platform evidence gate |
| SHIELD-95 | {cell(cap.get('current_shield_state','UNAVAILABLE'))} — `{cell(cap.get('current_shield_action','UNAVAILABLE'))}` | estimated proxy |
| Leading factors | {cell(factor_summary)} | derived linear attribution |
| Cross-chat proof | NOT_EXECUTED | independent successor receipt required |

## 4. Directive register

| ID | Instruction | Date | Status | Scope | Source | Supersession |
|---|---|---|---|---|---|---|
{directive_rows}

## 5. Workstream registry

| ID | Objective | Status | Latest checkpoint | Dependencies | Next action | Proof required |
|---|---|---|---|---|---|---|
| WS-CFF-AUDIT | Audit the recovered conversation from start to terminal state | {cell(state)} | {generated} | exact source; native telemetry for completion | `{cell(next_action)}` | native evidence plus output readback |
| WS-CFF-CONTINUITY | Preserve and independently restore audit state | READY_NOT_EXECUTED | complete local capsule generated | independent successor chat | execute restore/write/readback canary | signed/hash-bound bidirectional receipt |

## 6. Decision register

| ID | Decision | Rationale | Source | Date | Reversal / supersession |
|---|---|---|---|---|---|
| DEC-CFF-001 | Native evidence controls all completion claims | Prevent inferred context/cause from becoming fact | CFF truth boundary | {generated} | NONE |
| DEC-CFF-002 | Missing native telemetry keeps the audit partial | Context proxies cannot prove a platform limit | CFF completion gate | {generated} | Reverse only with native evidence |
| DEC-CFF-003 | Local capsule generation is not cross-chat verification | A separate chat must independently restore and return a delta receipt | ChatBridge proof model | {generated} | Reverse only after valid canary readback |

## 7. Fact and issue register

| ID | Item | Truth label | Exact source pointer | Dispute / qualification |
|---|---|---|---|---|
| FACT-CFF-001 | {complete.get('message_count','UNAVAILABLE')} messages and {complete.get('exchange_count','UNAVAILABLE')} exchanges were analyzed | NATIVE_SOURCE_DERIVED | `{cell(source_path)}` / `{cell(source_hash)}` | Only the recovered source boundary is claimed |
| FACT-CFF-002 | Terminal signal exchanges: {cell(terminal)} | TRANSCRIPT_EVIDENCE | `change_points.explicit_limit_signal_exchanges` | Absence does not prove no platform limit occurred |
| ISSUE-CFF-001 | Native context telemetry: {'present' if telemetry else 'unavailable'} | {'VERIFIED' if telemetry else 'UNVERIFIED'} | `source_completeness.native_token_telemetry_present` | Required for native capacity certainty |
| ISSUE-CFF-002 | Factor shares: {cell(factor_summary)} | DERIVED_LINEAR_COUNTERFACTUAL_ATTRIBUTION | `ranked_contributing_factors_v2` | Association/proxy, not causal proof |

## 8. Artifact and source index

| ID | Title | Role | Location / connector | Modified | Hash | Status |
|---|---|---|---|---|---|---|
| SRC-CFF-001 | {cell(Path(source_path).name)} | bounded audit source | `{cell(source_path)}` | UNAVAILABLE | `{cell(source_hash)}` | recovered |
{artifact_rows}

## 9. Open gates and discrepancy log

| Gap ID | Exact gap | Impact | Attempted routes | Next route | Reactivation condition |
|---|---|---|---|---|---|
{chr(10).join(gap_rows)}

## 10. Next-action queue

1. `{cell(next_action)}`; complete only on native source/telemetry readback.
2. Execute the independent successor-chat restore/write/readback canary; require a bidirectional delta receipt bound to this capsule hash.
3. Re-run CFF and promote state only if every higher-precedence evidence gate passes.

## 11. Recent event window

```yaml
{chr(10).join(event_rows)}
```

## 12. Predecessors and archives

- Previous capsule hash: `UNAVAILABLE` (first generated revision for this bounded audit).
- Event archive: `ART-CFF-005`; it is append-only and hash-chained for the recovered source window.
- Transaction/readback archive: `ART-CFF-006`.
- No predecessor is silently imported or treated as reconciled.

## 13. Relationships

- Parent: `conversation-failure-forensics` — universal algorithm, policy, and schema only.
- Child adapters: none registered.
- Related adapters: none registered.
- Boundary: this adapter contains state for `{cell(title)}` only; it must not absorb unrelated conversations or their proof claims.

## 14. Handoff receipt

- Latest recovered checkpoint: audit generated `{generated}` from source SHA-256 `{cell(source_hash)}`.
- Single next action: `{cell(next_action)}`.
- Adapter proof level: `{bridge_status}` / cross-chat `NOT_EXECUTED`.
- Handoff rule: successor must verify `content_sha256`, state the recovered checkpoint and single next action, write a new delta receipt, and expose that receipt for origin readback before promotion.
"""
    digest=capsule_digest(text)
    text=text.replace(f'content_sha256: "{"0"*64}"',f'content_sha256: "{digest}"',1)
    valid,reason=validate_capsule(text)
    if not valid: raise ValueError(f"generated ChatBridge capsule failed validation: {reason}")
    return text


CAPSULE_REQUIRED_SECTIONS=tuple(f"## {i}." for i in range(1,15))


def capsule_digest(text:str)->str:
    """Hash a capsule with its self-referential hash field normalized."""
    normalized=re.sub(r'(?m)^(  content_sha256: )"[a-fA-F0-9]{64}"$',lambda m:m.group(1)+'"'+'0'*64+'"',text,count=1)
    return sha(normalized)


def validate_capsule(text:str)->tuple[bool,str]:
    """Fail closed on schema, identity, section, or content-integrity drift."""
    if 'schema_version: "1.1"' not in text:return False,"SCHEMA_VERSION_MISSING"
    if any(section not in text for section in CAPSULE_REQUIRED_SECTIONS):return False,"REQUIRED_SECTION_MISSING"
    heading=re.search(r'^# CHATBRIDGE — ([a-z0-9-]+) — CURRENT$',text,re.M)
    key=re.search(r'^  instance_key: "([a-z0-9-]+)"$',text,re.M)
    if not heading or not key or heading.group(1)!=key.group(1):return False,"INSTANCE_IDENTITY_MISMATCH"
    stored=re.search(r'^  content_sha256: "([a-fA-F0-9]{64})"$',text,re.M)
    if not stored:return False,"CONTENT_HASH_MISSING"
    if stored.group(1).casefold()!=capsule_digest(text):return False,"CONTENT_HASH_MISMATCH"
    return True,"VALID"


def write_outputs(report:dict[str,Any],messages:list[core.Message],metadata:dict[str,Any],out:Path,output_prefix:Optional[str]=None)->dict[str,str]:
    prefix=safe_prefix(output_prefix or str(metadata.get("title") or report["audit"].get("target_title") or "conversation"))
    bridge_key=f"{prefix.replace('_','-')}-forensics"
    out.mkdir(parents=True,exist_ok=True); paths={"json":out/f"{prefix}_forensic_audit_v2.json","markdown":out/f"{prefix}_forensic_audit_v2.md","csv":out/f"{prefix}_exchange_metrics_v2.csv","html":out/f"{prefix}_forensic_dashboard_v2.html","ledger":out/f"{prefix}_event_ledger_v2.jsonl","capsule":out/f"CHATBRIDGE-{bridge_key}-CURRENT.md","transaction":out/f"{prefix}_transaction_manifest_v2.json"}
    paths["json"].write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8"); paths["markdown"].write_text(markdown(report),encoding="utf-8"); paths["html"].write_text(dashboard(report),encoding="utf-8"); paths["capsule"].write_text(capsule(report,bridge_key),encoding="utf-8")
    events=event_ledger(messages,metadata)
    if not validate_ledger(events):raise ValueError("event hash-chain validation failed")
    paths["ledger"].write_text("\n".join(json.dumps(e,sort_keys=True) for e in events)+"\n",encoding="utf-8")
    with paths["csv"].open("w",newline="",encoding="utf-8") as f:
        fields=list(report["metrics"][0].keys()); w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for row in report["metrics"]:
            copy=dict(row); copy["factor_contributions"]=json.dumps(copy["factor_contributions"],sort_keys=True); w.writerow(copy)
    writes=[]
    for key,path in paths.items():
        if key=="transaction":continue
        digest=hashlib.sha256(path.read_bytes()).hexdigest(); writes.append({"surface":"LOCAL_ARTIFACT","recordId":key,"idempotencyKey":digest,"state":"VERIFIED","readback":path.exists(),"expected":{"sha256":digest},"actual":{"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}})
    tx={"transactionId":f"TXN-CFF2-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}","missionVersion":2,"events":[{"eventId":e["event_id"],"sourceId":e["message_id"],"sourceVersion":e["content_sha256"],"occurrenceKey":e["role"],"disposition":"CAPTURE"} for e in events],"existingIds":{"EV":[e["event_id"] for e in events]},"writes":writes,"commitState":"COMMITTED","publishState":"PUBLISHED","unresolvedFaults":[x["gap"] for x in report["evidence_gaps"]],"completionClaim":report["audit"]["state"]}; paths["transaction"].write_text(json.dumps(tx,indent=2),encoding="utf-8")
    return {k:str(v) for k,v in paths.items()}


def run(source:Path,title:str,config_path:Optional[Path],out:Path,output_prefix:Optional[str]=None)->tuple[dict[str,Any],dict[str,str]]:
    config=core.merge_config(config_path); messages,metadata=core.load_source(source,title)
    source_ids=[m.message_id for m in messages if m.message_id]
    duplicates=[item for item,count in Counter(source_ids).items() if count>1]
    if duplicates: raise ValueError(f"Duplicate native message IDs fail closed: {duplicates}")
    base=core.analyze(messages,metadata,config); report=enhance(base,messages,metadata,source,config); return report,write_outputs(report,messages,metadata,out,output_prefix)


def main(argv:Optional[list[str]]=None)->int:
    p=argparse.ArgumentParser(description="CFF v2 universal Black Box audit"); p.add_argument("source",type=Path); p.add_argument("--title",default="App mentions"); p.add_argument("--config",type=Path); p.add_argument("--output-dir",type=Path,default=Path("audit-output-v2")); p.add_argument("--output-prefix",help="Optional collision-safe filename prefix; defaults to the normalized exact title"); p.add_argument("--strict-complete",action="store_true"); a=p.parse_args(argv)
    try:
        report,outputs=run(a.source,a.title,a.config,a.output_dir,a.output_prefix)
        if a.strict_complete and report["audit"]["state"]!="COMPLETE_VERIFIED": print(json.dumps({"status":"PARTIAL_CHECKPOINTED","outputs":outputs}),file=sys.stderr); return 3
        print(json.dumps({"status":report["audit"]["state"],"outputs":outputs})); return 0
    except Exception as exc: print(json.dumps({"status":"AUDIT_BLOCKED","error":str(exc)}),file=sys.stderr); return 2


if __name__=="__main__":raise SystemExit(main())
