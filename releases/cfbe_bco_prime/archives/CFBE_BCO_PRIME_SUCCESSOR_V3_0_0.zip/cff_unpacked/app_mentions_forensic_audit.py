#!/usr/bin/env python3
"""Compatibility launcher for CFF v2 Black Box / Flight Recorder."""
from app_mentions_forensic_audit_v2 import *  # noqa: F401,F403
from app_mentions_forensic_audit_v2 import main

if __name__ == "__main__":
    raise SystemExit(main())
