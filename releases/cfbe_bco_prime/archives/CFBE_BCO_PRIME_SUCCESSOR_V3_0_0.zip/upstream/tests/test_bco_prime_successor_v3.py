import contextlib
import hashlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_successor_v3 as successor
from benchmarking.cfbe_omega import bco_prime_chat_forensics_v2 as v2


def event():
    return {
        "event_id": "event-1",
        "mission_id": "mission-1",
        "correlation_id": "correlation-1",
        "kind": "TEST",
        "status": "COMPLETED",
        "failure_type": "NONE",
        "started_ns": 1,
        "ended_ns": 2,
        "payload": {},
    }


class SuccessorRegistryTests(unittest.TestCase):
    def test_additive_health_and_legacy_routes(self):
        with tempfile.TemporaryDirectory() as directory:
            registry = successor.SuccessorRegistry(Path(directory))
            health = registry.health()
            self.assertEqual(health["canonical_core_count"], 100)
            self.assertTrue(health["canonical_core_invariant_preserved"])
            self.assertEqual(health["runtimeState"], "ON_DEMAND_GOVERNED")
            self.assertEqual(health["successor_operation_count"], 14)
            self.assertEqual(registry.execute("BCO-PRIME-CAP-001", {})["namespace"], "core")
            self.assertEqual(
                registry.execute(
                    "BCO-PRIME-CFF-CAP-001",
                    {"expected_id": "conversation-1", "observed_id": "conversation-1"},
                )["namespace"],
                "legacy_chat_forensics",
            )

    def test_new_registry_flight_and_effect_denial(self):
        with tempfile.TemporaryDirectory() as directory:
            registry = successor.SuccessorRegistry(Path(directory))
            manifest = registry.execute("BCO-PRIME-V3-MANIFEST", {})
            self.assertEqual(manifest["namespace"], "successor_v3")
            appended = registry.execute(
                "BCO-PRIME-V3-FLIGHT-APPEND", {"recorder_root": "flight", "event": event()}
            )
            self.assertEqual(appended["output"]["sequence"], 1)
            verified = registry.execute("BCO-PRIME-V3-FLIGHT-VERIFY", {"recorder_root": "flight"})
            self.assertTrue(verified["output"]["valid"])
            with self.assertRaises(v2.ContractError):
                registry.execute("BCO-PRIME-V3-MANIFEST", {"deploy": True})
            with self.assertRaises(successor.SuccessorContractError):
                registry.execute("BCO-PRIME-V3-FLIGHT-VERIFY", {"recorder_root": "../escape"})

    def test_meta_dependency_closure_is_real_and_hash_pinned(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            registry = successor.SuccessorRegistry(root)
            blocked = registry.execute("BCO-PRIME-V3-META-DEPENDENCY-CLOSURE", {})["output"]
            self.assertEqual(blocked["state"], "BLOCKED_WITH_ROUTE")
            self.assertTrue(blocked["safeSubsetReady"])
            dependencies = {}
            for name in successor.META_DEPENDENCIES:
                relative = f"dependencies/{name.lower()}.json"
                target = root / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(json.dumps({"dependency": name}), encoding="utf-8")
                dependencies[name] = {
                    "path": relative,
                    "expected_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                }
            ready = registry.execute(
                "BCO-PRIME-V3-META-DEPENDENCY-CLOSURE", {"dependencies": dependencies}
            )["output"]
            self.assertEqual(ready["state"], "READY")
            self.assertTrue(ready["fullMetaRuntimeReady"])
            dependencies["PROOF_OS"]["expected_sha256"] = "0" * 64
            mismatch = registry.execute(
                "BCO-PRIME-V3-META-DEPENDENCY-CLOSURE", {"dependencies": dependencies}
            )["output"]
            self.assertEqual(mismatch["state"], "BLOCKED_WITH_ROUTE")

    def test_cli_health_smoke(self):
        with tempfile.TemporaryDirectory() as directory:
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                self.assertEqual(successor.main(["--workspace-root", directory, "health"]), 0)
            parsed = json.loads(output.getvalue())
            self.assertEqual(parsed["canonical_core_count"], 100)


if __name__ == "__main__":
    unittest.main()
