import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_flight_recorder_v3 as flight


def event(event_id="event-1", *, parent_id=None, failure_type="NONE", payload=None):
    return {
        "event_id": event_id,
        "mission_id": "mission-1",
        "correlation_id": "correlation-1",
        "parent_id": parent_id,
        "kind": "TEST_EVENT",
        "status": "COMPLETED",
        "failure_type": failure_type,
        "started_ns": 1_000_000,
        "ended_ns": 3_500_000,
        "payload": payload or {"proof": "local"},
    }


class FlightRecorderTests(unittest.TestCase):
    def test_append_verify_replay_and_checkpoint(self):
        with tempfile.TemporaryDirectory() as directory:
            recorder = flight.FlightRecorder(Path(directory))
            first = recorder.append(event())
            recorder.append(event("event-2", parent_id="event-1"))
            self.assertEqual(first["sequence"], 1)
            self.assertEqual(first["latency_ms"], 2.5)
            self.assertTrue(recorder.verify()["valid"])
            replay = recorder.replay()
            self.assertEqual(replay["drift_state"], "NO_DRIFT_DETECTED")
            self.assertEqual(replay["status_counts"], {"COMPLETED": 2})
            checkpoint = recorder.checkpoint("checkpoints/current.json")
            self.assertEqual(checkpoint["event_count"], 2)
            self.assertTrue((Path(directory) / "checkpoints/current.json").is_file())

    def test_duplicate_taxonomy_effect_and_path_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            recorder = flight.FlightRecorder(Path(directory))
            recorder.append(event())
            with self.assertRaises(flight.FlightRecorderError):
                recorder.append(event())
            with self.assertRaises(flight.FlightRecorderError):
                recorder.append(event("event-2", failure_type="NOT_REAL"))
            with self.assertRaises(flight.FlightRecorderError):
                recorder.append(event("event-3", payload={"external_effect": True}))
            with self.assertRaises(flight.FlightRecorderError):
                flight.FlightRecorder(Path(directory), "../escape.jsonl")
            with self.assertRaises(flight.FlightRecorderError):
                recorder.checkpoint("../escape.json")

    def test_tamper_is_detected_and_blocks_append_and_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            recorder = flight.FlightRecorder(Path(directory))
            recorder.append(event())
            row = json.loads(recorder.ledger_path.read_text(encoding="utf-8"))
            row["payload"]["proof"] = "tampered"
            recorder.ledger_path.write_text(json.dumps(row) + "\n", encoding="utf-8")
            verification = recorder.verify()
            self.assertFalse(verification["valid"])
            self.assertIn("EVENT_HASH_MISMATCH:1", verification["failures"])
            with self.assertRaises(flight.FlightRecorderError):
                recorder.append(event("event-2"))
            with self.assertRaises(flight.FlightRecorderError):
                recorder.replay()

    def test_missing_parent_is_reported_as_replay_drift(self):
        with tempfile.TemporaryDirectory() as directory:
            recorder = flight.FlightRecorder(Path(directory))
            recorder.append(event(parent_id="absent-parent"))
            replay = recorder.replay()
            self.assertEqual(replay["drift_state"], "DRIFT_DETECTED")
            self.assertEqual(replay["drift"], ["MISSING_PARENT:event-1:absent-parent"])


if __name__ == "__main__":
    unittest.main()
