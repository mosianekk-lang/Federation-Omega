import json
import os
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_harvesting_fabric_v1 as harvest


MIT_SOURCE = """# SPDX-License-Identifier: MIT
import hashlib
api_key = \"super-secret-value\"

def verify_payload(payload: dict) -> bool:
    return bool(hashlib.sha256(repr(payload).encode()).hexdigest())
"""


def paired_cases():
    return [
        {"baseline_quality": 0.5, "candidate_quality": 0.6, "passed": True}
        for _ in range(30)
    ]


class HarvestingFabricTests(unittest.TestCase):
    def test_authorized_incremental_scan_dedupes_content_not_occurrences(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "a.py").write_text(MIT_SOURCE, encoding="utf-8")
            (root / "b.py").write_text(MIT_SOURCE, encoding="utf-8")
            (root / "unsupported.bin").write_bytes(b"x")
            result = harvest.CapabilityRadar(root, ["source-1"]).scan(
                "source-1", "tenant-1", "matter-1"
            )
            self.assertEqual(result["occurrence_count"], 2)
            self.assertEqual(result["unique_content_count"], 1)
            self.assertEqual(len(result["duplicate_content_ids"]), 1)
            self.assertEqual(len({item["occurrence_id"] for item in result["records"]}), 2)
            self.assertFalse(result["raw_content_emitted"])
            self.assertNotIn("super-secret-value", json.dumps(result))
            self.assertTrue(any("unsupported file type" in item["reason"] for item in result["rejects"]))
            self.assertTrue(all(item["authority_state"] == "AUTHORIZED" for item in result["records"]))

    def test_authority_symlink_size_and_parser_fail_closed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "large.txt").write_text("x" * 32, encoding="utf-8")
            (root / "broken.py").write_text("def broken(:\n", encoding="utf-8")
            (root / "broken.json").write_text("{not-json", encoding="utf-8")
            outside = root.parent / f"{root.name}-outside.txt"
            outside.write_text("outside", encoding="utf-8")
            link = root / "outside-link.txt"
            try:
                os.symlink(outside, link)
            except OSError:
                link = None
            radar = harvest.CapabilityRadar(root, ["source-1"], max_file_bytes=16)
            with self.assertRaises(harvest.HarvestContractError):
                radar.scan("not-authorized", "tenant-1", "matter-1")
            result = radar.scan("source-1", "tenant-1", "matter-1")
            reasons = " ".join(item["reason"] for item in result["rejects"])
            self.assertIn("file size limit exceeded", reasons)
            self.assertIn("malformed Python", reasons)
            self.assertIn("malformed JSON", reasons)
            if link is not None:
                self.assertIn("symbolic links are not harvestable", reasons)

    def test_graph_compiler_and_shadow_qualification(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "capability.py").write_text(MIT_SOURCE, encoding="utf-8")
            scan = harvest.CapabilityRadar(root, ["source-1"]).scan(
                "source-1", "tenant-1", "matter-1"
            )
            graph = harvest.build_opportunity_graph(scan["records"])
            self.assertTrue(graph["acyclic"])
            candidate = harvest.compile_candidate(graph, [graph["ranked_candidates"][0]])
            self.assertFalse(candidate["shadow_package"]["executable"])
            receipt = harvest.qualify_shadow_candidate(
                candidate,
                paired_cases(),
                rollback_available=True,
                independent_verifier_pass=True,
            )
            self.assertTrue(receipt["shadowProven"])
            self.assertFalse(receipt["stablePromotionAuthorized"])
            escaped = dict(candidate)
            escaped["providerEffectAuthorized"] = True
            rejected = harvest.qualify_shadow_candidate(
                escaped,
                paired_cases(),
                rollback_available=True,
                independent_verifier_pass=True,
            )
            self.assertIn("SHADOW_ESCAPE_REJECTED", rejected["reasons"])

    def test_unknown_licence_and_dependency_cycle_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "unknown.py").write_text("def candidate():\n    return True\n", encoding="utf-8")
            scan = harvest.CapabilityRadar(root, ["source-1"]).scan(
                "source-1", "tenant-1", "matter-1"
            )
            graph = harvest.build_opportunity_graph(scan["records"])
            with self.assertRaises(harvest.HarvestContractError):
                harvest.compile_candidate(graph, [graph["ranked_candidates"][0]])

        base = {
            "controls": [],
            "confidence": 1.0,
            "authority_state": "AUTHORIZED",
            "license": {"compatible": True},
            "content_id": "c" * 64,
        }
        first = dict(base, dna_id="a" * 64, symbol="one", dependencies=["two"])
        second = dict(base, dna_id="b" * 64, symbol="two", dependencies=["one"])
        with self.assertRaises(harvest.HarvestContractError):
            harvest.build_opportunity_graph([first, second])


if __name__ == "__main__":
    unittest.main()
