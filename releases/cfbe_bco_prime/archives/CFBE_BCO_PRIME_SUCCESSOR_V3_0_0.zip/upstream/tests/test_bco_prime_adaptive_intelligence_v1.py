import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_adaptive_intelligence_v1 as adaptive


def candidate(effect_class="LOCAL_SHADOW"):
    return adaptive.PolicyCandidate(
        "adaptive-test",
        "operation-a",
        "checkpoint_and_reduce_batch_size",
        ("evidence-1",),
        True,
        effect_class,
    )


def cases(count=30, baseline=0.5, proposed=0.6, hard_regression=False):
    return [
        {
            "baseline_quality": baseline,
            "candidate_quality": proposed,
            "hard_regression": hard_regression and index == 0,
        }
        for index in range(count)
    ]


class AdaptiveIntelligenceTests(unittest.TestCase):
    def test_observation_validation_and_measured_candidate_derivation(self):
        with self.assertRaises(adaptive.AdaptiveContractError):
            adaptive.TelemetryObservation("", True, 1.0, evidence_id="evidence-1")
        with self.assertRaises(adaptive.AdaptiveContractError):
            adaptive.TelemetryObservation("op", True, -1.0, evidence_id="evidence-1")
        observations = [
            adaptive.TelemetryObservation("slow", True, 1500.0, evidence_id="evidence-1"),
            adaptive.TelemetryObservation("failed", False, 20.0, "TIMEOUT", "evidence-2"),
        ]
        derived = {item.operation: item for item in adaptive.derive_candidates(observations)}
        self.assertEqual(derived["slow"].policy, "checkpoint_and_reduce_batch_size")
        self.assertIn("quarantine", derived["failed"].policy)
        self.assertEqual(adaptive.derive_candidates([]), ())

    def test_policy_candidate_requires_identity_evidence_and_reversibility(self):
        with self.assertRaises(adaptive.AdaptiveContractError):
            adaptive.PolicyCandidate("", "", "", (), False)

    def test_paired_evaluation_never_self_promotes(self):
        accepted = adaptive.paired_evaluate(
            candidate(), cases(), rollback_available=True, independent_verifier_pass=True
        )
        self.assertTrue(accepted["shadowProven"])
        self.assertFalse(accepted["stablePromotionAuthorized"])
        self.assertEqual(accepted["state"], "SHADOW_CANDIDATE_REVIEW")

        too_small = adaptive.paired_evaluate(
            candidate(), cases(29), rollback_available=True, independent_verifier_pass=True
        )
        self.assertIn("THIRTY_PAIRED_CASES_REQUIRED", too_small["reasons"])
        regressed = adaptive.paired_evaluate(
            candidate(), cases(hard_regression=True), rollback_available=True, independent_verifier_pass=True
        )
        self.assertIn("HARD_REGRESSION", regressed["reasons"])
        unsafe = adaptive.paired_evaluate(
            candidate("PROVIDER"), cases(), rollback_available=False, independent_verifier_pass=False
        )
        self.assertFalse(unsafe["shadowProven"])
        self.assertIn("NON_SHADOW_EFFECT_CLASS_REJECTED", unsafe["reasons"])

    def test_rollback_is_candidate_bound(self):
        receipt = adaptive.paired_evaluate(
            candidate(), cases(), rollback_available=True, independent_verifier_pass=True
        )
        self.assertEqual(adaptive.rollback(candidate(), receipt)["state"], "ROLLED_BACK_TO_STABLE_BASELINE")
        with self.assertRaises(adaptive.AdaptiveContractError):
            adaptive.rollback(
                adaptive.PolicyCandidate("different", "op", "policy", ("proof",), True), receipt
            )


if __name__ == "__main__":
    unittest.main()
