import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from benchmarking.cfbe_omega import bco_prime_capability_fabric_v1 as core
from benchmarking.cfbe_omega import bco_prime_chat_forensics_v1 as legacy
from benchmarking.cfbe_omega import bco_prime_chat_forensics_v2 as v2


ENGINE_ROOT = Path(__file__).resolve().parents[2] / "cff_unpacked"
ENGINE_PATH = ENGINE_ROOT / "app_mentions_forensic_audit_v2.py"
ENGINE_SHA256 = "e56e002e7e0c5e95cc0b5cc13279f12da6e45fd8eb137156f5f661f0cf67e016"
DEPENDENCY_SHA256 = "6226812cbf69335cfb74e3be244d107202eb065019321767411cdb951f1bbe7b"


def incident():
    sha = "a" * 64
    return {
        "conversation": {
            "expected_id": "conv-1",
            "observed_id": "conv-1",
            "expected_title": "Synthetic audit",
            "observed_title": "Synthetic audit",
        },
        "sources": [
            {
                "source_id": "tool-1",
                "kind": "forensic_engine",
                "accessible": True,
                "captured": True,
                "sha256": sha,
                "bytes": 20,
            },
            {
                "source_id": "incident-1",
                "kind": "conversation_export",
                "accessible": True,
                "captured": True,
                "sha256": sha,
            },
            {
                "source_id": "incident-2",
                "kind": "trace",
                "accessible": True,
                "captured": True,
                "sha256": sha,
            },
            {
                "source_id": "incident-3",
                "kind": "screenshot",
                "accessible": True,
                "captured": True,
                "sha256": sha,
            },
            {
                "source_id": "blocked-1",
                "kind": "backend_log",
                "accessible": False,
                "captured": False,
            },
        ],
        "observations": {
            "working_indicator_present": True,
            "assistant_terminal_content_present": False,
            "final_tool_action_present": True,
            "final_response_commit_observed": False,
            "user_stop_observed": False,
            "client_disconnect_observed": False,
            "terminal_window_elapsed": True,
        },
        "capture_metrics": {"terminalBlankTurn": False},
        "provider_durability": {
            "pinned_ref": "refs/heads/isolated",
            "artifacts": [
                {
                    "path": "artifact.json",
                    "expected_sha256": sha,
                    "observed_sha256": sha,
                    "readback_verified": True,
                }
            ],
        },
    }


def adapter():
    return v2.CFFEngineAdapter(
        v2.CFFEngineSpec(
            ENGINE_PATH,
            ENGINE_ROOT,
            ENGINE_SHA256,
            DEPENDENCY_SHA256,
        )
    )


def native_export():
    mapping = {}
    parent = None
    exchanges = [
        ("user", "Audit the exact conversation and preserve evidence."),
        ("assistant", "I am inventorying the native source and identifiers."),
        ("user", "Continue with the bounded audit."),
        ("assistant", "Checkpoint: source identity and branches are reconciled."),
        ("user", "Test drift and terminal completion."),
        ("assistant", "I am calculating metrics and validating the event chain."),
        ("user", "n"),
        ("assistant", "Final audit artifacts are ready with explicit proof limits."),
    ]
    for index, (role, text) in enumerate(exchanges, start=1):
        node_id = f"node-{index}"
        mapping[node_id] = {
            "id": node_id,
            "parent": parent,
            "children": [],
            "message": {
                "id": f"message-{index}",
                "author": {"role": role},
                "create_time": float(1_700_000_000 + index),
                "content": {"content_type": "text", "parts": [text]},
                "metadata": {"model_slug": "synthetic-fixture"},
                "status": "finished_successfully",
            },
        }
        if parent is not None:
            mapping[parent]["children"].append(node_id)
        parent = node_id
    return [
        {
            "id": "native-conv-1",
            "conversation_id": "native-conv-1",
            "title": "Synthetic Native V2",
            "current_node": parent,
            "mapping": mapping,
        }
    ]


class ContractTests(unittest.TestCase):
    def test_strict_validation_and_duplicate_rejection(self):
        valid = v2.validate_incident_bundle(incident())
        self.assertEqual(valid["conversation"]["observed_id"], "conv-1")
        broken = incident()
        broken["sources"].append(dict(broken["sources"][0]))
        with self.assertRaises(v2.ContractError):
            v2.validate_incident_bundle(broken)
        broken = incident()
        broken["sources"][1]["sha256"] = "not-a-hash"
        with self.assertRaises(v2.ContractError):
            v2.validate_incident_bundle(broken)
        with self.assertRaises(v2.ContractError):
            v2.canonical_json({"bad": object()})

    def test_source_accounting_separates_methodology(self):
        result = v2.source_accounting(incident()["sources"])
        self.assertEqual(result["methodology_asset_count"], 1)
        self.assertEqual(result["incident_source_count"], 4)
        self.assertEqual(result["incident_captured_count"], 3)
        self.assertEqual(result["incident_blocked_count"], 1)

    def test_truth_repair_registers_contradiction_and_downgrades(self):
        result = v2.audit_incident_v1_1(incident())
        self.assertEqual(result["terminal_lifecycle"]["state"], "FAILED_FINALIZATION")
        self.assertEqual(len(result["contradictions"]), 2)
        self.assertEqual(result["confidence"]["state"], "SOURCE_SUPPORTED_PARTIAL")
        self.assertNotEqual(result["confidence"]["label"], "HIGH")
        self.assertEqual(result["backend_cause"], "UNVERIFIED")

    def test_provider_durability_requires_exact_readback(self):
        valid = v2.provider_durability(incident()["provider_durability"])
        self.assertEqual(valid["state"], "PROVEN")
        invalid = incident()["provider_durability"]
        invalid["artifacts"][0]["readback_verified"] = False
        self.assertEqual(v2.provider_durability(invalid)["state"], "UNPROVEN")

    def test_external_effect_requests_fail_closed(self):
        registry = v2.UnifiedRegistry()
        with self.assertRaises(v2.ContractError):
            registry.execute("BCO-PRIME-META-MANIFEST", {"deploy": True})


class RegistryTests(unittest.TestCase):
    def test_registry_preserves_counts_and_v1(self):
        registry = v2.UnifiedRegistry()
        manifest = registry.manifest()
        self.assertEqual(len(core.CAPABILITY_SPECS), 100)
        self.assertEqual(len(legacy.CAPABILITY_SPECS), 24)
        self.assertEqual(manifest["total_registered_count"], 134)
        self.assertFalse(manifest["engine"]["ready"])
        self.assertIn("BCO-PRIME-CAP-001", manifest["namespaces"]["core"])
        self.assertIn(
            "BCO-PRIME-CFF-CAP-001",
            manifest["namespaces"]["legacy_chat_forensics"],
        )

    def test_core_and_legacy_routes_execute(self):
        registry = v2.UnifiedRegistry()
        core_receipt = registry.execute("BCO-PRIME-CAP-001", {})
        legacy_receipt = registry.execute(
            "BCO-PRIME-CFF-CAP-001",
            {"expected_id": "conv-1", "observed_id": "conv-1"},
        )
        self.assertEqual(core_receipt["namespace"], "core")
        self.assertEqual(legacy_receipt["namespace"], "legacy_chat_forensics")

    def test_meta_manifest_route_executes(self):
        receipt = v2.UnifiedRegistry().execute("BCO-PRIME-META-MANIFEST", {})
        self.assertEqual(receipt["namespace"], "meta")
        self.assertIsInstance(receipt["output"], dict)

    def test_meta_strategy_tournament_uses_native_dataclass(self):
        candidate = {
            "strategy_id": "route-a",
            "failure_domain": "local",
            "expected_quality": 0.9,
            "evidence_strength": 0.8,
            "reliability": 0.9,
            "reversibility": 1.0,
            "information_gain": 0.8,
            "failure_domain_diversity": 0.5,
            "latency_cost": 0.1,
            "monetary_cost": 0.0,
            "owner_burden": 0.0,
            "risk": 0.1,
        }
        receipt = v2.UnifiedRegistry().execute(
            "BCO-PRIME-META-STRATEGY-TOURNAMENT",
            {"candidates": [candidate]},
        )
        self.assertEqual(receipt["namespace"], "meta")
        self.assertFalse(receipt["output"]["full_meta_runtime_ready"])

    def test_engine_absence_fails_closed(self):
        with self.assertRaises(v2.EngineUnavailable):
            v2.UnifiedRegistry().execute("CFF-V2-SEMANTIC", {})


class EngineIntegrationTests(unittest.TestCase):
    def test_engine_probe_and_hash_verification(self):
        probe = adapter().probe()
        self.assertTrue(probe["ready"], probe)
        self.assertEqual(probe["engine_sha256"], ENGINE_SHA256)
        broken = v2.CFFEngineAdapter(
            v2.CFFEngineSpec(ENGINE_PATH, ENGINE_ROOT, "0" * 64, DEPENDENCY_SHA256)
        )
        self.assertFalse(broken.probe()["ready"])

    def test_pure_engine_operations_execute(self):
        registry = v2.UnifiedRegistry(adapter())
        semantic = registry.execute(
            "CFF-V2-SEMANTIC", {"left": "finished task", "right": "finished task"}
        )
        ensemble = registry.execute("CFF-V2-ENSEMBLE", {"values": [0.2, 0.4]})
        shield = registry.execute("CFF-V2-SHIELD", {"ratio": 0.96})
        self.assertEqual(semantic["namespace"], "cff_engine")
        self.assertEqual(ensemble["namespace"], "cff_engine")
        self.assertEqual(shield["namespace"], "cff_engine")

    def test_v2_audit_is_deterministic_and_covers_ten_domains(self):
        registry = v2.UnifiedRegistry(adapter())
        first = v2.audit_incident_v2(incident(), registry)
        second = v2.audit_incident_v2(incident(), registry)
        self.assertEqual(first["receipt_sha256"], second["receipt_sha256"])
        self.assertEqual(first["core_domain_profile"]["executed_domain_count"], 10)
        self.assertEqual(first["audit_state"], "PARTIAL_CHECKPOINTED")
        self.assertFalse(first["claims"]["tested"])

    def test_output_set_validation_requires_all_seven(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            paths = v2.discover_output_paths(root, "x")
            for path in paths.values():
                Path(path).write_text("evidence", encoding="utf-8")
            result = v2.validate_cff_output_set(paths)
            self.assertTrue(result["complete"])
            Path(paths["csv"]).unlink()
            result = v2.validate_cff_output_set(paths)
            self.assertFalse(result["complete"])

    def test_native_engine_audit_produces_validated_seven_file_contract(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "conversations.json"
            source.write_text(json.dumps(native_export()), encoding="utf-8")
            receipt = adapter().run_native_audit(
                source,
                "Synthetic Native V2",
                root / "out",
                "native_fixture",
            )
            self.assertTrue(receipt["output_validation"]["complete"], receipt)
            self.assertEqual(
                receipt["output_validation"]["validated_file_count"], 7
            )
            self.assertEqual(set(receipt["output_paths"]), set(v2.OUTPUT_KEYS))
            self.assertIn(
                receipt["audit_state"], {"PARTIAL_CHECKPOINTED", "COMPLETE_VERIFIED"}
            )


if __name__ == "__main__":
    unittest.main()
